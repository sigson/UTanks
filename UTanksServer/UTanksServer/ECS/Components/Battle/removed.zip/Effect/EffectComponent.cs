﻿using UTanksServer.Core.Protocol;
using UTanksServer.ECS.ECSCore;

namespace UTanksServer.ECS.Components.Battle.Effect
{
    [TypeUid(-2031238140072554135L)]
    public class EffectComponent : ECSComponent
    {

    }
}
