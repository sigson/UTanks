﻿using System;
using UTanksServer.Core.Protocol;
using UTanksServer.ECS.ECSCore;

namespace UTanksServer.ECS.Components.Battle.Effect
{
    [TypeUid(5192591761194414739L)]
    public class DurationComponent : ECSComponent
    {
        public DurationComponent(DateTime startedTime)
        {
            StartedTime = startedTime;
        }

        public DateTime StartedTime { get; set; }
    }
}
