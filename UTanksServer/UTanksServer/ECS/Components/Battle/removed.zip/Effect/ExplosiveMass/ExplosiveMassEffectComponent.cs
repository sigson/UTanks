﻿using UTanksServer.Core.Protocol;
using UTanksServer.ECS.ECSCore;

namespace UTanksServer.ECS.Components.Battle.Effect.ExplosiveMass
{
    [TypeUid(1543402751411L)]
    public class ExplosiveMassEffectComponent : ECSComponent
    {
        public ExplosiveMassEffectComponent(float radius, long delay)
        {
            Radius = radius;
            Delay = 3000;
        }

        public float Radius { get; set; }
        public long Delay { get; set; }
    }
}
