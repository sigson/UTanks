﻿using System.Numerics;
using UTanksServer.Core.Protocol;
using UTanksServer.ECS.ECSCore;
using UTanksServer.ECS.Components.Battle.Tank;

namespace UTanksServer.ECS.Components.Battle.Effect.Unit
{
    [TypeUid(1485519196443L)]
    public class UnitMoveComponent : ECSComponent
    {
        public UnitMoveComponent(Movement movement)
        {
            Movement = movement;
        }

        public Movement Movement { get; set; }

        [ProtocolIgnore]
        public Vector3 LastPosition { get; set; }
    }
}
