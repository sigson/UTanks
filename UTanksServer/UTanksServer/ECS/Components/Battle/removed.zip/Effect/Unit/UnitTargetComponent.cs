﻿using UTanksServer.Core.Protocol;
using UTanksServer.ECS.ECSCore;

namespace UTanksServer.ECS.Components.Battle.Effect.Unit
{
    [TypeUid(1486455226183L)]
    public class UnitTargetComponent : ECSComponent
    {
        public UnitTargetComponent(ECSEntity target, ECSEntity targetIncarnation)
        {
            Target = target;
            TargetIncarnation = targetIncarnation;
        }

        public ECSEntity Target { get; set; }
        public ECSEntity TargetIncarnation { get; set; }
    }
}
