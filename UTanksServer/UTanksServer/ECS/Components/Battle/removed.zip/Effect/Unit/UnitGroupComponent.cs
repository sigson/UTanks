﻿using UTanksServer.Core.Protocol;
using UTanksServer.ECS.ECSCore;

namespace UTanksServer.ECS.Components.Battle.Effect.Unit
{
    [TypeUid(1485231135123L)]
    public sealed class UnitGroupComponent : GroupComponent
    {
        //public UnitGroupComponent(ECSEntity Key) : base(Key)
        //{
        //}

        public UnitGroupComponent(long Key) : base(Key)
        {
        }
    }
}
