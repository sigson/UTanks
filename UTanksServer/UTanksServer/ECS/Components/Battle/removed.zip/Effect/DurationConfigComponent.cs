﻿using UTanksServer.Core.Protocol;
using UTanksServer.ECS.ECSCore;

namespace UTanksServer.ECS.Components.Battle.Effect
{
    [TypeUid(482294559116673084L)]
    public class DurationConfigComponent : ECSComponent
    {
        public DurationConfigComponent(long duration)
        {
            Duration = duration;
        }

        public long Duration { get; set; }
    }
}
