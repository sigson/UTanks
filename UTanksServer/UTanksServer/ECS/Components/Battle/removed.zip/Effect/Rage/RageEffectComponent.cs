using UTanksServer.Core.Protocol;
using UTanksServer.ECS.ECSCore;

namespace UTanksServer.ECS.Components.Battle.Effect.Rage
{
    [TypeUid(636364996704090103L)]
    public class RageEffectComponent : ECSComponent
    {
        public RageEffectComponent(int decreaseCooldownPerKillMs)
        {
            DecreaseCooldownPerKillMS = decreaseCooldownPerKillMs;
        }

        public int DecreaseCooldownPerKillMS { get; set; }
    }
}
