﻿using UTanksServer.Core.Protocol;
using UTanksServer.ECS.ECSCore;

namespace UTanksServer.ECS.Components.Battle.Effect.Mine
{
    [TypeUid(636377093029435859L)]
    public class MineEffectTriggeringAreaComponent : ECSComponent
    {
        public MineEffectTriggeringAreaComponent() {
            Radius = 2;
        }

        public float Radius { get; set; }
    }
}
