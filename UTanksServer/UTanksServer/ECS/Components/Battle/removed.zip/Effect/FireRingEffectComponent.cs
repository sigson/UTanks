﻿using UTanksServer.Core.Protocol;
using UTanksServer.ECS.ECSCore;

namespace UTanksServer.ECS.Components.Battle.Effect
{
    [TypeUid(1542695311337L)]
    public class FireRingEffectComponent : ECSComponent
    {
        public FireRingEffectComponent()
        {
            Duration = 4;
            TemperatureDelta = 150;
            TemperatureLimit = 60;
        }

        public long Duration { get; set; }
        public float TemperatureDelta { get; set; }
        public float TemperatureLimit { get; set; }
    }
}
