﻿using UTanksServer.Core.Protocol;
using UTanksServer.ECS.ECSCore;

namespace UTanksServer.ECS.Components.Battle.Effect.EMP
{
    [TypeUid(636250000933021510L)]
    public class EMPEffectComponent : ECSComponent
    {
        public EMPEffectComponent(float radius)
        {
            Radius = radius;
        }

        public float Radius { get; set; }
    }
}
