﻿using UTanksServer.Core.Protocol;
using UTanksServer.ECS.ECSCore;

namespace UTanksServer.ECS.Components.Battle.Effect.EMP
{
    [TypeUid(636371831496078072L)]
    public class SlotLockedByEMPComponent : ECSComponent
    {
    }
}
