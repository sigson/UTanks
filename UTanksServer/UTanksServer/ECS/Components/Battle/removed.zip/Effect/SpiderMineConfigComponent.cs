﻿using UTanksServer.Core.Protocol;
using UTanksServer.ECS.ECSCore;

namespace UTanksServer.ECS.Components.Battle.Effect {
    [TypeUid(1487227856805L)]
    public class SpiderMineConfigComponent : ECSComponent
    {
        public SpiderMineConfigComponent(float acceleration, float speed)
        {
            Speed = speed;
            Acceleration = acceleration;
            Energy = 100;
            IdleEnergyDrainRate = 0;
            ChasingEnergyDrainRate = 0;
        }

        public float Speed { get; set; }
        public float Acceleration { get; set; }
        public float Energy { get; set; }
        public float IdleEnergyDrainRate { get; set; }
        public float ChasingEnergyDrainRate { get; set; }
    }
}
