﻿using System.Numerics;
using UTanksServer.Core.Protocol;
using UTanksServer.ECS.ECSCore;

namespace UTanksServer.ECS.Components.Battle.Effect.Drone
{
    [TypeUid(3441234123559L)]
    public class DroneMoveConfigComponent : ECSComponent
    {
        public float Acceleration { get; set; } = 20;
        public Vector3 SpawnPosition { get; set; } = new(0, 4, 0);
        public Vector3 FlyPosition { get; set; } = new(0, 5, 0);
        public float RotationSpeed { get; set; } = 5;
        public float MoveSpeed { get; set; } = 100;
    }
}
