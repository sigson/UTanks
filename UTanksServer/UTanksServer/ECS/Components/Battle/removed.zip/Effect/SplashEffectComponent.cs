﻿using UTanksServer.Core.Protocol;
using UTanksServer.ECS.ECSCore;

namespace UTanksServer.ECS.Components.Battle.Effect
{
    [TypeUid(1542363613520L)]
    public class SplashEffectComponent : ECSComponent
    {
        public SplashEffectComponent(bool canTargetTeammates)
        {
            CanTargetTeammates = canTargetTeammates;
        }

        public bool CanTargetTeammates { get; set; }
    }
}
