﻿using UTanksServer.Core.Protocol;

namespace UTanksServer.ECS.Components.Battle.Module
{
    [TypeUid(636350379074917887L)]
    public class ModuleEffectDurationPropertyComponent : ModuleEffectUpgradablePropertyComponent
    {
    }
}
