﻿using System;

using UTanksServer.Core.Protocol;
using UTanksServer.ECS.ECSCore;

namespace UTanksServer.ECS.Components.Battle.Module {
	[TypeUid(636367520290400984L)]
	public class InventorySlotTemporaryBlockedByServerComponent : ECSComponent {
		public InventorySlotTemporaryBlockedByServerComponent(long blockTimeMs, DateTime startBlockTime) {
			BlockTimeMS = blockTimeMs;
			StartBlockTime = startBlockTime;
		}

		public long BlockTimeMS { get; set; }

		public DateTime StartBlockTime { get; set; }
	}
}
