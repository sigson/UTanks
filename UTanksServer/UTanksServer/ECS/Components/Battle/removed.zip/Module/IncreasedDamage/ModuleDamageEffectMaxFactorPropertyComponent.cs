using UTanksServer.Core.Protocol;

namespace UTanksServer.ECS.Components.Battle.Module.IncreasedDamage
{
    [TypeUid(636352878319840416L)]
    public class ModuleDamageEffectMaxFactorPropertyComponent : ModuleEffectUpgradablePropertyComponent
    {
    }
}
