using UTanksServer.Core.Protocol;

namespace UTanksServer.ECS.Components.Battle.Module.IncreasedDamage
{
    [TypeUid(636352878010942748L)]
    public class ModuleDamageEffectMinFactorPropertyComponent : ModuleEffectUpgradablePropertyComponent
    {
    }
}
