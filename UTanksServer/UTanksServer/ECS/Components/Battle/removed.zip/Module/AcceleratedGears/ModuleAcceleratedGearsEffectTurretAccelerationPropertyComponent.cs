﻿using UTanksServer.Core.Protocol;

namespace UTanksServer.ECS.Components.Battle.Module.AcceleratedGears
{
    [TypeUid(636353691961041765L)]
    public class ModuleAcceleratedGearsEffectTurretAccelerationPropertyComponent : ModuleEffectUpgradablePropertyComponent
    {
    }
}
