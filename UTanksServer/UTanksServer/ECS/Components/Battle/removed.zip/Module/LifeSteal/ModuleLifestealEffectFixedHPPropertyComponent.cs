﻿using UTanksServer.Core.Protocol;

namespace UTanksServer.ECS.Components.Battle.Module.LifeSteal
{
    [TypeUid(636353775649218455L)]
    public class ModuleLifestealEffectFixedHPPropertyComponent : ModuleEffectUpgradablePropertyComponent
    {
    }
}
