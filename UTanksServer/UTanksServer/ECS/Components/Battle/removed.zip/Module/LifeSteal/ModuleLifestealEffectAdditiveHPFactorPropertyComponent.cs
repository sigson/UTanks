﻿using UTanksServer.Core.Protocol;

namespace UTanksServer.ECS.Components.Battle.Module.LifeSteal
{
    [TypeUid(636353776254463073L)]
    public class ModuleLifestealEffectAdditiveHPFactorPropertyComponent : ModuleEffectUpgradablePropertyComponent
    {
    }
}
