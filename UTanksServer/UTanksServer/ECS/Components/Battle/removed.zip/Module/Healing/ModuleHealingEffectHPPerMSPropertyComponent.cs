using UTanksServer.Core.Protocol;

namespace UTanksServer.ECS.Components.Battle.Module.Healing
{
    [TypeUid(636352945156393248L)]
    public class ModuleHealingEffectHPPerMSPropertyComponent : ModuleEffectUpgradablePropertyComponent
    {
    }
}
