using UTanksServer.Core.Protocol;

namespace UTanksServer.ECS.Components.Battle.Module.Healing
{
    [TypeUid(636352945645851244L)]
    public class ModuleHealingEffectInstantHPPropertyComponent : ModuleEffectUpgradablePropertyComponent
    {
    }
}
