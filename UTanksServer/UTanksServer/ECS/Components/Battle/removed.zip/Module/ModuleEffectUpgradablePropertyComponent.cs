﻿using System.Collections.Generic;
using UTanksServer.ECS.ECSCore;

namespace UTanksServer.ECS.Components.Battle.Module
{
    public abstract class ModuleEffectUpgradablePropertyComponent : ECSComponent
    {
        public bool LinearInterpolation { get; set; }
        public List<float> UpgradeLevel2Values { get; set; }
    }
}
