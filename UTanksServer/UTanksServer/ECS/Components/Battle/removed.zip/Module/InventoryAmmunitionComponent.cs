﻿using UTanksServer.Core.Protocol;
using UTanksServer.ECS.ECSCore;

namespace UTanksServer.ECS.Components.Battle.Module
{
	[TypeUid(636383014039871905L)]
	public class InventoryAmmunitionComponent : ECSComponent
	{
		public InventoryAmmunitionComponent(int maxCount = 0)
        {
            MaxCount = maxCount;
            CurrentCount = maxCount;
        }

		public int MaxCount { get; set; }
		public int CurrentCount { get; set; }
	}
}
