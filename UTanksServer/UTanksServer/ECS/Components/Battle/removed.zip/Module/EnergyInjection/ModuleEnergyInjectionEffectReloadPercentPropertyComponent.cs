﻿using UTanksServer.Core.Protocol;

namespace UTanksServer.ECS.Components.Battle.Module.EnergyInjection
{
    [TypeUid(636367448048338974L)]
    public class ModuleEnergyInjectionEffectReloadPercentPropertyComponent : ModuleEffectUpgradablePropertyComponent
    {
    }
}
