﻿using System;

using UTanksServer.Core.Protocol;
using UTanksServer.ECS.ECSCore;

namespace UTanksServer.ECS.Components.Battle.Module
{
	[TypeUid(1486635434064L)]
	public class InventoryCooldownStateComponent : ECSComponent
    {
		public InventoryCooldownStateComponent(int cooldownTime, DateTime cooldownStartTime)
        {
			CooldownTime = cooldownTime;
			CooldownStartTime = cooldownStartTime;
		}

		public int CooldownTime { get; set; }

		public DateTime CooldownStartTime { get; set; }
	}
}
