namespace UTanksServer.ECS.Components.Battle.Module.Sapper
{
    public class DamageResistanceEffectPropertyComponent : ModuleEffectUpgradablePropertyComponent
    {
    }
}
