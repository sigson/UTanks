﻿using UTanksServer.Core.Protocol;

namespace UTanksServer.ECS.Components.Battle.Module.EMP
{
    [TypeUid(636371764390179834L)]
    public class ModuleEMPEffectRadiusPropertyComponent : ModuleEffectUpgradablePropertyComponent
    {
    }
}
