using UTanksServer.Core.Protocol;

namespace UTanksServer.ECS.Components.Battle.Module.MultipleUsage
{
    [TypeUid(636364857408796316L)]
    public class ModuleEffectTargetingPeriodPropertyComponent : ModuleEffectUpgradablePropertyComponent
    {
    }
}
