using UTanksServer.Core.Protocol;

namespace UTanksServer.ECS.Components.Battle.Module.MultipleUsage
{
    [TypeUid(1542364761406L)]
    public class ModuleEffectSplashDamageMinPercentPropertyComponent : ModuleEffectUpgradablePropertyComponent
    {
    }
}
