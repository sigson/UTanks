﻿using UTanksServer.Core.Protocol;

namespace UTanksServer.ECS.Components.Battle.Module.MultipleUsage
{
    [TypeUid(636364868333117422L)]
    public class ModuleEffectAccelerationPropertyComponent : ModuleEffectUpgradablePropertyComponent
    {
    }
}
