using UTanksServer.Core.Protocol;

namespace UTanksServer.ECS.Components.Battle.Module.MultipleUsage
{
    [TypeUid(1542363811544L)]
    public class ModuleEffectImpactPropertyComponent : ModuleEffectUpgradablePropertyComponent
    {
    }
}
