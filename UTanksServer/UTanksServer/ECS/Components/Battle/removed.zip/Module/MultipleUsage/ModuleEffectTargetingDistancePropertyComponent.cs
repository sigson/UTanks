﻿using UTanksServer.Core.Protocol;

namespace UTanksServer.ECS.Components.Battle.Module.MultipleUsage
{
    [TypeUid(636364855396261206L)]
    public class ModuleEffectTargetingDistancePropertyComponent : ModuleEffectUpgradablePropertyComponent
    {
    }
}
