using UTanksServer.Core.Protocol;

namespace UTanksServer.ECS.Components.Battle.Module.Tempblock
{
    [TypeUid(636353658499397868L)]
    public class ModuleTempblockIncrementPropertyComponent : ModuleEffectUpgradablePropertyComponent
    {
    }
}
