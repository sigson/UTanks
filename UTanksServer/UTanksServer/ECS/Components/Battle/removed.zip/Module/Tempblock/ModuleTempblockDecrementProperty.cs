using UTanksServer.Core.Protocol;

namespace UTanksServer.ECS.Components.Battle.Module.Tempblock
{
    [TypeUid(636353659803362451L)]
    public class ModuleTempblockDecrementPropertyComponent : ModuleEffectUpgradablePropertyComponent
    {
    }
}
