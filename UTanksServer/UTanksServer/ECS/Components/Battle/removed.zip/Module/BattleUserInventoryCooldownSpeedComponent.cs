﻿using UTanksServer.Core.Protocol;
using UTanksServer.ECS.ECSCore;

namespace UTanksServer.ECS.Components.Battle.Module
{
	[TypeUid(636366605665347423L)]
	public class BattleUserInventoryCooldownSpeedComponent : ECSComponent
    {
		public BattleUserInventoryCooldownSpeedComponent(float speedCoeff)
        {
			SpeedCoeff = speedCoeff;
		}

		public float SpeedCoeff { get; set; }
	}
}
