﻿using UTanksServer.Core.Protocol;

namespace UTanksServer.ECS.Components.Battle.Module.Mine
{
    [TypeUid(636364872473691603L)]
    public class ModuleMineEffectHideRangePropertyComponent : ModuleEffectUpgradablePropertyComponent
    {
    }
}
