using UTanksServer.Core.Protocol;

namespace UTanksServer.ECS.Components.Battle.Module.Mine
{
    [TypeUid(636364862705049244L)]
    public class ModuleMineEffectSplashDamageMaxRadiusPropertyComponent : ModuleEffectUpgradablePropertyComponent
    {
    }
}
