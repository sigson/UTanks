using UTanksServer.Core.Protocol;

namespace UTanksServer.ECS.Components.Battle.Module.Mine
{
    [TypeUid(636364862254193457L)]
    public class ModuleMineEffectSplashDamageMinRadiusPropertyComponent : ModuleEffectUpgradablePropertyComponent
    {
    }
}
