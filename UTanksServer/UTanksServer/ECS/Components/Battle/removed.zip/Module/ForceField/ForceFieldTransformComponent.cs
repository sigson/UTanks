﻿using UTanksServer.Core.Protocol;
using UTanksServer.ECS.ECSCore;
using UTanksServer.ECS.Components.Battle.Tank;

namespace UTanksServer.ECS.Components.Battle.Module.ForceField
{
	[TypeUid(1505906670608L)]
	public class ForceFieldTransformComponent : ECSComponent
    {
		public ForceFieldTransformComponent(Movement movement) => Movement = movement;

        public Movement Movement { get; set; }
	}
}
