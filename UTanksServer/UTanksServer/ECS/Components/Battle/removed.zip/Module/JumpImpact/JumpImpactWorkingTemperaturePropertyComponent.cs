﻿using UTanksServer.Core.Protocol;

namespace UTanksServer.ECS.Components.Battle.Module.JumpImpact
{
    [TypeUid(1539062951383L)]
    public class JumpImpactWorkingTemperaturePropertyComponent : ModuleEffectUpgradablePropertyComponent
    {
    }
}
