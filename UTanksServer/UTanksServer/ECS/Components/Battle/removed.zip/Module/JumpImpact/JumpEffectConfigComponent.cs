﻿using UTanksServer.Core.Protocol;
using UTanksServer.ECS.ECSCore;

namespace UTanksServer.ECS.Components.Battle.Module.JumpImpact
{
	[TypeUid(1538548472363L)]
	public class JumpEffectConfigComponent : ECSComponent
    {
		public JumpEffectConfigComponent(float forceUpgradeMult) => ForceUpgradeMult = forceUpgradeMult;

        public float ForceUpgradeMult { get; set; }
	}
}
