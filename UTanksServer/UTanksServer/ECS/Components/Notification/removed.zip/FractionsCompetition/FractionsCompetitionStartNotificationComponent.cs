using UTanksServer.Core.Protocol;
using UTanksServer.ECS.ECSCore;
using UTanksServer.ECS.GlobalEntities;

namespace UTanksServer.ECS.Components.Notification.FractionsCompetition
{
    [TypeUid(1544689451885L)]
    public class FractionsCompetitionStartNotificationComponent : ECSComponent
    {
        public long[] FractionsInCompetition { get; set; } = {
            Fractions.GlobalItems.Antaeus.EntityId, Fractions.GlobalItems.Frontier.EntityId
        };
    }
}
