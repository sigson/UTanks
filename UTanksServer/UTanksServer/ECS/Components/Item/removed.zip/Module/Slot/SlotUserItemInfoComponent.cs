﻿using UTanksServer.Core.Protocol;
using UTanksServer.ECS.ECSCore;
using UTanksServer.ECS.Types;

namespace UTanksServer.ECS.Components
{
    [TypeUid(1485846320654L)]
    public class SlotUserItemInfoComponent : ECSComponent
    {
        public SlotUserItemInfoComponent(Slot slot, ModuleBehaviourType moduleBehaviourType)
        {
            Slot = slot;
            ModuleBehaviourType = moduleBehaviourType;
        }

        public Slot Slot { get; set; }

        public ModuleBehaviourType ModuleBehaviourType { get; set; }

        public int UpgradeLevel { get; set; } = 1;
    }
}
