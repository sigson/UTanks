﻿using UTanksServer.Core.Protocol;
using UTanksServer.ECS.ECSCore;
using UTanksServer.ECS.Types;

namespace UTanksServer.ECS.Components
{
    [TypeUid(636326081851010949L)]
    public class SlotTankPartComponent : ECSComponent
    {
        public SlotTankPartComponent(TankPartModuleType tankPart)
        {
            TankPart = tankPart;
        }

        public TankPartModuleType TankPart { get; set; }
    }
}
