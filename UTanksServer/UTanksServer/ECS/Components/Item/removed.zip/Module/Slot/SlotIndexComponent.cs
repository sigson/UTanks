﻿using UTanksServer.Core.Protocol;
using UTanksServer.ECS.ECSCore;

namespace UTanksServer.ECS.Components
{
    [TypeUid(1494535525136L)]
    public class SlotIndexComponent : ECSComponent
    {
        public SlotIndexComponent(int Index)
        {
            this.Index = Index;
        }

        public int Index { get; set; }
    }
}
