using UTanksServer.Core.Protocol;
using UTanksServer.ECS.ECSCore;

namespace UTanksServer.ECS.Components.Item.Module.Slot
{
    [TypeUid(1485850708198L)]
    public class SlotLockedComponent : ECSComponent
    {
    }
}
