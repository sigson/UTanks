using System.Collections.Generic;
using UTanksServer.Core.Protocol;
using UTanksServer.ECS.ECSCore;

namespace UTanksServer.ECS.Components.Item.Module
{
    [TypeUid(636462061562673727L)]
    public class TargetTierComponent : ECSComponent
    {
        public int TargetTier { get; set; }
        public int MaxExistTier { get; set; }
        public bool ContainsAllTierItem { get; set; }
        public List<long> ItemList { get; set; }
    }
}
