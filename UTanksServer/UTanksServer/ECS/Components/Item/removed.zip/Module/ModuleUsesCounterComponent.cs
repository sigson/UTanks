﻿using UTanksServer.Core.Protocol;
using UTanksServer.ECS.ECSCore;

namespace UTanksServer.ECS.Components
{
    [TypeUid(1534433783359L)]
    public class ModuleUsesCounterComponent : ECSComponent
    {
    }
}
