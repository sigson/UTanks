﻿using UTanksServer.Core.Protocol;
using UTanksServer.ECS.ECSCore;

namespace UTanksServer.ECS.Components
{
    [TypeUid(636330378478033958)]
    public class ModuleTierComponent : ECSComponent
    {
        public ModuleTierComponent(int TierNumber)
        {
            this.TierNumber = TierNumber;
        }

        public int TierNumber { get; set; }
    }
}
