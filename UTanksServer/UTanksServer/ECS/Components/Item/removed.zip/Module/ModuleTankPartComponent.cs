﻿using UTanksServer.Core.Protocol;
using UTanksServer.ECS.ECSCore;
using UTanksServer.ECS.Types;

namespace UTanksServer.ECS.Components
{
    [TypeUid(636324457894395944)]
    public class ModuleTankPartComponent : ECSComponent
    {
        public ModuleTankPartComponent(TankPartModuleType TankPart)
        {
            this.TankPart = TankPart;
        }

        public TankPartModuleType TankPart { get; set; }
    }
}
