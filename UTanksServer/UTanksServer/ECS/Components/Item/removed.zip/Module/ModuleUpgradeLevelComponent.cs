﻿using UTanksServer.Core.Protocol;
using UTanksServer.ECS.ECSCore;

namespace UTanksServer.ECS.Components.Item.Module
{
    [TypeUid(636329487716905336L)]
    public class ModuleUpgradeLevelComponent : ECSComponent
    {
        public ModuleUpgradeLevelComponent(long level)
        {
            Level = level;
        }

        public long Level { get; set; } = 0;
    }
}
