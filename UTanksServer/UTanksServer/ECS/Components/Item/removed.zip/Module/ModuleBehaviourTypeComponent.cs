﻿using UTanksServer.Core.Protocol;
using UTanksServer.ECS.ECSCore;
using UTanksServer.ECS.Types;

namespace UTanksServer.ECS.Components
{
    [TypeUid(636341573884178402)]
    public class ModuleBehaviourTypeComponent : ECSComponent
    {
        //public ModuleBehaviourTypeComponent(ModuleBehaviourType Type)
        //{
        //    this.Type = Type;
        //}

        //public ModuleBehaviourType Type { get; set; }
    }
}
