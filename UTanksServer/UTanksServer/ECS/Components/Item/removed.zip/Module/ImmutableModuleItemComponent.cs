﻿using UTanksServer.Core.Protocol;
using UTanksServer.ECS.ECSCore;

namespace UTanksServer.ECS.Components
{
    [TypeUid(1531082510042)]
    public class ImmutableModuleItemComponent : ECSComponent
    {
    }
}
