﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Net;
using System.Net.Sockets;
using BitNet;

namespace CSampleClient
{
	using GameServer;
    using System.Threading;

    class Programasdad
	{
		static List<IPeer> game_servers = new List<IPeer>();
		public static int packets = 0;
		static void Mainwefwefwefwe(string[] args)
		{
			//CPacketBufferManager.initialize(2000);

			CNetworkService service = new CNetworkService(true);

			CConnector connector = new CConnector(service);
			connector.connected_callback += on_connected_gameserver;
			IPEndPoint endpoint = new IPEndPoint(IPAddress.Parse("192.168.31.198"), 7979);
			connector.connect(endpoint);
			//System.Threading.Thread.Sleep(10);
			Thread.Sleep(2022);
			while (true)
			{
				Console.Write("> ");
				//string line = Console.ReadLine();
				//if (line == "q")
				//{
				//	break;
				//}
				string line = "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa";
				CPacket msg = CPacket.create((short)PROTOCOL.CHAT_MSG_REQ);
				msg.push(line);
				game_servers[0].send(msg);
				Thread.Sleep(5);
				packets++;
			}

			((CRemoteServerPeer)game_servers[0]).token.disconnect();

			//System.Threading.Thread.Sleep(1000 * 20);
			Console.ReadKey();
		}

		static void on_connected_gameserver(CUserToken server_token)
		{
			lock (game_servers)
			{
				IPeer server = new CRemoteServerPeer(server_token);
                server_token.on_connected();
				game_servers.Add(server);
				Console.WriteLine("Connected!");
			}
		}
	}
}
