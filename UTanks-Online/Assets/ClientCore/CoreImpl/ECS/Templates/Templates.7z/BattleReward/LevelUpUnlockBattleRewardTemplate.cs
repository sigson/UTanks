﻿using System.Collections.Generic;
using UTanksServer.Core.Protocol;
using UTanksServer.ECS.ECSCore;
using UTanksServer.ECS.Components.BattleRewards;

namespace UTanksServer.ECS.Templates.BattleReward
{
    [TypeUid(1514196284686L)]
    public class LevelUpUnlockBattleRewardTemplate : BattleResultRewardTemplate
    {
        public static ECSEntity CreateEntity(List<ECSEntity> unlockedItems)
        {
            ECSEntity battleReward = CreateEntity(new LevelUpUnlockBattleRewardTemplate(), "battle_rewards/lvlup_unlock");
            battleReward.AddComponent(new LevelUpUnlockPersonalRewardComponent(unlockedItems));

            return battleReward;
        }
    }
}
