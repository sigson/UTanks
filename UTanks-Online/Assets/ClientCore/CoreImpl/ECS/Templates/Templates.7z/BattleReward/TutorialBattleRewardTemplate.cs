﻿using UTanksServer.Core.Protocol;
using UTanksServer.ECS.ECSCore;

namespace UTanksServer.ECS.Templates.BattleReward
{
    [TypeUid(1514023810287L)]
    public class TutorialBattleRewardTemplate : BattleResultRewardTemplate
    {
        public static ECSEntity CreateEntity() =>
            CreateEntity(new TutorialBattleRewardTemplate(), "battle_rewards/tutorial");
    }
}
