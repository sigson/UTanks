using UTanksServer.Core.Protocol;
using UTanksServer.ECS.ECSCore;
using UTanksServer.ECS.Components;
using UTanksServer.ECS.Components.BattleRewards;

namespace UTanksServer.ECS.Templates.BattleReward
{
    [TypeUid(1513235522063L)]
    public class BattleResultRewardTemplate : IEntityTemplate
    {
        protected static ECSEntity CreateEntity(BattleResultRewardTemplate template, string configPath)
        {
            ECSEntity battleReward = new(new TemplateAccessor(template, configPath),
                new PersonalBattleRewardComponent());

            battleReward.AddComponent(new BattleRewardGroupComponent(battleReward));

            return battleReward;
        }
    }
}
