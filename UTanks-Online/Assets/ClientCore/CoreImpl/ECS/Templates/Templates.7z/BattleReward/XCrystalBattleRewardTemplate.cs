﻿using UTanksServer.Core.Protocol;
using UTanksServer.ECS.ECSCore;

namespace UTanksServer.ECS.Templates
{
    [TypeUid(1513245612798L)]
    public class XCrystalBattleRewardTemplate : IEntityTemplate { }
}
