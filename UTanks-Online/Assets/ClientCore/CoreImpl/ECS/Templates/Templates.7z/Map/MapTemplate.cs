﻿using UTanksServer.Core.Protocol;
using UTanksServer.ECS.ECSCore;

namespace UTanksServer.ECS.Templates
{
    [TypeUid(-5630755063511713066)]
    public class MapTemplate : IEntityTemplate { }
}
