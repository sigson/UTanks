﻿using UTanksServer.Core.Protocol;
using UTanksServer.ECS.ECSCore;

namespace UTanksServer.ECS.Templates
{
    [TypeUid(1493731132842L)]
	public class BattleCountQuestTemplate : IEntityTemplate
	{
	}
}
