﻿using UTanksServer.Core.Protocol;
using UTanksServer.ECS.ECSCore;

namespace UTanksServer.ECS.Templates
{
	[TypeUid(1493731178976L)]
	public class ScoreQuestTemplate : IEntityTemplate
	{
	}
}
