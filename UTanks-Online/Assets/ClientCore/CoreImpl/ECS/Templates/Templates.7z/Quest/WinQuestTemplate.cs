﻿using UTanksServer.Core.Protocol;
using UTanksServer.ECS.ECSCore;

namespace UTanksServer.ECS.Templates
{
    [TypeUid(1493731205127L)]
	public class WinQuestTemplate : IEntityTemplate
	{
	}
}
