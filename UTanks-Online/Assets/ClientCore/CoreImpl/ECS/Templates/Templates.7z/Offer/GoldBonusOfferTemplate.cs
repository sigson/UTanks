﻿using UTanksServer.Core.Protocol;
using UTanksServer.ECS.ECSCore;

namespace UTanksServer.ECS.Templates
{
    [TypeUid(-3834761627489275062L)]
    public class GoldBonusOfferTemplate : IEntityTemplate { }
}
