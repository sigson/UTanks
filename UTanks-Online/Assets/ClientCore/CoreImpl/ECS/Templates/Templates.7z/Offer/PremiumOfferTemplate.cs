﻿using UTanksServer.Core.Protocol;
using UTanksServer.ECS.ECSCore;

namespace UTanksServer.ECS.Templates
{
    [TypeUid(1513675638265L)]
	public class PremiumOfferTemplate : IEntityTemplate
	{
	}
}
