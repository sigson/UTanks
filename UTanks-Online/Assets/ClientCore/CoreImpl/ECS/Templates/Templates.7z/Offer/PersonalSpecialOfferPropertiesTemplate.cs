﻿using UTanksServer.Core.Protocol;
using UTanksServer.ECS.ECSCore;

namespace UTanksServer.ECS.Templates
{
    [TypeUid(636173896038335794)]
    public class PersonalSpecialOfferPropertiesTemplate : IEntityTemplate { }
}
