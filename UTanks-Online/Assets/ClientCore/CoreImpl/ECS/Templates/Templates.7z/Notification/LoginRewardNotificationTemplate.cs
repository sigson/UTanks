using UTanksServer.Core;
using UTanksServer.Core.Protocol;
using UTanksServer.ECS.ECSCore;
using UTanksServer.ECS.Components;
using UTanksServer.ECS.Components.Notification;
using UTanksServer.ECS.Types;

namespace UTanksServer.ECS.Templates.Notification
{
    [TypeUid(1523947810296L)]
    public class LoginRewardNotificationTemplate : IEntityTemplate
    {
        public static ECSEntity CreateEntity(Player player)
        {
            ECSEntity notification = new(new TemplateAccessor(new LoginRewardNotificationTemplate(), "notification/loginrewards"),
                new NotificationGroupComponent(player.User),
                new NotificationComponent(NotificationPriority.MESSAGE),
                new LoginRewardsNotificationComponent(player));

            return notification;
        }
    }
}
