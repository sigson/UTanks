﻿using UTanksServer.Core.Protocol;
using UTanksServer.ECS.ECSCore;
using UTanksServer.ECS.Components;
using UTanksServer.ECS.Components.Notification;
using UTanksServer.ECS.Types;

namespace UTanksServer.ECS.Templates
{
    [TypeUid(1475750208936L)]
    public class UIDChangedNotificationTemplate : IEntityTemplate
    {
        // warning: Alternativa logic: oldUserUID = newUserUID 
        public static ECSEntity CreateEntity(string oldUserUID, ECSEntity entity)
        {
            ECSEntity notification = new ECSEntity(new TemplateAccessor(new UIDChangedNotificationTemplate(), "notification/uidchanged"),
                new UIDChangedNotificationComponent(oldUserUID),
                new NotificationGroupComponent(entity),
                new NotificationComponent(NotificationPriority.MESSAGE));

            return notification;
        }
    }
}
