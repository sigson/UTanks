using UTanksServer.Core.Protocol;
using UTanksServer.ECS.ECSCore;
using UTanksServer.ECS.Components;
using UTanksServer.ECS.Components.Notification;
using UTanksServer.ECS.Types;

namespace UTanksServer.ECS.Templates.Notification
{
    [TypeUid(1454656560829L)]
    public class NotificationTemplate : IEntityTemplate
    {
        protected static ECSEntity CreateEntity(NotificationTemplate template, string configPath)
        {
            ECSEntity notification = new(new TemplateAccessor(template, configPath),
                new NotificationComponent(NotificationPriority.MESSAGE));

            notification.AddComponent(new NotificationGroupComponent(notification));

            return notification;
        }
    }
}
