using UTanksServer.Core;
using UTanksServer.Core.Protocol;
using UTanksServer.ECS.ECSCore;
using UTanksServer.ECS.Components;
using UTanksServer.ECS.Components.Notification.FractionsCompetition;

namespace UTanksServer.ECS.Templates.Notification.FractionsCompetition
{
    [TypeUid(1547017909507L)]
    public class FractionsCompetitionRewardNotificationTemplate : NotificationTemplate
    {
        public static ECSEntity CreateEntity(Player player)
        {
            ECSEntity notification = CreateEntity(new FractionsCompetitionRewardNotificationTemplate(),
                "notification/fractionscompetitionrewards");
            notification.Components.UnionWith(new Component[]
            {
                new FractionsCompetitionRewardNotificationComponent(player),
                player.User.GetComponent<UserGroupComponent>()
            });

            return notification;
        }
    }
}
