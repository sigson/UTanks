﻿using UTanksServer.Core.Protocol;
using UTanksServer.ECS.ECSCore;
using UTanksServer.ECS.Components;
using UTanksServer.ECS.Components.Notification;
using UTanksServer.ECS.Types;

namespace UTanksServer.ECS.Templates
{
	[TypeUid(1507711452261L)]
	public class FriendSentNotificationTemplate : IEntityTemplate
	{
        public static ECSEntity CreateEntity(ECSEntity entity)
        {
            ECSEntity notification = new ECSEntity(new TemplateAccessor(new FriendSentNotificationTemplate(), "notification/friendSent"),
                new NotificationGroupComponent(entity),
                new NotificationComponent(NotificationPriority.MESSAGE));


            return notification;
        }
    }
}
