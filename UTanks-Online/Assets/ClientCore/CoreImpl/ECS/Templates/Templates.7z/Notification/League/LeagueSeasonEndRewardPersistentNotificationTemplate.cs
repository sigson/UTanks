using UTanksServer.Core;
using UTanksServer.Core.Protocol;
using UTanksServer.ECS.ECSCore;
using UTanksServer.ECS.Components.Notification.League;

namespace UTanksServer.ECS.Templates.Notification.League
{
    [TypeUid(1508752948719L)]
    public class LeagueSeasonEndRewardPersistentNotificationTemplate : NotificationTemplate
    {
        public static ECSEntity CreateEntity(Player player)
        {
            ECSEntity notification = CreateEntity(new LeagueSeasonEndRewardPersistentNotificationTemplate(),
                "notification/league_season_end_reward");
            notification.AddComponent(new LeagueSeasonEndRewardNotificationComponent(player));

            return notification;
        }
    }
}
