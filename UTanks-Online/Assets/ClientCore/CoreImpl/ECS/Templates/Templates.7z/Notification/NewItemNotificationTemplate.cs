﻿using UTanksServer.Core.Protocol;
using UTanksServer.ECS.ECSCore;
using UTanksServer.ECS.Components;
using UTanksServer.ECS.Components.Notification;
using UTanksServer.ECS.Types;

namespace UTanksServer.ECS.Templates
{
	[TypeUid(1481176055388L)]
	public class NewItemNotificationTemplate : IEntityTemplate
	{
        public static ECSEntity CreateEntity(ECSEntity entity, ECSEntity item, int amount = 1)
        {
            return new(new TemplateAccessor(new NewItemNotificationTemplate(), "notification/newitem"),
                new NotificationGroupComponent(entity),
                new NewItemNotificationComponent(item, amount),
                new NotificationComponent(NotificationPriority.MESSAGE));
        }

        public static ECSEntity CreateCardNotification(ECSEntity container, ECSEntity card, int amount)
        {
            ECSEntity notification = CreateEntity(container, card, amount);
            notification.AddComponent(new NewCardItemNotificationComponent());
            return notification;
        }
	}
}
