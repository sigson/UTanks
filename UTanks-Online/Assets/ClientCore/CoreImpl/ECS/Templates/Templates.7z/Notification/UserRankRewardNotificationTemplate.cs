﻿using UTanksServer.Core.Protocol;
using UTanksServer.ECS.ECSCore;
using UTanksServer.ECS.Components;
using UTanksServer.ECS.Components.Notification;
using UTanksServer.ECS.Types;

namespace UTanksServer.ECS.Templates
{
    [TypeUid(636147223268818488L)]
    public class UserRankRewardNotificationTemplate : IEntityTemplate
    {
        public static ECSEntity CreateEntity(long xCrystals, long crystals, long rank)
        {
            ECSEntity notification = new(new TemplateAccessor(new UserRankRewardNotificationTemplate(), "notification/rankreward"),
                new NotificationComponent(NotificationPriority.MESSAGE),
                new UserRankRewardNotificationInfoComponent(xCrystals, crystals, rank));
            notification.AddComponent(new NotificationGroupComponent(notification));
            return notification;
        }
    }
}
