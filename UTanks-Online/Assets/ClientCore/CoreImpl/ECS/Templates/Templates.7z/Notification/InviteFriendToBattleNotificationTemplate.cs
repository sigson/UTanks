﻿using UTanksServer.Core;
using UTanksServer.Core.Protocol;
using UTanksServer.ECS.ECSCore;
using UTanksServer.ECS.Components;
using UTanksServer.ECS.Components.Battle;
using UTanksServer.ECS.Components.Notification;
using UTanksServer.ECS.Types;

namespace UTanksServer.ECS.Templates
{
    [TypeUid(1454585264587L)]
    public class InviteFriendToBattleNotificationTemplate : IEntityTemplate
    {
        public static ECSEntity CreateEntity(Player player, ECSEntity entity)
        {
            ECSEntity notification = new ECSEntity(new TemplateAccessor(new InviteFriendToBattleNotificationTemplate(), "notification/invitefriendtobattle"),
                new NotificationGroupComponent(entity),
                new NotificationComponent(NotificationPriority.MESSAGE),
                player.User.GetComponent<UserGroupComponent>(),
                player.BattlePlayer.Battle.BattleEntity.GetComponent<BattleModeComponent>(),
                player.BattlePlayer.Battle.BattleEntity.GetComponent<BattleGroupComponent>(),
                player.BattlePlayer.Battle.BattleEntity.GetComponent<MapGroupComponent>());
            player.User.AddComponent(new BattleSelectComponent());
            return notification;
        }
    }
}
