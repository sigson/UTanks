using UTanksServer.Core.Protocol;
using UTanksServer.ECS.ECSCore;
using UTanksServer.ECS.Components.Notification;

namespace UTanksServer.ECS.Templates.Notification
{
    [TypeUid(1493196797791L)]
    public class SimpleTextNotificationTemplate : NotificationTemplate
    {
        public static ECSEntity CreateEntity(string message)
        {
            ECSEntity notification = CreateEntity(new SimpleTextNotificationTemplate(), "notification/simpletext");
            notification.AddComponent(new ServerNotificationMessageComponent(message));

            return notification;
        }
    }
}
