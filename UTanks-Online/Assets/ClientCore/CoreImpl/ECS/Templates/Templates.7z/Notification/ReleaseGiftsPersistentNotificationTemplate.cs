using UTanksServer.Core;
using UTanksServer.Core.Protocol;
using UTanksServer.ECS.ECSCore;
using UTanksServer.ECS.Components.Notification;

namespace UTanksServer.ECS.Templates.Notification
{
    [TypeUid(636564549062284016L)]
    public class ReleaseGiftsPersistentNotificationTemplate : NotificationTemplate
    {
        public static ECSEntity CreateEntity(Player player)
        {
            ECSEntity notification = CreateEntity(new ReleaseGiftsPersistentNotificationTemplate(),
                "notification/releasegifts");
            notification.AddComponent(new ReleaseGiftsNotificationComponent(player));

            return notification;
        }
    }
}
