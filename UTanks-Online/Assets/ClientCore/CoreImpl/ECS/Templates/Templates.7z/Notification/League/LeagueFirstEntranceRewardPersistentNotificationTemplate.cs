using UTanksServer.Core;
using UTanksServer.Core.Protocol;
using UTanksServer.ECS.ECSCore;
using UTanksServer.ECS.Components.Notification.League;

namespace UTanksServer.ECS.Templates.Notification.League
{
    [TypeUid(1505906347666L)]
    public class LeagueFirstEntranceRewardPersistentNotificationTemplate : NotificationTemplate
    {
        public static ECSEntity CreateEntity(Player player)
        {
            ECSEntity notification = CreateEntity(new LeagueFirstEntranceRewardPersistentNotificationTemplate(),
                "notification/leaguefirstentrancereward");
            notification.AddComponent(new LeagueFirstEntranceRewardNotificationComponent(player));

            return notification;
        }
    }
}
