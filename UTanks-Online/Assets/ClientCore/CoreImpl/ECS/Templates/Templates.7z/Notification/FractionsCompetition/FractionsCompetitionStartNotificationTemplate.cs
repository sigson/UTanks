using UTanksServer.Core;
using UTanksServer.Core.Protocol;
using UTanksServer.ECS.ECSCore;
using UTanksServer.ECS.Components;
using UTanksServer.ECS.Components.Notification.FractionsCompetition;

namespace UTanksServer.ECS.Templates.Notification.FractionsCompetition
{
    [TypeUid(636564549062284016L)]
    public class FractionsCompetitionStartNotificationTemplate : NotificationTemplate
    {
        public static ECSEntity CreateEntity(Player player)
        {
            ECSEntity notification = CreateEntity(new FractionsCompetitionStartNotificationTemplate(),
                "notification/fractionscompetitionstarted");
            notification.Components.UnionWith(new Component[]
            {
                new FractionsCompetitionStartNotificationComponent(),
                player.User.GetComponent<UserGroupComponent>()
            });

            player.Data.ShowedFractionsCompetition = true;

            return notification;
        }
    }
}
