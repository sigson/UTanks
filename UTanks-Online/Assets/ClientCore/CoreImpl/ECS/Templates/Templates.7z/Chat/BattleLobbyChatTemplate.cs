﻿using UTanksServer.Core.Protocol;
using UTanksServer.ECS.ECSCore;
using UTanksServer.ECS.Components;

namespace UTanksServer.ECS.Templates.Battle
{
    [TypeUid(1499421322354L)]
    public class BattleLobbyChatTemplate : IEntityTemplate {
        public static ECSEntity CreateEntity()
        {
            ECSEntity entity = new ECSEntity(new TemplateAccessor(new BattleLobbyChatTemplate(), "/chat/general/en"),
                new ChatComponent()
            );
            return entity;
        }
    }
}