﻿using UTanksServer.Core.Protocol;
using UTanksServer.ECS.ECSCore;
using UTanksServer.ECS.Components;

namespace UTanksServer.ECS.Templates.Chat
{
    [TypeUid(1447137441472)]
    public class GeneralBattleChatTemplate : IEntityTemplate {
        public static ECSEntity CreateEntity()
        {
            ECSEntity entity = new ECSEntity(new TemplateAccessor(new GeneralBattleChatTemplate(), "/chat/general/en"),
                new ChatComponent(),
                new GeneralBattleChatComponent()
            );
            return entity;
        }
    }
}