﻿using UTanksServer.Core.Protocol;
using UTanksServer.ECS.ECSCore;
using UTanksServer.ECS.Components;

namespace UTanksServer.ECS.Templates.Battle
{
    [TypeUid(1450340158222L)]
    public class TeamBattleChatTemplate : IEntityTemplate {
        public static ECSEntity CreateEntity()
        {
            ECSEntity entity = new ECSEntity(new TemplateAccessor(new TeamBattleChatTemplate(), "/chat/general/en"),
                new ChatComponent(),
                new TeamBattleChatComponent()
            );
            return entity;
        }
    }
}