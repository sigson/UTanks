﻿using UTanksServer.Core.Protocol;
using UTanksServer.ECS.ECSCore;
using UTanksServer.ECS.Components;

namespace UTanksServer.ECS.Templates.Chat
{
    [TypeUid(1447137441472)]
    public class ChatTemplate : IEntityTemplate
    {
        public static ECSEntity CreateEntity()
        {
            ECSEntity entity = new ECSEntity(new TemplateAccessor(new ChatTemplate(), "/chat/general/en"),
                new ChatComponent()
            );
            return entity;
        }
    }
}