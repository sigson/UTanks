﻿using UTanksServer.Core.Protocol;
using UTanksServer.ECS.ECSCore;

namespace UTanksServer.ECS.Templates
{
    [TypeUid(636451756485532125L)]
    public class GeneralChatTemplate : IEntityTemplate { }
}
