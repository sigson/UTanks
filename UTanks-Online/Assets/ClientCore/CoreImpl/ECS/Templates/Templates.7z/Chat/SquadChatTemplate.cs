﻿using UTanksServer.Core;
using UTanksServer.Core.Protocol;
using UTanksServer.ECS.ECSCore;
using UTanksServer.ECS.Components;

namespace UTanksServer.ECS.Templates.Chat
{
    [TypeUid(636479864244249445L)]
    public class SquadChatTemplate : IEntityTemplate {
        public static ECSEntity CreateEntity(Player participant)
        {
            ECSEntity entity = new ECSEntity(new TemplateAccessor(new SquadChatTemplate(), "/chat/general/en"),
                new ChatParticipantsComponent(participant.User)
            );
            return entity;
        }
    }
}