﻿using UTanksServer.Core.Protocol;
using UTanksServer.ECS.ECSCore;

namespace UTanksServer.ECS.Templates
{
    [TypeUid(636469998634338659L)]
	public class PersonalChatTemplate : IEntityTemplate
	{
	}
}
