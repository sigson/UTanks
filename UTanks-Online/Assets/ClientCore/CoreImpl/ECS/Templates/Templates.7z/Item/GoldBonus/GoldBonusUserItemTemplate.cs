﻿using UTanksServer.Core.Protocol;
using UTanksServer.ECS.ECSCore;

namespace UTanksServer.ECS.Templates
{
    [TypeUid(1530005856940L)]
	public class GoldBonusUserItemTemplate : IEntityTemplate
	{
	}
}
