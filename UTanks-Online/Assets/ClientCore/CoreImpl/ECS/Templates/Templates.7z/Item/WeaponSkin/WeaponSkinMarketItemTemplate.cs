﻿using UTanksServer.Core.Protocol;
using UTanksServer.ECS.ECSCore;

namespace UTanksServer.ECS.Templates
{
    [TypeUid(1469607574709L)]
    public class WeaponSkinMarketItemTemplate : IEntityTemplate { }
}
