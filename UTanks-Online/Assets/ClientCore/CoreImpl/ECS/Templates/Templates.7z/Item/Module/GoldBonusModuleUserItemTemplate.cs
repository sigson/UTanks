﻿using System.Linq;
using UTanksServer.Core.Battles;
using UTanksServer.Core.Protocol;
using UTanksServer.ECS.ECSCore;
using UTanksServer.ECS.Components;
using UTanksServer.ECS.Components.Battle.Module;
using UTanksServer.ECS.Components.Battle.Tank;
using UTanksServer.ECS.Types;

namespace UTanksServer.ECS.Templates.Item.Module
{
	[TypeUid(1531929899999L)]
	public class GoldBonusModuleUserItemTemplate : IEntityTemplate
    {
		public static ECSEntity CreateEntity(ECSEntity garageModule, BattleTankPlayer battlePlayer)
        {
			ECSEntity slot = battlePlayer.Player.CurrentPreset.Modules.SingleOrDefault(x => x.Value == garageModule).Key;
			Component slotUserItemInfoComponent = slot != null
				? slot.GetComponent<SlotUserItemInfoComponent>()
				: new SlotUserItemInfoComponent(Types.Slot.SLOT7, ModuleBehaviourType.ACTIVE);

			ECSEntity entity = new(
				new TemplateAccessor(new GoldBonusModuleUserItemTemplate(), garageModule.TemplateAccessor.ConfigPath),
				new SlotTankPartComponent(garageModule.GetComponent<ModuleTankPartComponent>().TankPart),
				slotUserItemInfoComponent,
                new ModuleUsesCounterComponent(),
                battlePlayer.MatchPlayer.TankEntity.GetComponent<UserGroupComponent>(),
				battlePlayer.MatchPlayer.TankEntity.GetComponent<TankGroupComponent>()
			);
			return entity;
		}
    }
}
