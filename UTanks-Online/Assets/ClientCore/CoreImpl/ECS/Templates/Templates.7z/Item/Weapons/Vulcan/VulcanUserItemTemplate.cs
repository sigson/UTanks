﻿using UTanksServer.Core.Protocol;

namespace UTanksServer.ECS.Templates
{
	[TypeUid(1435139228955L)]
	public class VulcanUserItemTemplate : IWeaponUserItemTemplate
	{
	}
}
