﻿using UTanksServer.Core.Protocol;
using UTanksServer.ECS.ECSCore;

namespace UTanksServer.ECS.Templates
{
    [TypeUid(1530005871302L)]
	public class GoldBonusMarketItemTemplate : IEntityTemplate
	{
	}
}
