﻿using UTanksServer.Core.Protocol;
using UTanksServer.ECS.ECSCore;

namespace UTanksServer.ECS.Templates
{
    [TypeUid(636287153836461132L)]
    public class WeaponPaintMarketItemTemplate : IEntityTemplate { }
}
