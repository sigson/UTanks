﻿using UTanksServer.Core.Protocol;
using UTanksServer.ECS.ECSCore;

namespace UTanksServer.ECS.Templates
{
    [TypeUid(1438603647557L)]
	public class TankPaintUserItemTemplate : IEntityTemplate
	{
	}
}
