﻿using UTanksServer.Core.Protocol;
using UTanksServer.ECS.ECSCore;

namespace UTanksServer.ECS.Templates
{
    [TypeUid(1489474099632)]
    public class ContainerPackPriceMarketItemTemplate : IEntityTemplate { }
}
