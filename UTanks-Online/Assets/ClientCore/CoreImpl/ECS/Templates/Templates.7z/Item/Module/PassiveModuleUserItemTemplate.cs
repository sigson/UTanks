﻿using System.Linq;

using UTanksServer.Core.Battles;
using UTanksServer.Core.Protocol;
using UTanksServer.ECS.ECSCore;
using UTanksServer.ECS.Components;
using UTanksServer.ECS.Components.Battle.Tank;
using UTanksServer.ECS.Components.Battle.Module;

namespace UTanksServer.ECS.Templates
{
	[TypeUid(1486980355472L)]
	public class PassiveModuleUserItemTemplate : IEntityTemplate
    {
		public static ECSEntity CreateEntity(ECSEntity garageModule, BattleTankPlayer battlePlayer) {

			ECSEntity slot = battlePlayer.Player.CurrentPreset.Modules.SingleOrDefault(x => x.Value == garageModule).Key;
			Component slotUserItemInfoComponent = slot.GetComponent<SlotUserItemInfoComponent>();

			ECSEntity entity = new(
				new TemplateAccessor(
					new PassiveModuleUserItemTemplate(),
					garageModule.TemplateAccessor.ConfigPath
				),
				new SlotTankPartComponent(garageModule.GetComponent<ModuleTankPartComponent>().TankPart),
				slotUserItemInfoComponent,
                new ModuleUsesCounterComponent(),
                battlePlayer.MatchPlayer.TankEntity.GetComponent<UserGroupComponent>(),
				battlePlayer.MatchPlayer.TankEntity.GetComponent<TankGroupComponent>()
			);
			return entity;
		}
	}
}
