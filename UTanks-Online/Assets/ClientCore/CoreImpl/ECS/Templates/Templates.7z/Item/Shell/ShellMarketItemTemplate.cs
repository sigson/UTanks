﻿using UTanksServer.Core.Protocol;
using UTanksServer.ECS.ECSCore;

namespace UTanksServer.ECS.Templates
{
    [TypeUid(716181447780635764)]
    public class ShellMarketItemTemplate : IEntityTemplate { }
}
