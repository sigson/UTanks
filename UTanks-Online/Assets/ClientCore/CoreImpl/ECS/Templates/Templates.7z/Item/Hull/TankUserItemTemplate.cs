﻿using UTanksServer.Core.Protocol;
using UTanksServer.ECS.ECSCore;

namespace UTanksServer.ECS.Templates
{
    [TypeUid(1438603503434L)]
	public class TankUserItemTemplate : IEntityTemplate
	{
	}
}
