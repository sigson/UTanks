﻿using UTanksServer.Core.Protocol;
using UTanksServer.ECS.ECSCore;

namespace UTanksServer.ECS.Templates
{
    [TypeUid(1479898249156L)]
	public class CrystalUserItemTemplate : IEntityTemplate
	{
	}
}
