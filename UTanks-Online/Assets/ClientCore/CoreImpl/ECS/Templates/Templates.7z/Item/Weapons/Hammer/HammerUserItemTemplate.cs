﻿using UTanksServer.Core.Protocol;
using UTanksServer.ECS.ECSCore;

namespace UTanksServer.ECS.Templates
{
    [TypeUid(1435138823086L)]
	public class HammerUserItemTemplate : IWeaponUserItemTemplate
	{
	}
}
