﻿using UTanksServer.Core.Protocol;
using UTanksServer.ECS.ECSCore;

namespace UTanksServer.ECS.Templates
{
    [TypeUid(1491539852367)]
    public class XCrystalMarketItemTemplate : IEntityTemplate { }
}
