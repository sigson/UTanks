﻿using System.Linq;

using UTanksServer.Core.Battles;
using UTanksServer.Core.Protocol;
using UTanksServer.ECS.ECSCore;
using UTanksServer.ECS.Components;
using UTanksServer.ECS.Components.Battle.Module;
using UTanksServer.ECS.Components.Battle.Tank;
using UTanksServer.ECS.Types;

namespace UTanksServer.ECS.Templates.Item.Module {
	[TypeUid(1484901449548L)]
	public class ModuleUserItemTemplate : IEntityTemplate {
		public static ECSEntity CreateEntity(ECSEntity garageModule, BattleTankPlayer battlePlayer)
        {
			ECSEntity slot = battlePlayer.Player.CurrentPreset.Modules.SingleOrDefault(x => x.Value == garageModule).Key;
            if (slot is null) return null;
			Component slotUserItemInfoComponent = slot.GetComponent<SlotUserItemInfoComponent>();

			ECSEntity entity = new(new TemplateAccessor(new ModuleUserItemTemplate(), garageModule.TemplateAccessor.ConfigPath),
				new SlotTankPartComponent(garageModule.GetComponent<ModuleTankPartComponent>().TankPart),
				// new ModuleTierComponent(1),
				slotUserItemInfoComponent,
				/*
				new SlotUserItemInfoComponent(slot.GetComponent<SlotUserItemInfoComponent>().Slot, garageModule.GetComponent<ModuleBehaviourTypeComponent>().Type) {
				    UpgradeLevel = 1
				},
				*/
                /*
                new ModuleBehaviourTypeComponent(ModuleBehaviourType.ACTIVE),
                new ModuleTankPartComponent(TankPartModuleType.TANK),
                new ModuleUpgradeLevelComponent() {
                    Level = 666
                },
                */
				new ModuleUsesCounterComponent(),
				//new UserItemCounterComponent(100),
				battlePlayer.MatchPlayer.TankEntity.GetComponent<UserGroupComponent>(),
				battlePlayer.MatchPlayer.TankEntity.GetComponent<TankGroupComponent>()
			);

            return entity;
		}
	}
}
