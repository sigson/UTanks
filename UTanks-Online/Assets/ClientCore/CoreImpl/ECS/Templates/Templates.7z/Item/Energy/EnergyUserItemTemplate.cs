﻿using UTanksServer.Core.Protocol;
using UTanksServer.ECS.ECSCore;

namespace UTanksServer.ECS.Templates
{
    [TypeUid(1502967306412)]
    public class EnergyUserItemTemplate : IEntityTemplate
    {
    }
}
