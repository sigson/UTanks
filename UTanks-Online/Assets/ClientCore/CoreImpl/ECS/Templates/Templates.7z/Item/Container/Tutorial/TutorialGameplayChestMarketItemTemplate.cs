﻿using UTanksServer.Core.Protocol;
using UTanksServer.ECS.ECSCore;

namespace UTanksServer.ECS.Templates
{
    [TypeUid(636413290399070700L)]
	public class TutorialGameplayChestMarketItemTemplate : IEntityTemplate
	{
	}
}
