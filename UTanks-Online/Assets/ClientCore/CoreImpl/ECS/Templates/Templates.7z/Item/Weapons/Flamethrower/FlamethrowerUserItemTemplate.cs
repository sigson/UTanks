﻿using UTanksServer.Core.Protocol;
using UTanksServer.ECS.ECSCore;

namespace UTanksServer.ECS.Templates
{
    [TypeUid(1435139307697L)]
	public class FlamethrowerUserItemTemplate : IWeaponUserItemTemplate
	{
	}
}
