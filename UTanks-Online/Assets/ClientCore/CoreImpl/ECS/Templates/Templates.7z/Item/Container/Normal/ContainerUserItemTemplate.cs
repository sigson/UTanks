﻿using UTanksServer.Core.Protocol;
using UTanksServer.ECS.ECSCore;

namespace UTanksServer.ECS.Templates
{
    [TypeUid(1479807574456L)]
    public class ContainerUserItemTemplate : IEntityTemplate
    {
    }
}
