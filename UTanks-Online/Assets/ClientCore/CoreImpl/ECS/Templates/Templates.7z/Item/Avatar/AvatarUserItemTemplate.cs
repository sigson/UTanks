﻿using UTanksServer.Core.Protocol;
using UTanksServer.ECS.ECSCore;

namespace UTanksServer.ECS.Templates
{
    [TypeUid(1544694265965L)]
	public class AvatarUserItemTemplate : IEntityTemplate
	{
	}
}
