﻿using UTanksServer.Core.Protocol;
using UTanksServer.ECS.ECSCore;

namespace UTanksServer.ECS.Templates
{
    [TypeUid(1435138663254L)]
	public class TwinsMarketItemTemplate : IEntityTemplate
	{
	}
}
