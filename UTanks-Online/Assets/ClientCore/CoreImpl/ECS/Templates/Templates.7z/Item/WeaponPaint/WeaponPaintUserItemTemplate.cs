﻿using UTanksServer.Core.Protocol;
using UTanksServer.ECS.ECSCore;

namespace UTanksServer.ECS.Templates
{
    [TypeUid(636287154959625373L)]
	public class WeaponPaintUserItemTemplate : IEntityTemplate
	{
	}
}
