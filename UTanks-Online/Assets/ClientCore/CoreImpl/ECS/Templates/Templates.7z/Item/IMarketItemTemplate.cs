﻿using System;
using UTanksServer.ECS.ECSCore;

namespace UTanksServer.ECS.Templates
{
    public interface IMarketItemTemplate : IEntityTemplate
    {
        Type UserItemType { get; }
    }
}
