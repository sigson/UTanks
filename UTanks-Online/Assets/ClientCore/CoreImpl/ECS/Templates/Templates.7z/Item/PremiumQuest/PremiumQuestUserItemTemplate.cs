﻿using UTanksServer.Core.Protocol;
using UTanksServer.ECS.ECSCore;

namespace UTanksServer.ECS.Templates
{
    [TypeUid(1513582138852L)]
	public class PremiumQuestUserItemTemplate : IEntityTemplate
	{
	}
}
