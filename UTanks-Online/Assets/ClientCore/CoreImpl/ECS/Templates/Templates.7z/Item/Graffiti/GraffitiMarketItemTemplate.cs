﻿using UTanksServer.Core.Protocol;
using UTanksServer.ECS.ECSCore;

namespace UTanksServer.ECS.Templates
{
    [TypeUid(636100801770520539L)]
    public class GraffitiMarketItemTemplate : IEntityTemplate { }
}
