﻿using UTanksServer.Core.Protocol;
using UTanksServer.ECS.ECSCore;

namespace UTanksServer.ECS.Templates
{
    [TypeUid(1513580195801L)]
	public class PremiumBoostMarketItemTemplate : IEntityTemplate
	{
	}
}
