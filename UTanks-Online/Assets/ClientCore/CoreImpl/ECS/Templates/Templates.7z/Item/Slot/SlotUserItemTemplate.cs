﻿using UTanksServer.Core.Battles;
using UTanksServer.Core.Protocol;
using UTanksServer.ECS.ECSCore;
using UTanksServer.ECS.Components;
using UTanksServer.ECS.Components.Battle.Tank;

namespace UTanksServer.ECS.Templates.Item.Slot
{
    [TypeUid(1485846188251L)]
    public class SlotUserItemTemplate : IEntityTemplate
    {
        public static ECSEntity CreateEntity(ECSEntity module, BattleTankPlayer battlePlayer)
        {
            ECSEntity entity = new ECSEntity(new TemplateAccessor(new SlotUserItemTemplate(), "/garage/module/slot"),
                module.GetComponent<SlotTankPartComponent>(),
                module.GetComponent<SlotUserItemInfoComponent>(),
                battlePlayer.MatchPlayer.TankEntity.GetComponent<UserGroupComponent>(),
                battlePlayer.MatchPlayer.TankEntity.GetComponent<TankGroupComponent>()
            );
            
            module.AddComponent(new ModuleGroupComponent(entity.EntityId));
            
            return entity;
        }
    }
}