﻿using UTanksServer.Core.Protocol;
using UTanksServer.ECS.ECSCore;

namespace UTanksServer.ECS.Templates
{
    [TypeUid(1487149202122)]
    public class GameplayChestMarketItemTemplate : IEntityTemplate { }
}
