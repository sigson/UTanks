﻿using UTanksServer.Core.Protocol;
using UTanksServer.ECS.ECSCore;

namespace UTanksServer.ECS.Templates
{
    [TypeUid(1433406732656L)]
    public class TankMarketItemTemplate : IEntityTemplate
    {
    }
}
