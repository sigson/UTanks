﻿using UTanksServer.Core.Protocol;
using UTanksServer.ECS.ECSCore;

namespace UTanksServer.ECS.Templates
{
    [TypeUid(1433406804439L)]
	public class FreezeUserItemTemplate : IWeaponUserItemTemplate
	{
	}
}
