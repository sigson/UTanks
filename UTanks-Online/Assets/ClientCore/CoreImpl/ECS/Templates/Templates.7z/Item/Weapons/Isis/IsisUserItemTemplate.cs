﻿using UTanksServer.Core.Protocol;
using UTanksServer.ECS.ECSCore;

namespace UTanksServer.ECS.Templates
{
    [TypeUid(1435910167704L)]
	public class IsisUserItemTemplate : IWeaponUserItemTemplate
	{
	}
}
