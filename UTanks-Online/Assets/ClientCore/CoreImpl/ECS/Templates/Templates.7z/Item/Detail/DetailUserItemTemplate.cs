﻿using UTanksServer.Core.Protocol;
using UTanksServer.ECS.ECSCore;

namespace UTanksServer.ECS.Templates
{
    [TypeUid(636457331914703122L)]
    public class DetailUserItemTemplate : IEntityTemplate
    {
    }
}
