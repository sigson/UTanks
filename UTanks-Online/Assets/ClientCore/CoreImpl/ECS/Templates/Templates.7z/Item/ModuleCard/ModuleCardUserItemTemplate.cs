﻿using UTanksServer.Core.Protocol;
using UTanksServer.ECS.ECSCore;

namespace UTanksServer.ECS.Templates
{
    [TypeUid(636319308428353334L)]
	public class ModuleCardUserItemTemplate : IEntityTemplate
	{
	}
}
