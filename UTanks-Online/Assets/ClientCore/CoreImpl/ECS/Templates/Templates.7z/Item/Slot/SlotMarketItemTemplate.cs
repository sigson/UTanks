﻿using UTanksServer.Core.Protocol;
using UTanksServer.ECS.ECSCore;

namespace UTanksServer.ECS.Templates
{
	[TypeUid(636390988457169067L)]
	public class SlotMarketItemTemplate : IEntityTemplate
	{
	}
}
