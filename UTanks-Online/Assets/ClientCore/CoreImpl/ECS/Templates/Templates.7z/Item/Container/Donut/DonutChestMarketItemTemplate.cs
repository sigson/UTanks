﻿using UTanksServer.Core.Protocol;
using UTanksServer.ECS.ECSCore;

namespace UTanksServer.ECS.Templates
{
    [TypeUid(636408122917164205L)]
    public class DonutChestMarketItemTemplate : IEntityTemplate
    {
    }
}
