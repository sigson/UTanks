﻿using UTanksServer.Core.Protocol;
using UTanksServer.ECS.ECSCore;

namespace UTanksServer.ECS.Templates
{
    [TypeUid(1469607756132L)]
	public class WeaponSkinUserItemTemplate : IEntityTemplate
	{
	}
}
