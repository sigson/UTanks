﻿using UTanksServer.Core.Protocol;
using UTanksServer.ECS.ECSCore;

namespace UTanksServer.ECS.Templates
{
    [TypeUid(1543968970810L)]
	public class SimpleChestUserItemTemplate : IEntityTemplate
	{
	}
}
