﻿using UTanksServer.Core.Protocol;
using UTanksServer.ECS.ECSCore;

namespace UTanksServer.ECS.Templates
{
    [TypeUid(1479898113503L)]
	public class CrystalMarketItemTemplate : IEntityTemplate
	{
	}
}
