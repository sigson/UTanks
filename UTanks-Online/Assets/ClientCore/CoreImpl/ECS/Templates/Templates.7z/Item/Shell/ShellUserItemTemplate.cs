﻿using UTanksServer.Core.Protocol;
using UTanksServer.ECS.ECSCore;

namespace UTanksServer.ECS.Templates
{
    [TypeUid(-1597888122960034653L)]
    public class ShellUserItemTemplate : IEntityTemplate
    {
    }
}
