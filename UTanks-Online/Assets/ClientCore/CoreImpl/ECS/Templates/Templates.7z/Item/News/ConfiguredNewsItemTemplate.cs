﻿using UTanksServer.Core.Protocol;
using UTanksServer.ECS.ECSCore;

namespace UTanksServer.ECS.Templates
{
    [TypeUid(1481257271234L)]
    public class ConfiguredNewsItemTemplate : IEntityTemplate { }
}
