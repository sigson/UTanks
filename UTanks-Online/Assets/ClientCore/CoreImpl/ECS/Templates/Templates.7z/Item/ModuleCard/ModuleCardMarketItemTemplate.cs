﻿using UTanksServer.Core.Protocol;
using UTanksServer.ECS.ECSCore;

namespace UTanksServer.ECS.Templates
{
    [TypeUid(636319307214133884L)]
    public class ModuleCardMarketItemTemplate : IEntityTemplate { }
}
