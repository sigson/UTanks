﻿using System;
using UTanksServer.Core.Protocol;

namespace UTanksServer.ECS.Templates
{
    [TypeUid(1493972656490L)]
    public class PresetMarketItemTemplate : IMarketItemTemplate
    {
        public Type UserItemType => typeof(PresetUserItemTemplate);
    }
}
