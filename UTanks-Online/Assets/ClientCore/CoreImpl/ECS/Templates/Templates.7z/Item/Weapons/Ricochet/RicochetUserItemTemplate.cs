﻿using UTanksServer.Core.Protocol;
using UTanksServer.ECS.ECSCore;

namespace UTanksServer.ECS.Templates
{
    [TypeUid(1435138285320L)]
	public class RicochetUserItemTemplate : IWeaponUserItemTemplate
	{
	}
}
