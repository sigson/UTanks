﻿using UTanksServer.Core.Protocol;
using UTanksServer.ECS.ECSCore;

namespace UTanksServer.ECS.Templates
{
    [TypeUid(636100801497439942L)]
    public class ChildGraffitiMarketItemTemplate : IEntityTemplate { }
}
