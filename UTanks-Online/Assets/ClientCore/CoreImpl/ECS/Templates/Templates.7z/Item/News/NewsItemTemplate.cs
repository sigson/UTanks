﻿using UTanksServer.Core.Protocol;
using UTanksServer.ECS.ECSCore;

namespace UTanksServer.ECS.Templates.Item.News
{
    [TypeUid(1479374682015L)]
    public class NewsItemTemplate : IEntityTemplate { }
}
