﻿using UTanksServer.Core.Protocol;
using UTanksServer.ECS.ECSCore;

namespace UTanksServer.ECS.Templates
{
    [TypeUid(1435139147319L)]
	public class ThunderMarketItemTemplate : IEntityTemplate
	{
	}
}
