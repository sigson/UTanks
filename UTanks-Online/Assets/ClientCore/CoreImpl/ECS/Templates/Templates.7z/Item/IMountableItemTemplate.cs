﻿using UTanksServer.ECS.ECSCore;

namespace UTanksServer.ECS.Templates
{
    public interface IMountableItemTemplate : IEntityTemplate { }
}
