﻿using UTanksServer.Core;
using UTanksServer.ECS.ECSCore;

namespace UTanksServer.ECS.Templates
{
    public interface IUserItemTemplate : IEntityTemplate
    {
        void AddUserItemComponents(Player player, ECSEntity item);
    }
}
