﻿using UTanksServer.Core.Protocol;
using UTanksServer.ECS.ECSCore;

namespace UTanksServer.ECS.Templates
{
    [TypeUid(1433406776150L)]
	public class SmokyUserItemTemplate : IWeaponUserItemTemplate
	{
	}
}
