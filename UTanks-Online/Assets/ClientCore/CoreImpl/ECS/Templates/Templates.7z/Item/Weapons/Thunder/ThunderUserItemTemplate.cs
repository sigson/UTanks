﻿using UTanksServer.Core.Protocol;
using UTanksServer.ECS.ECSCore;

namespace UTanksServer.ECS.Templates
{
    [TypeUid(1435139182866L)]
	public class ThunderUserItemTemplate : IWeaponUserItemTemplate
	{
	}
}
