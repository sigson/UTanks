﻿using UTanksServer.Core.Protocol;
using UTanksServer.ECS.ECSCore;

namespace UTanksServer.ECS.Templates
{
    [TypeUid(636457330280837037L)]
    public class DetailMarketItemTemplate : IEntityTemplate 
    {
    }
}
