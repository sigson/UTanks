﻿using UTanksServer.Core;
using UTanksServer.Core.Protocol;
using UTanksServer.ECS.ECSCore;
using UTanksServer.ECS.Components;

namespace UTanksServer.ECS.Templates
{
    [TypeUid(1493972686116L)]
    public class PresetUserItemTemplate : IUserItemTemplate, IMountableItemTemplate
    {
        public void AddUserItemComponents(Player player, ECSEntity item)
        {
            item.Components.Add(new PresetEquipmentComponent(player, item));
            item.Components.Add(new PresetNameComponent($"Preset {player.Data.Presets.Count + 1}"));
            player.Data.Presets.Add(item);
        }
    }
}
