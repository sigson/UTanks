﻿using UTanksServer.Core.Protocol;
using UTanksServer.ECS.ECSCore;

namespace UTanksServer.ECS.Templates
{
    [TypeUid(1491539827448L)]
	public class XCrystalUserItemTemplate : IEntityTemplate
	{
	}
}
