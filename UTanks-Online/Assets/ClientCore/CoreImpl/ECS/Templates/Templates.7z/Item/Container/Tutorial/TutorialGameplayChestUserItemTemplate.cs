﻿using UTanksServer.Core.Protocol;
using UTanksServer.ECS.ECSCore;

namespace UTanksServer.ECS.Templates
{
    [TypeUid(636413315444096863L)]
	public class TutorialGameplayChestUserItemTemplate : IEntityTemplate
	{
	}
}
