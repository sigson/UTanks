﻿using UTanksServer.Core.Protocol;
using UTanksServer.ECS.ECSCore;

namespace UTanksServer.ECS.Templates
{
    [TypeUid(1454928219469)]
    public class LobbyTemplate : IEntityTemplate { }
}
