﻿using System;
using UTanksServer.Core;
using UTanksServer.Core.Protocol;
using UTanksServer.ECS.ECSCore;
using UTanksServer.ECS.Components;
using UTanksServer.ECS.Components.DailyBonus;
using UTanksServer.ECS.Components.User;
using UTanksServer.ECS.Components.User.Tutorial;

namespace UTanksServer.ECS.Templates.User
{
    [TypeUid(1433752208915)]
    public class UserTemplate : IEntityTemplate
    {
        public static ECSEntity CreateEntity(Player player)
        {
            ECSEntity user = new(new TemplateAccessor(new UserTemplate(), ""),
                new UserComponent(),
                new UserOnlineComponent(),

                new UserUidComponent(player.Data.Username),
                new UserCountryComponent(player.Data.CountryCode),
                new RegistrationDateComponent(player.Data.RegistrationDate),

                new UserMoneyComponent(player.Data.Crystals),
                new UserXCrystalsComponent(player.Data.XCrystals),
                new UserRankComponent(Leveling.GetRankByXp(player.Data.Experience)),
                new UserExperienceComponent(player.Data.Experience),
                new UserReputationComponent(player.Data.Reputation),

                //new TutorialCompleteIdsComponent(player.Data.CompletedTutorialIds, player),

                new FractionUserScoreComponent(player.Data.FractionUserScore),

                new UserStatisticsComponent(),
                new FavoriteEquipmentStatisticsComponent(),
                new KillsEquipmentStatisticsComponent(),
                new BattleLeaveCounterComponent(0, 0),

                new PersonalChatOwnerComponent(),

                new LeagueGroupComponent(player.Data.League),
                new GameplayChestScoreComponent(player.Data.LeagueChestScore),

                new BlackListComponent(),

                new UserDailyBonusInitializedComponent(player),
                new UserDailyBonusCycleComponent(player),
                new UserDailyBonusReceivedRewardsComponent(player),
                new UserDailyBonusZoneComponent(player),
                new UserDailyBonusNextReceivingDateComponent(player),

                new QuestReadyComponent(),
                new UserPublisherComponent(),
                new ConfirmedUserEmailComponent(player.Data.Email, player.Data.Subscribed),
                new UserSubscribeComponent());

            if (player.Data.Admin)
            {
                user.Components.Add(new UserAdminComponent());
                if (!player.Data.IsPremium)
                    player.Data.RenewPremium(new TimeSpan(23999976, 0, 0));
            }
            if (player.Data.Beta)
                user.Components.Add(new ClosedBetaQuestAchievementComponent());

            if (player.Data.Fraction is not null)
                user.AddComponent(new FractionGroupComponent(player.Data.Fraction));

            if (player.Data.PremiumExpirationDate > DateTime.UtcNow)
                user.AddComponent(new PremiumAccountBoostComponent(player.Data.PremiumExpirationDate));

            user.AddComponent(new UserGroupComponent(user));

            return user;
        }
    }
}
