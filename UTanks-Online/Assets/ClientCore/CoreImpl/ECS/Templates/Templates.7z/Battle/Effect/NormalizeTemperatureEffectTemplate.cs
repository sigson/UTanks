using UTanksServer.Core.Battles;
using UTanksServer.Core.Protocol;
using UTanksServer.ECS.ECSCore;

namespace UTanksServer.ECS.Templates.Battle.Effect
{
    [TypeUid(1487227012386L)]
    public class NormalizeTemperatureEffectTemplate : EffectBaseTemplate
    {
        public static ECSEntity CreateEntity(MatchPlayer matchPlayer) =>
            CreateEntity(new NormalizeTemperatureEffectTemplate(), "battle/effect/normalizetemperature", matchPlayer);
    }
}
