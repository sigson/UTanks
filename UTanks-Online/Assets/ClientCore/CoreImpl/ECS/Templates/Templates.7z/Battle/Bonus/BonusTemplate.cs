﻿using UTanksServer.Core.Protocol;
using UTanksServer.ECS.ECSCore;
using UTanksServer.ECS.Components.Battle.Bonus;
using UTanksServer.ECS.Types;
using System;
using System.Numerics;
using UTanksServer.ECS.Components.Battle.Location;
using UTanksServer.ECS.Components.Battle;

namespace UTanksServer.ECS.Templates.Battle.Bonus
{
    [TypeUid(7553964914512142106L)]
    public class BonusTemplate : IEntityTemplate
    {
        public static ECSEntity CreateEntity(BonusTemplate template, string configPath, ECSEntity bonusRegion, Vector3 position, ECSEntity battleEntity)
        {
            return new (new TemplateAccessor(template, configPath),
                new BonusComponent(),
                new BonusDropTimeComponent(DateTime.UtcNow),
                new PositionComponent(position),
                new RotationComponent(new Vector3(0, 0, 0)),
                bonusRegion.GetComponent<BonusRegionGroupComponent>(),
                battleEntity.GetComponent<BattleGroupComponent>()
            );
        }
    }
}
