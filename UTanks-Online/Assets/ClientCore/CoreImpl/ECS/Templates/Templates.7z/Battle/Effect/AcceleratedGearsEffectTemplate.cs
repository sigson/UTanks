﻿using UTanksServer.Core.Battles;
using UTanksServer.Core.Protocol;
using UTanksServer.ECS.ECSCore;

namespace UTanksServer.ECS.Templates.Battle.Effect
{
    [TypeUid(1486978694968L)]
    public class AcceleratedGearsEffectTemplate : EffectBaseTemplate
    {
        public static ECSEntity CreateEntity(MatchPlayer matchPlayer) =>
            CreateEntity(new AcceleratedGearsEffectTemplate(), "battle/effect/acceleratedgears", matchPlayer);
    }
}
