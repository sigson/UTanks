﻿using UTanksServer.Core.Battles;
using UTanksServer.Core.Configuration;
using UTanksServer.Core.Protocol;
using UTanksServer.ECS.ECSCore;
using UTanksServer.ECS.Components.Battle.Weapon;
using UTanksServer.ECS.Components.Battle.Weapon.Hammer;

namespace UTanksServer.ECS.Templates.Battle.Weapon
{
    [TypeUid(4939169559170921259L)]
    public class HammerBattleItemTemplate : DiscreteWeaponTemplate
    {
        private const string ConfigPath = "garage/weapon/hammer";

        public static ECSEntity CreateEntity(ECSEntity tank, BattleTankPlayer battlePlayer)
        {
            ECSEntity entity = CreateEntity(new HammerBattleItemTemplate(), ConfigPath, tank, battlePlayer);

            entity.Components.UnionWith(new Component[]
            {
                Config.GetComponent<HammerPelletConeComponent>(ConfigPath.Replace("garage", "battle")),
                Config.GetComponent<MagazineWeaponComponent>(ConfigPath),
                new HammerComponent(),
                new MagazineReadyStateComponent(),
            });

            return entity;
        }
    }
}
