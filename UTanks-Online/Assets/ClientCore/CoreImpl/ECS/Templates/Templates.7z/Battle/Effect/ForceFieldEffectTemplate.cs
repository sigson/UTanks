﻿using UTanksServer.Core.Battles;
using UTanksServer.Core.Protocol;
using UTanksServer.ECS.ECSCore;

namespace UTanksServer.ECS.Templates.Battle.Effect
{
	[TypeUid(1503314606668L)]
	public class ForceFieldEffectTemplate : EffectBaseTemplate
    {
        private const string ConfigPath = "/battle/effect/forcefield";

        public static ECSEntity CreateEntity(MatchPlayer matchPlayer) =>
            CreateEntity(new ForceFieldEffectTemplate(), ConfigPath, matchPlayer, 8000, addTeam:true);
    }
}
