using System;
using System.Collections.Generic;
using UTanksServer.Core.Battles;
using UTanksServer.Core.Configuration;
using UTanksServer.Core.Protocol;
using UTanksServer.ECS.ECSCore;
using UTanksServer.ECS.Components;
using UTanksServer.ECS.Components.Battle;
using UTanksServer.ECS.Components.Battle.Energy;
using UTanksServer.ECS.Components.Battle.Tank;
using UTanksServer.ECS.Components.Battle.Team;
using UTanksServer.ECS.Components.Battle.Weapon;
using UTanksServer.ECS.Templates.Battle.Weapon;
using UTanksServer.ECS.GlobalEntities;

namespace UTanksServer.ECS.Templates.Battle
{
    [TypeUid(1430285417001)]
    public class WeaponTemplate : IEntityTemplate
    {
        private static readonly Dictionary<Type, Func<ECSEntity, BattleTankPlayer, ECSEntity>> UserToBattleTemplate = new()
        {
            { typeof(SmokyUserItemTemplate), SmokyBattleItemTemplate.CreateEntity },
            { typeof(FlamethrowerUserItemTemplate), FlamethrowerBattleItemTemplate.CreateEntity },
            { typeof(FreezeUserItemTemplate), FreezeBattleItemTemplate.CreateEntity },
            { typeof(IsisUserItemTemplate), IsisBattleItemTemplate.CreateEntity },
            { typeof(ThunderUserItemTemplate), ThunderBattleItemTemplate.CreateEntity },
            { typeof(RicochetUserItemTemplate), RicochetBattleItemTemplate.CreateEntity },
            { typeof(TwinsUserItemTemplate), TwinsBattleItemTemplate.CreateEntity },
            { typeof(RailgunUserItemTemplate), RailgunBattleItemTemplate.CreateEntity },
            { typeof(ShaftUserItemTemplate), ShaftBattleItemTemplate.CreateEntity },
            { typeof(HammerUserItemTemplate), HammerBattleItemTemplate.CreateEntity },
            { typeof(VulcanUserItemTemplate), VulcanBattleItemTemplate.CreateEntity },
        };

        public static ECSEntity CreateEntity(ECSEntity userItem, ECSEntity tank, BattleTankPlayer battlePlayer)
        {
            if (UserToBattleTemplate.TryGetValue(userItem.TemplateAccessor.Template.GetType(),
                out Func<ECSEntity, BattleTankPlayer, ECSEntity> method))
                return method(tank, battlePlayer);

            throw new NotImplementedException();
        }

        protected static ECSEntity CreateEntity(WeaponTemplate template, string configPath, ECSEntity tank, BattleTankPlayer battlePlayer)
        {
            ECSEntity weapon = new(new TemplateAccessor(template, configPath.Replace("garage", "battle")),
                tank.GetComponent<TankPartComponent>(),
                new WeaponComponent(),
                tank.GetComponent<UserGroupComponent>(),
                tank.GetComponent<TankGroupComponent>(),
                tank.GetComponent<BattleGroupComponent>(),
                battlePlayer.Player.CurrentPreset.Weapon.GetComponent<MarketItemGroupComponent>());

            if (template.GetType() != typeof(HammerBattleItemTemplate))
                weapon.AddComponent(new WeaponEnergyComponent(1));

            if (battlePlayer.Team != null)
                weapon.AddComponent(battlePlayer.Team.GetComponent<TeamGroupComponent>());

            if (Config.GetComponent<WeaponCooldownComponent>(configPath, false) is Component component)
            {
                if (battlePlayer.TurretUnloadEnergyPerShot != null)
                    component = new WeaponCooldownComponent((float)battlePlayer.TurretUnloadEnergyPerShot);
                else if (template.GetType() == typeof(ShaftBattleItemTemplate))
                    ((WeaponCooldownComponent) component).CooldownIntervalSec = 2;

                weapon.Components.Add(component);
            }

            return weapon;
        }
    }
}
