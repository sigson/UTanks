﻿using UTanksServer.Core.Battles;
using UTanksServer.Core.Protocol;
using UTanksServer.ECS.ECSCore;
using UTanksServer.ECS.Components;
using UTanksServer.ECS.Components.Battle;
using UTanksServer.ECS.Components.Battle.Round;
using UTanksServer.ECS.Components.Battle.Tank;
using UTanksServer.ECS.Components.Battle.Team;

namespace UTanksServer.ECS.Templates.Battle
{
    [TypeUid(140335313420508312)]
    public class RoundUserTemplate : IEntityTemplate
    {
        public static ECSEntity CreateEntity(BattleTankPlayer battlePlayer, ECSEntity battle, ECSEntity tank)
        {
            ECSEntity entity = new ECSEntity(new TemplateAccessor(new RoundUserTemplate(), "battle/round/rounduser"),
                new RoundUserStatisticsComponent(1, 0, 0, 0, 0),
                new RoundUserComponent(),
                new UserGroupComponent(battlePlayer.User),
                new BattleGroupComponent(battle));
            if (battlePlayer.Team != null)
                entity.Components.Add(battlePlayer.Team.GetComponent<TeamGroupComponent>());
            if (tank != null)
                entity.Components.Add(tank.GetComponent<TankGroupComponent>());
            return entity;
        }
    }
}
