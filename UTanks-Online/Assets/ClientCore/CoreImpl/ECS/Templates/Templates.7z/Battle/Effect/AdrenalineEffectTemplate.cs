using UTanksServer.Core.Battles;
using UTanksServer.Core.Protocol;
using UTanksServer.ECS.ECSCore;

namespace UTanksServer.ECS.Templates.Battle.Effect
{
    [TypeUid(636365892282334249L)]
    public class AdrenalineEffectTemplate : EffectBaseTemplate
    {
        public static ECSEntity CreateEntity(MatchPlayer matchPlayer) => CreateEntity(new AdrenalineEffectTemplate(),
            "/battle/effect/andrenaline", matchPlayer);
    }
}
