using UTanksServer.Core.Battles;
using UTanksServer.Core.Protocol;
using UTanksServer.ECS.ECSCore;

namespace UTanksServer.ECS.Templates.Battle.Effect
{
    [TypeUid(1486018775542L)]
    public class ArmorEffectTemplate : EffectBaseTemplate
    {
        public static ECSEntity CreateEntity(MatchPlayer matchPlayer, long duration) =>
            CreateEntity(new ArmorEffectTemplate(), "battle/effect/armor", matchPlayer, duration);
    }
}
