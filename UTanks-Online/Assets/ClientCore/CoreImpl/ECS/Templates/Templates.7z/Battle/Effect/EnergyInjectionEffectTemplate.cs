﻿using UTanksServer.Core.Battles;
using UTanksServer.Core.Protocol;
using UTanksServer.ECS.ECSCore;

namespace UTanksServer.ECS.Templates.Battle.Effect
{
    [TypeUid(636367475101866348L)]
    public class EnergyInjectionEffectTemplate : EffectBaseTemplate
    {
        public static ECSEntity CreateEntity(MatchPlayer matchPlayer) =>
            CreateEntity(new EnergyInjectionEffectTemplate(), "battle/effect/energyinjection",
                matchPlayer);
    }
}
