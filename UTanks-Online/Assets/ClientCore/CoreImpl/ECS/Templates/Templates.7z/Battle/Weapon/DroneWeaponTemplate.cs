﻿using UTanksServer.Core.Battles;
using UTanksServer.Core.Configuration;
using UTanksServer.Core.Protocol;
using UTanksServer.ECS.ECSCore;
using UTanksServer.ECS.Components;
using UTanksServer.ECS.Components.Battle;
using UTanksServer.ECS.Components.Battle.Effect.Unit;
using UTanksServer.ECS.Components.Battle.Team;
using UTanksServer.ECS.Components.Battle.Weapon;

namespace UTanksServer.ECS.Templates.Battle.Weapon
{
    [TypeUid(1485335125183L)]
    public class DroneWeaponTemplate : IEntityTemplate
    {
        private const string ConfigPath = "battle/effect/droneweapon";

        public static ECSEntity CreateEntity(MatchPlayer matchPlayer)
        {
            ECSEntity effect = new(new TemplateAccessor(new DroneWeaponTemplate(), ConfigPath),
                new DroneWeaponComponent(),

                matchPlayer.Battle.BattleEntity.GetComponent<BattleGroupComponent>(),
                matchPlayer.TankEntity.GetComponent<UserGroupComponent>(),

                new ShootableComponent(),
                Config.GetComponent<StreamHitConfigComponent>(ConfigPath),

                new WeaponComponent(),
                Config.GetComponent<WeaponCooldownComponent>(ConfigPath));

            if (matchPlayer.Battle.ModeHandler is Core.Battles.Battle.TeamBattleHandler)
                effect.AddComponent(matchPlayer.TankEntity.GetComponent<TeamGroupComponent>());

            effect.AddComponent(new UnitGroupComponent(effect));

            return effect;
        }
    }
}
