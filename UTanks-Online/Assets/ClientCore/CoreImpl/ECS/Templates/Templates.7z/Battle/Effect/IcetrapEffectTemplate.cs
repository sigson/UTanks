using UTanksServer.Core.Battles;
using UTanksServer.Core.Protocol;
using UTanksServer.ECS.ECSCore;
using UTanksServer.ECS.Components;
using UTanksServer.ECS.Components.Battle;
using UTanksServer.ECS.Components.Battle.Effect;
using UTanksServer.ECS.Components.Battle.Effect.Mine;
using UTanksServer.ECS.Components.Battle.Weapon;

namespace UTanksServer.ECS.Templates.Battle.Effect
{
    [TypeUid(636384697009346423L)]
    public class IcetrapEffectTemplate : EffectBaseTemplate
    {
        public static ECSEntity CreateEntity(MatchPlayer matchPlayer, long activationTime, float beginHideDistance,
            float damageMaxRadius, float damageMinRadius, float damageMinPercent, float hideRange, float impact)
        {
            ECSEntity effect = CreateEntity(new IcetrapEffectTemplate(), "/battle/effect/icetrap", matchPlayer, addTeam:true);
            effect.Components.UnionWith(new Component[]
            {
                new EffectActiveComponent(),

                new MineConfigComponent(activationTime: activationTime,
                    beginHideDistance: beginHideDistance, hideRange: hideRange, impact: impact),
                new MinePositionComponent(matchPlayer.TankPosition),
                new MineEffectTriggeringAreaComponent(),

                new SplashWeaponComponent(damageMinPercent,  damageMaxRadius, damageMinRadius),
                new SplashEffectComponent(matchPlayer.Battle.Params.FriendlyFire),
                new SplashImpactComponent(impact),

                new DamageWeakeningByDistanceComponent(damageMinPercent, damageMaxRadius, damageMinRadius),
                new DiscreteWeaponComponent(),

                matchPlayer.Battle.BattleEntity.GetComponent<BattleGroupComponent>(),
                matchPlayer.Player.User.GetComponent<UserGroupComponent>()
            });

            return effect;
        }
    }
}
