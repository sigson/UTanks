using UTanksServer.Core.Battles;
using UTanksServer.Core.Protocol;
using UTanksServer.ECS.ECSCore;
using UTanksServer.ECS.Components.Battle;
using UTanksServer.ECS.Components.Battle.Effect;
using UTanksServer.ECS.Components.Battle.Weapon;

namespace UTanksServer.ECS.Templates.Battle.Effect
{
    [TypeUid(1554279538858L)]
    public class KamikadzeEffectTemplate : EffectBaseTemplate
    {
        public static ECSEntity CreateEntity(float damageMinPercent, bool friendlyFire, float impact, float splashRadius,
            MatchPlayer matchPlayer)
        {
            ECSEntity effect = CreateEntity(new KamikadzeEffectTemplate(), "battle/effect/kamikadze", matchPlayer, addTeam:true);
            effect.Components.UnionWith(new Component[]
            {
                new SplashEffectComponent(friendlyFire),
                new SplashWeaponComponent(damageMinPercent, 0, splashRadius),
                new SplashImpactComponent(impact),

                new DamageWeakeningByDistanceComponent(damageMinPercent, 0, splashRadius),

                new DiscreteWeaponComponent(),

                matchPlayer.Battle.BattleEntity.GetComponent<BattleGroupComponent>()
            });

            return effect;
        }
    }
}
