﻿using UTanksServer.Core.Battles;
using UTanksServer.Core.Protocol;
using UTanksServer.ECS.ECSCore;
using UTanksServer.ECS.Components.Battle.Effect.ExplosiveMass;

namespace UTanksServer.ECS.Templates.Battle.Effect
{
    [TypeUid(1543482696222L)]
    public class ExplosiveMassEffectTemplate : EffectBaseTemplate
    {
        public static ECSEntity CreateEntity(MatchPlayer matchPlayer, float radius, long delay)
        {
            ECSEntity effect = CreateEntity(new ExplosiveMassEffectTemplate(), "/battle/effect/explosivemass", matchPlayer, addTeam:true);

            effect.AddComponent(new ExplosiveMassEffectComponent(radius, delay));

            return effect;
        }
    }
}
