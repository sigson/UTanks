﻿using UTanksServer.Core.Battles;
using UTanksServer.Core.Protocol;
using UTanksServer.ECS.ECSCore;
using UTanksServer.ECS.Components.Battle.Weapon;

namespace UTanksServer.ECS.Templates.Battle.Weapon
{
    [TypeUid(-8770103861152493981L)]
	public class ThunderBattleItemTemplate : DiscreteWeaponTemplate
	{
        public static ECSEntity CreateEntity(ECSEntity tank, BattleTankPlayer battlePlayer)
        {
            ECSEntity entity = CreateEntity(new ThunderBattleItemTemplate(), "garage/weapon/thunder", tank, battlePlayer);
            entity.Components.Add(new SplashImpactComponent(4f));
            entity.Components.Add(new SplashWeaponComponent(40f, 0f, 15f));
            entity.Components.Add(new ThunderComponent());

            return entity;
        }
    }
}
