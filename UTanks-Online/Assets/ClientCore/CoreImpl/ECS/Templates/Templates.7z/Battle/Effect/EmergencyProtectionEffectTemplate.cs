using UTanksServer.Core.Battles;
using UTanksServer.Core.Protocol;
using UTanksServer.ECS.ECSCore;

namespace UTanksServer.ECS.Templates.Battle.Effect
{
    [TypeUid(636301946304873717L)]
    public class EmergencyProtectionEffectTemplate : EffectBaseTemplate
    {
        public static ECSEntity CreateEntity(MatchPlayer matchPlayer)
        {
            return CreateEntity(new EmergencyProtectionEffectTemplate(), "/battle/effect/emergencyprotection",
                matchPlayer, addTeam: true);
        }
    }
}
