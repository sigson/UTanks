using UTanksServer.Core.Battles;
using UTanksServer.Core.Protocol;
using UTanksServer.ECS.ECSCore;

namespace UTanksServer.ECS.Templates.Battle.Effect
{
    [TypeUid(1486988156885L)]
    public class HealingEffectTemplate : EffectBaseTemplate
    {
        public static ECSEntity CreateEntity(MatchPlayer matchPlayer, long duration) =>
            CreateEntity(new HealingEffectTemplate(), "battle/effect/healing", matchPlayer, duration);
    }
}
