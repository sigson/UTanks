﻿using UTanksServer.Core.Protocol;
using UTanksServer.ECS.ECSCore;
using UTanksServer.ECS.Components;
using UTanksServer.ECS.Components.Battle;
using UTanksServer.ECS.Components.Battle.Tank;
using UTanksServer.ECS.Components.Battle.Weapon;

namespace UTanksServer.ECS.Templates.Battle
{
    [TypeUid(636046254605033322)]
    public class WeaponSkinBattleItemTemplate : IEntityTemplate
    {
        public static ECSEntity CreateEntity(ECSEntity userItem, ECSEntity tank)
        {
            return new ECSEntity(new TemplateAccessor(new WeaponSkinBattleItemTemplate(), userItem.TemplateAccessor.ConfigPath),
                new WeaponSkinBattleItemComponent(),
                tank.GetComponent<UserGroupComponent>(),
                tank.GetComponent<BattleGroupComponent>(),
                tank.GetComponent<TankGroupComponent>(),
                userItem.GetComponent<MarketItemGroupComponent>());
        }
    }
}