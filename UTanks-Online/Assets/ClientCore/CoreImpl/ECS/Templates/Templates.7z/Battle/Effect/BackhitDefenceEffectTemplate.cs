using UTanksServer.Core.Battles;
using UTanksServer.Core.Protocol;
using UTanksServer.ECS.ECSCore;

namespace UTanksServer.ECS.Templates.Battle.Effect
{
    [TypeUid(636335612872999792L)]
    public class BackhitDefenceEffectTemplate : EffectBaseTemplate
    {
        public static ECSEntity CreateEntity(MatchPlayer matchPlayer) =>
            CreateEntity(new BackhitDefenceEffectTemplate(), "battle/effect/backhitdefence", matchPlayer);
    }
}
