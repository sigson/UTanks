﻿using UTanksServer.Core.Protocol;
using UTanksServer.ECS.ECSCore;
using UTanksServer.ECS.Components.Battle;

namespace UTanksServer.ECS.Templates.Battle
{
    [TypeUid(-4141404049750078994)]
    public class DMTemplate : BattleTemplate
    {
        public static ECSEntity CreateEntity(ECSEntity battleLobby, int scoreLimit, int timeLimit, int warmingUpTimeLimit)
        {
            ECSEntity entity = CreateEntity(battleLobby, new DMTemplate(), "dm", scoreLimit, timeLimit, warmingUpTimeLimit);
            entity.Components.Add(new DMComponent());

            return entity;
        }
    }
}