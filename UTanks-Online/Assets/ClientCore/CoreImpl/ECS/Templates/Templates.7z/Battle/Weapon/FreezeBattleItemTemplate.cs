﻿using UTanksServer.Core.Battles;
using UTanksServer.Core.Protocol;
using UTanksServer.ECS.ECSCore;
using UTanksServer.ECS.Components.Battle.Weapon;
using UTanksServer.ECS.Templates.Battle.Weapon;

namespace UTanksServer.ECS.Templates.Battle
{
    [TypeUid(525358843506658817L)]
    public class FreezeBattleItemTemplate : StreamWeaponTemplate
    {
        public static ECSEntity CreateEntity(ECSEntity tank, BattleTankPlayer battlePlayer)
        {
            ECSEntity entity = CreateEntity(new FreezeBattleItemTemplate(), "garage/weapon/freeze", tank, battlePlayer);
            entity.Components.Add(new FreezeComponent());

            return entity;
        }
    }
}
