﻿using System.Numerics;
using UTanksServer.Core.Protocol;
using UTanksServer.ECS.ECSCore;
using UTanksServer.ECS.Components.Battle;
using UTanksServer.ECS.Components.Battle.Team;

namespace UTanksServer.ECS.Templates.Battle
{
    [TypeUid(1431941266589L)]
    public class FlagTemplate : IEntityTemplate
    {
        public static ECSEntity CreateEntity(Vector3 position, ECSEntity team, ECSEntity battle)
        {
            return new(new TemplateAccessor(new FlagTemplate(), "battle/modes/ctf"),
                new FlagComponent(),
                team.GetComponent<TeamGroupComponent>(),
                battle.GetComponent<BattleGroupComponent>(),
                new FlagHomeStateComponent(),
                new FlagPositionComponent(position));
        }
    }
}