﻿using UTanksServer.Core.Battles;
using UTanksServer.Core.Protocol;
using UTanksServer.ECS.ECSCore;

namespace UTanksServer.ECS.Templates.Battle.Effect
{
    [TypeUid(636341525184122918L)]
    public class LifestealEffectTemplate : EffectBaseTemplate
    {
        private static readonly string _configPath = "/battle/effect/lifesteal";

        public static ECSEntity CreateEntity(MatchPlayer matchPlayer) =>
            CreateEntity(new LifestealEffectTemplate(), _configPath, matchPlayer);
    }
}
