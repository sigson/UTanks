﻿using UTanksServer.Core.Battles;
using UTanksServer.Core.Protocol;
using UTanksServer.ECS.ECSCore;
using UTanksServer.ECS.Components.Battle.Module;
using UTanksServer.ECS.Components.Battle.Module.JumpImpact;

namespace UTanksServer.ECS.Templates.Battle.Effect
{
	[TypeUid(1538451741218L)]
	public class JumpEffectTemplate : EffectBaseTemplate
    {
        private static readonly string _configPath = "/battle/effect/jumpimpact";

		public static ECSEntity CreateEntity(MatchPlayer matchPlayer, float forceMultiplier)
        {
            ECSEntity effect = CreateEntity(new JumpEffectTemplate(), _configPath, matchPlayer);
            effect.AddComponent(new JumpEffectConfigComponent(forceMultiplier));

            return effect;
		}
	}
}
