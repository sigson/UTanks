﻿using UTanksServer.Core.Protocol;
using UTanksServer.ECS.ECSCore;
using UTanksServer.ECS.Components;
using UTanksServer.ECS.Components.Battle;
using UTanksServer.ECS.Components.Battle.Hull;
using UTanksServer.ECS.Components.Battle.Tank;

namespace UTanksServer.ECS.Templates.Battle
{
    [TypeUid(636047163591561471)]
    public class HullSkinBattleItemTemplate : IEntityTemplate
    {
        public static ECSEntity CreateEntity(ECSEntity userItem, ECSEntity tank)
        {
            return new ECSEntity(new TemplateAccessor(new HullSkinBattleItemTemplate(), userItem.TemplateAccessor.ConfigPath),
                new HullSkinBattleItemComponent(),
                tank.GetComponent<UserGroupComponent>(),
                tank.GetComponent<BattleGroupComponent>(),
                tank.GetComponent<TankGroupComponent>(),
                userItem.GetComponent<MarketItemGroupComponent>());
        }
    }
}