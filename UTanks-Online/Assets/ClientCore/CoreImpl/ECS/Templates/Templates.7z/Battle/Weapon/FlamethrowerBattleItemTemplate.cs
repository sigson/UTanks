﻿using UTanksServer.Core.Battles;
using UTanksServer.Core.Protocol;
using UTanksServer.ECS.ECSCore;
using UTanksServer.ECS.Components.Battle.Weapon;
using UTanksServer.ECS.Templates.Battle.Weapon;

namespace UTanksServer.ECS.Templates.Battle
{
    [TypeUid(4652768934679402653L)]
    public class FlamethrowerBattleItemTemplate : StreamWeaponTemplate
    {
        public static ECSEntity CreateEntity(ECSEntity tank, BattleTankPlayer battlePlayer)
        {
            ECSEntity entity = CreateEntity(new FlamethrowerBattleItemTemplate(), "garage/weapon/flamethrower", tank, battlePlayer);
            entity.Components.Add(new FlamethrowerComponent());

            return entity;
        }
    }
}
