﻿using UTanksServer.Core.Battles;
using UTanksServer.Core.Configuration;
using UTanksServer.Core.Protocol;
using UTanksServer.ECS.ECSCore;
using UTanksServer.ECS.Components;
using UTanksServer.ECS.Components.Battle;
using UTanksServer.ECS.Components.Battle.Chassis;
using UTanksServer.ECS.Components.Battle.Health;
using UTanksServer.ECS.Components.Battle.Tank;
using UTanksServer.ECS.Components.Battle.Team;

namespace UTanksServer.ECS.Templates.Battle.Tank
{
    [TypeUid(2012489519776979402)]
    public class TankTemplate : IEntityTemplate
    {
        public static ECSEntity CreateEntity(ECSEntity hullUserItem, ECSEntity battleUser, BattleTankPlayer battlePlayer)
        {
            string configPath = hullUserItem.TemplateAccessor.ConfigPath;

            ECSEntity entity = new(new TemplateAccessor(new TankTemplate(), configPath.Replace("garage", "battle")),
                new TankComponent(),
                new TankPartComponent(),
                battleUser.GetComponent<UserGroupComponent>(),
                battleUser.GetComponent<BattleGroupComponent>(),
                Config.GetComponent<HealthConfigComponent>(configPath),
                Config.GetComponent<DampingComponent>(configPath),
                Config.GetComponent<SpeedComponent>(configPath),
                Config.GetComponent<SpeedConfigComponent>(configPath),
                Config.GetComponent<WeightComponent>(configPath),
                new TemperatureComponent(0),
                new TankNewStateComponent(),
                battlePlayer.Player.CurrentPreset.Hull.GetComponent<MarketItemGroupComponent>());

            if (battleUser.HasComponent<TeamGroupComponent>())
                entity.Components.Add(battleUser.GetComponent<TeamGroupComponent>());
            entity.Components.Add(new TankGroupComponent(entity));

            return entity;
        }
    }
}
