﻿using UTanksServer.Core.Protocol;
using UTanksServer.ECS.ECSCore;
using UTanksServer.ECS.Components.Battle;

namespace UTanksServer.ECS.Templates.Battle.BattleMode
{
    [TypeUid(8215935014037697786L)]
    public class TDMTemplate : TeamBattleTemplate
    {
        public static ECSEntity CreateEntity(ECSEntity battleLobby, int scoreLimit, int timeLimit, int warmingUpTimeLimit)
        {
            ECSEntity entity = CreateEntity(battleLobby, new TDMTemplate(), "tdm", scoreLimit, timeLimit, warmingUpTimeLimit);
            entity.Components.Add(new TDMComponent());
            entity.Components.Add(new BattleScoreComponent());

            return entity;
        }
    }
}
