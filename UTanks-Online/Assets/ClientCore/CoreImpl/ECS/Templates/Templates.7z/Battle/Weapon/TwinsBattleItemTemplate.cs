﻿using UTanksServer.Core.Battles;
using UTanksServer.Core.Protocol;
using UTanksServer.ECS.ECSCore;
using UTanksServer.ECS.Components.Battle.Weapon;
using UTanksServer.ECS.Templates.Battle.Weapon;

namespace UTanksServer.ECS.Templates.Battle
{
    [TypeUid(583528765588657091L)]
    public class TwinsBattleItemTemplate : DiscreteWeaponTemplate
    {
        public static ECSEntity CreateEntity(ECSEntity tank, BattleTankPlayer battlePlayer)
        {
            ECSEntity entity = CreateEntity(new TwinsBattleItemTemplate(), "garage/weapon/twins", tank, battlePlayer);
            entity.Components.Add(new TwinsComponent());

            entity.Components.Add(battlePlayer.BulletSpeed == null
                ? new WeaponBulletShotComponent(0.5f, 150f)
                : new WeaponBulletShotComponent(0.5f, (float)battlePlayer.BulletSpeed));

            return entity;
        }
    }
}
