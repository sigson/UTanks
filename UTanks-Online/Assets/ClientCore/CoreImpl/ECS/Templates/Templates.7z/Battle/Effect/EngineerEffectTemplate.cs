﻿using UTanksServer.Core.Battles;
using UTanksServer.Core.Protocol;
using UTanksServer.ECS.ECSCore;

namespace UTanksServer.ECS.Templates.Battle.Effect
{
    [TypeUid(636334642664388463L)]
    public class EngineerEffectTemplate : EffectBaseTemplate
    {
        private static readonly string _configPath = "/battle/effect/engineer";

        public static ECSEntity CreateEntity(MatchPlayer matchPlayer) =>
            CreateEntity(new EngineerEffectTemplate(), _configPath, matchPlayer);
    }
}
