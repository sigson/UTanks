﻿using System.Numerics;
using UTanksServer.Core.Protocol;
using UTanksServer.ECS.ECSCore;
using UTanksServer.ECS.Components.Battle;
using UTanksServer.ECS.Components.Battle.Team;
using UTanksServer.ECS.Types;

namespace UTanksServer.ECS.Templates.Battle
{
    [TypeUid(1431942342249L)]
    public class PedestalTemplate : IEntityTemplate
    {
        public static ECSEntity CreateEntity(Vector3 position, ECSEntity team, ECSEntity battle)
        {
            ECSEntity entity = new ECSEntity(new TemplateAccessor(new PedestalTemplate(), "battle/modes/ctf"),
                new FlagPedestalComponent(position),
                team.GetComponent<TeamGroupComponent>(),
                battle.GetComponent<BattleGroupComponent>()
            );
            return entity;
        }
    }
}