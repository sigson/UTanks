﻿using System.Numerics;
using UTanksServer.Core.Battles;
using UTanksServer.Core.Protocol;
using UTanksServer.ECS.ECSCore;
using UTanksServer.ECS.Components;
using UTanksServer.ECS.Components.Battle.Effect;
using UTanksServer.ECS.Components.Battle.Effect.Drone;
using UTanksServer.ECS.Components.Battle.Effect.Unit;
using UTanksServer.ECS.Components.Battle.Tank;

namespace UTanksServer.ECS.Templates.Battle.Effect
{
    [TypeUid(1485335642293L)]
    public class DroneEffectTemplate : EffectBaseTemplate
    {
        public static ECSEntity CreateEntity(float duration, float targetingDistance, float targetingPeriod, ECSEntity weapon,
            MatchPlayer matchPlayer)
        {
            Vector3 spawnPosition = new (matchPlayer.TankPosition.X, matchPlayer.TankPosition.Y + 4,
                matchPlayer.TankPosition.Z);

            ECSEntity effect = CreateEntity(new DroneEffectTemplate(), "battle/effect/drone", matchPlayer,
                (long) duration, addTeam: true);

            effect.Components.UnionWith(new Component[]
            {
                new DroneEffectComponent(),
                new DroneMoveConfigComponent(),
                new EffectActiveComponent(),
                new UnitComponent(),
                new UnitMoveComponent(new Movement(spawnPosition, Vector3.Zero,
                    Vector3.Zero, matchPlayer.TankQuaternion)),
                new UnitTargetingConfigComponent(targetingPeriod, targetingDistance),

                weapon.GetComponent<UnitGroupComponent>(),
                matchPlayer.Player.User.GetComponent<UserGroupComponent>(),
            });

            return effect;
        }
    }
}
