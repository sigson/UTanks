﻿using UTanksServer.Core.Protocol;
using UTanksServer.ECS.ECSCore;
using UTanksServer.ECS.Components;
using UTanksServer.ECS.Components.Battle;
using UTanksServer.ECS.Components.Battle.Tank;
using UTanksServer.ECS.Components.Battle.Weapon;

namespace UTanksServer.ECS.Templates.Battle
{
    [TypeUid(636100801926133320L)]
    public class GraffitiBattleItemTemplate : IEntityTemplate
    {
        public static ECSEntity CreateEntity(ECSEntity userItem, ECSEntity tank)
        {
            return new ECSEntity(new TemplateAccessor(new GraffitiBattleItemTemplate(), userItem.TemplateAccessor.ConfigPath),
                new GraffitiBattleItemComponent(),
                tank.GetComponent<UserGroupComponent>(),
                userItem.GetComponent<MarketItemGroupComponent>());
        }
    }
}