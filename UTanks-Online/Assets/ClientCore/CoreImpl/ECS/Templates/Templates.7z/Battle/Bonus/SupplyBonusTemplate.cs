﻿using System.Numerics;
using UTanksServer.Core.Protocol;
using UTanksServer.ECS.ECSCore;
using UTanksServer.ECS.Types;

namespace UTanksServer.ECS.Templates.Battle.Bonus
{
	[TypeUid(5411677468097447480L)]
	public class SupplyBonusTemplate : BonusTemplate
	{
        public static ECSEntity CreateEntity(BonusType bonusType, ECSEntity bonusRegion, Vector3 position, ECSEntity battleEntity) =>
            CreateEntity(new SupplyBonusTemplate(), $"battle/bonus/{bonusType.ToString().ToLower()}",
                bonusRegion, position, battleEntity);
    }
}
