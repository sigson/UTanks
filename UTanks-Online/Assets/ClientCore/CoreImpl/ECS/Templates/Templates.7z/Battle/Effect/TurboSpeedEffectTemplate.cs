using UTanksServer.Core.Battles;
using UTanksServer.Core.Protocol;
using UTanksServer.ECS.ECSCore;

namespace UTanksServer.ECS.Templates.Battle.Effect
{
    [TypeUid(1486970297039L)]
    public class TurboSpeedEffectTemplate : EffectBaseTemplate
    {
        public static ECSEntity CreateEntity(MatchPlayer matchPlayer, long duration) => CreateEntity(new TurboSpeedEffectTemplate(),
            "battle/effect/turbospeed", matchPlayer, duration);
    }
}
