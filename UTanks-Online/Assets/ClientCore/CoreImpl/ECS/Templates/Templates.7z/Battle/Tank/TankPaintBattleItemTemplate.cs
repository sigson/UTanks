﻿using UTanksServer.Core.Protocol;
using UTanksServer.ECS.ECSCore;
using UTanksServer.ECS.Components;
using UTanksServer.ECS.Components.Battle;
using UTanksServer.ECS.Components.Battle.Tank;
using UTanksServer.ECS.Components.Battle.Weapon;

namespace UTanksServer.ECS.Templates.Battle
{
    [TypeUid(1437375358285)]
    public class TankPaintBattleItemTemplate : IEntityTemplate
    {
        public static ECSEntity CreateEntity(ECSEntity userItem, ECSEntity tank)
        {
            return new ECSEntity(new TemplateAccessor(new TankPaintBattleItemTemplate(), userItem.TemplateAccessor.ConfigPath),
                new TankPaintBattleItemComponent(),
                tank.GetComponent<UserGroupComponent>(),
                tank.GetComponent<BattleGroupComponent>(),
                tank.GetComponent<TankGroupComponent>(),
                userItem.GetComponent<MarketItemGroupComponent>());
        }
    }
}