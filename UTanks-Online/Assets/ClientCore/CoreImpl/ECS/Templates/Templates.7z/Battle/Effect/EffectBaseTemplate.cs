﻿using System;
using UTanksServer.Core.Battles;
using UTanksServer.Core.Protocol;
using UTanksServer.ECS.ECSCore;
using UTanksServer.ECS.Components;
using UTanksServer.ECS.Components.Battle.Effect;
using UTanksServer.ECS.Components.Battle.Tank;
using UTanksServer.ECS.Components.Battle.Team;

namespace UTanksServer.ECS.Templates.Battle.Effect
{
    [TypeUid(1486041253393L)]
    public class EffectBaseTemplate : IEntityTemplate
    {
        protected static ECSEntity CreateEntity(EffectBaseTemplate template, string configPath,
            MatchPlayer matchPlayer, long durationMs = 0, bool addTeam = false)
        {
            ECSEntity effect = new(new TemplateAccessor(template, configPath),
                new EffectComponent(),
                matchPlayer.TankEntity.GetComponent<TankGroupComponent>());

            if (durationMs > 0)
            {
                effect.AddComponent(new DurationConfigComponent(durationMs));
                effect.AddComponent(new DurationComponent(DateTime.UtcNow));
            }

            if (addTeam && matchPlayer.Battle.ModeHandler is Core.Battles.Battle.TeamBattleHandler)
            {
                effect.AddComponent(matchPlayer.Player.BattlePlayer.Team.GetComponent<TeamColorComponent>());
                effect.AddComponent(matchPlayer.Player.BattlePlayer.Team.GetComponent<TeamGroupComponent>());
            }

            return effect;
        }
    }
}
