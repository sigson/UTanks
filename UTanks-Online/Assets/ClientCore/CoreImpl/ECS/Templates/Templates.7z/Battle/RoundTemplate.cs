using System;
using UTanksServer.Core.Protocol;
using UTanksServer.ECS.ECSCore;
using UTanksServer.ECS.Components.Battle;
using UTanksServer.ECS.Components.Battle.Round;
using UTanksServer.ECS.Components.Battle.Time;

namespace UTanksServer.ECS.Templates.Battle
{
    [TypeUid(1429256309752)]
    public class RoundTemplate : IEntityTemplate
    {
        public static ECSEntity CreateEntity(ECSEntity battle)
        {
            return new ECSEntity(new TemplateAccessor(new RoundTemplate(), null),
                new RoundComponent(),
                new BattleGroupComponent(battle),

                // WarmingUpTimerSystem
                new RoundStopTimeComponent(DateTimeOffset.UtcNow.AddSeconds(40)),
                new RoundActiveStateComponent()
            );
        }
    }
}
