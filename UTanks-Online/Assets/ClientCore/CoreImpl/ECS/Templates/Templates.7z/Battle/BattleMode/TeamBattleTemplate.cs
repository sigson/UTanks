﻿using UTanksServer.ECS.ECSCore;
using UTanksServer.ECS.Components.Battle.Team;

namespace UTanksServer.ECS.Templates.Battle
{
    public abstract class TeamBattleTemplate : BattleTemplate
    {
        protected static new ECSEntity CreateEntity(ECSEntity battleLobby, BattleTemplate template, string modeName, int scoreLimit, int timeLimit, int warmingUpTimeLimit)
        {
            ECSEntity entity = BattleTemplate.CreateEntity(battleLobby, template, modeName, scoreLimit, timeLimit, warmingUpTimeLimit);
            entity.Components.Add(new TeamBattleComponent());

            return entity;
        }
    }
}