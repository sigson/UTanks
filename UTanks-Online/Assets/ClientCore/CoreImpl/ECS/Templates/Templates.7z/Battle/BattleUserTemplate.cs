﻿using UTanksServer.Core;
using UTanksServer.Core.Protocol;
using UTanksServer.ECS.ECSCore;
using UTanksServer.ECS.Components;
using UTanksServer.ECS.Components.Battle;
using UTanksServer.ECS.Components.Battle.Team;

namespace UTanksServer.ECS.Templates.Battle
{
    [TypeUid(-2043703779834243389)]
    public class BattleUserTemplate : IEntityTemplate
    {
        private static ECSEntity CreateEntity(Player player, ECSEntity battle)
        {
            return new ECSEntity(new TemplateAccessor(new BattleUserTemplate(), "battle/battleuser"),
                player.User.GetComponent<UserGroupComponent>(),
                battle.GetComponent<BattleGroupComponent>(),
                new BattleUserComponent());
        }

        public static ECSEntity CreateEntity(Player player, ECSEntity battle, ECSEntity team)
        {
            ECSEntity entity = CreateEntity(player, battle);

            entity.Components.Add(new UserInBattleAsTankComponent());

            if (team != null)
                entity.Components.Add(team.GetComponent<TeamGroupComponent>());


            return entity;
        }

        public static ECSEntity CreateSpectatorEntity(Player player, ECSEntity battle)
        {
            ECSEntity entity = CreateEntity(player, battle);
            entity.Components.Add(new UserInBattleAsSpectatorComponent(battle.EntityId));
            return entity;
        }
    }
}
