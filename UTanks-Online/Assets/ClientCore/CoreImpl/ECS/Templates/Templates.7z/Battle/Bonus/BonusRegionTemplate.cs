﻿using System.Numerics;
using UTanksServer.Core.Protocol;
using UTanksServer.ECS.ECSCore;
using UTanksServer.ECS.Components.Battle.Bonus;
using UTanksServer.ECS.Types;

namespace UTanksServer.ECS.Templates.Battle.Bonus
{
    [TypeUid(8116072916726390829L)]
    public class BonusRegionTemplate : IEntityTemplate
    {
        public static ECSEntity CreateEntity(BonusType bonusType, Vector3 position)
        {
            ECSEntity entity = new ECSEntity(new TemplateAccessor(new BonusRegionTemplate(), "battle/bonus/region"),
                new BonusRegionComponent(bonusType),
                new SpatialGeometryComponent(position, new Vector3(0, 0, 0))
            );
            entity.Components.Add(new BonusRegionGroupComponent(entity));

            if (bonusType != BonusType.GOLD)
                entity.Components.Add(new SupplyBonusRegionComponent());
            else
            {
                entity.Components.Add(new GoldBonusRegionComponent());
                entity.Components.Add(new BonusComponent());
            }

            return entity;
        }
    }
}
