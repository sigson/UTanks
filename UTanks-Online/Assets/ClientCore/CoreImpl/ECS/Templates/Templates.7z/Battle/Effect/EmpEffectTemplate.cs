﻿using UTanksServer.Core.Battles;
using UTanksServer.Core.Protocol;
using UTanksServer.ECS.ECSCore;
using UTanksServer.ECS.Components.Battle.Effect;
using UTanksServer.ECS.Components.Battle.Effect.EMP;

namespace UTanksServer.ECS.Templates.Battle.Effect
{
    [TypeUid(636250001674528714L)]
    public class EmpEffectTemplate : EffectBaseTemplate
    {
        public static ECSEntity CreateEntity(MatchPlayer matchPlayer, float radius)
        {
            ECSEntity effect = CreateEntity(new EmpEffectTemplate(), "/battle/effect/emp", matchPlayer, addTeam: true);

            effect.AddComponent(new EMPEffectComponent(radius));

            return effect;
        }
    }
}
