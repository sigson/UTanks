﻿using UTanksServer.Core.Protocol;
using UTanksServer.ECS.ECSCore;
using UTanksServer.ECS.Components.Battle.Incarnation;
using UTanksServer.ECS.Components.Battle.Tank;

namespace UTanksServer.ECS.Templates.Battle.Tank
{
    [TypeUid(1478091203635)]
    public class TankIncarnationTemplate : IEntityTemplate
    {
        public static ECSEntity CreateEntity(ECSEntity tank)
        {
            return new ECSEntity(new TemplateAccessor(new TankIncarnationTemplate(), null),
                new TankIncarnationComponent(),
                new TankGroupComponent(tank),
                new TankIncarnationKillStatisticsComponent());
        }
    }
}
