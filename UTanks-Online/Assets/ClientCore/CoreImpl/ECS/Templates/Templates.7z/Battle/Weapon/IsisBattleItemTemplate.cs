﻿using UTanksServer.Core.Battles;
using UTanksServer.Core.Configuration;
using UTanksServer.Core.Protocol;
using UTanksServer.ECS.ECSCore;
using UTanksServer.ECS.Components.Battle.Weapon;
using UTanksServer.ECS.Templates.Battle.Weapon;

namespace UTanksServer.ECS.Templates.Battle
{
    [TypeUid(3413384256910001471L)]
    public class IsisBattleItemTemplate : StreamWeaponTemplate
    {
        public static ECSEntity CreateEntity(ECSEntity tank, BattleTankPlayer battlePlayer)
        {
            ECSEntity entity = CreateEntity(new IsisBattleItemTemplate(), "garage/weapon/isis", tank, battlePlayer);
            entity.Components.Add(new IsisComponent());
            entity.Components.Add(Config.GetComponent<StreamHitConfigComponent>("battle/weapon/isis"));

            return entity;
        }
    }
}
