using System.Numerics;
using UTanksServer.Core.Battles;
using UTanksServer.Core.Protocol;
using UTanksServer.ECS.ECSCore;
using UTanksServer.ECS.Components;
using UTanksServer.ECS.Components.Battle;
using UTanksServer.ECS.Components.Battle.Effect;
using UTanksServer.ECS.Components.Battle.Effect.Mine;
using UTanksServer.ECS.Components.Battle.Effect.Unit;
using UTanksServer.ECS.Components.Battle.Tank;
using UTanksServer.ECS.Components.Battle.Weapon;

namespace UTanksServer.ECS.Templates.Battle.Effect
{
    [TypeUid(1485337553359L)]
    public class SpiderEffectTemplate : EffectBaseTemplate
    {
        public static ECSEntity CreateEntity(MatchPlayer matchPlayer, float acceleration, long activationTime,
            float beginHideDistance, float hideRange, float impact, float damageMaxRadius, float damageMinRadius,
            float damageMinPercent, float speed, float targetingDistance, float targetingPeriod)
        {
            ECSEntity effect = CreateEntity(new SpiderEffectTemplate(), "/battle/effect/spidermine", matchPlayer, addTeam:true);
            effect.Components.UnionWith(new Component[]
            {
                new EffectActiveComponent(),

                new MineConfigComponent(activationTime: activationTime,
                    beginHideDistance: beginHideDistance, hideRange: hideRange, impact: impact),
                new SpiderMineConfigComponent(acceleration, speed),

                new SplashWeaponComponent(damageMinPercent, damageMaxRadius, damageMinRadius),

                new UnitComponent(),
                new UnitMoveComponent(new Movement(matchPlayer.TankPosition, Vector3.Zero, Vector3.Zero,
                    matchPlayer.TankQuaternion)),
                new UnitTargetingConfigComponent(targetingPeriod, targetingDistance),

                matchPlayer.Battle.BattleEntity.GetComponent<BattleGroupComponent>(),
                matchPlayer.Player.User.GetComponent<UserGroupComponent>()
            });

            return effect;
        }
    }
}
