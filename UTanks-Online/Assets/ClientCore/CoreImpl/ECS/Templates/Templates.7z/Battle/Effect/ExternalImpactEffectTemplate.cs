﻿using UTanksServer.Core.Battles;
using UTanksServer.Core.Protocol;
using UTanksServer.ECS.ECSCore;
using UTanksServer.ECS.Components.Battle;
using UTanksServer.ECS.Components.Battle.Effect;
using UTanksServer.ECS.Components.Battle.Effect.ExternalImpact;
using UTanksServer.ECS.Components.Battle.Weapon;

namespace UTanksServer.ECS.Templates.Battle.Effect
{
    [TypeUid(1542270967570L)]
    public class ExternalImpactEffectTemplate : EffectBaseTemplate
    {
        public static ECSEntity CreateEntity(float damageMinPercent, bool friendlyFire, float impact, float splashRadius,
            MatchPlayer matchPlayer)
        {
            ECSEntity effect = CreateEntity(new ExternalImpactEffectTemplate(), "battle/effect/externalimpact", matchPlayer);

            effect.AddComponent(matchPlayer.Battle.BattleEntity.GetComponent<BattleGroupComponent>());
            effect.AddComponent(new ExternalImpactEffectComponent());

            effect.AddComponent(new SplashEffectComponent(friendlyFire));
            effect.AddComponent(new SplashWeaponComponent(damageMinPercent, 0, splashRadius));
            effect.AddComponent(new SplashImpactComponent(impact));

            effect.AddComponent(new DamageWeakeningByDistanceComponent(damageMinPercent, 0, splashRadius));
            effect.AddComponent(new DiscreteWeaponComponent());

            return effect;
        }
    }
}
