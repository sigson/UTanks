﻿using UTanksServer.Core.Protocol;
using UTanksServer.ECS.ECSCore;
using UTanksServer.ECS.Components;
using UTanksServer.ECS.Components.Battle;
using UTanksServer.ECS.Components.Battle.Team;
using UTanksServer.ECS.Types;

namespace UTanksServer.ECS.Templates.Battle
{
    [TypeUid(1429761302402)]
    public class TeamTemplate : IEntityTemplate
    {
        public static ECSEntity CreateEntity(TeamColor color, ECSEntity battle)
        {
            ECSEntity entity = new ECSEntity(new TemplateAccessor(new TeamTemplate(), null),
                new TeamComponent(),
                new TeamColorComponent(color),
                battle.GetComponent<BattleGroupComponent>(),
                new TeamScoreComponent()
            );
            entity.Components.Add(new TeamGroupComponent(entity));

            return entity;
        }
    }
}
