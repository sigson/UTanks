﻿using UTanksServer.Core.Battles;
using UTanksServer.Core.Protocol;
using UTanksServer.ECS.ECSCore;
using UTanksServer.ECS.Components.Battle.Weapon;
using UTanksServer.ECS.Templates.Battle.Weapon;

namespace UTanksServer.ECS.Templates.Battle
{
    [TypeUid(-8939173357737272930L)]
    public class RicochetBattleItemTemplate : DiscreteWeaponTemplate
    {
        public static ECSEntity CreateEntity(ECSEntity tank, BattleTankPlayer battlePlayer)
        {
            ECSEntity entity = CreateEntity(new RicochetBattleItemTemplate(), "garage/weapon/ricochet", tank, battlePlayer);
            entity.Components.Add(new RicochetComponent());
            
            entity.Components.Add(battlePlayer.BulletSpeed == null
                ? new WeaponBulletShotComponent(0.5f, 110f)
                : new WeaponBulletShotComponent(0.5f, (float) battlePlayer.BulletSpeed));

            return entity;
        }
    }
}
