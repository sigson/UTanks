﻿using UTanksServer.Core.Battles;
using UTanksServer.Core.Protocol;
using UTanksServer.ECS.ECSCore;
using UTanksServer.ECS.Components.Battle.Weapon;
using UTanksServer.ECS.Templates.Battle.Weapon;

namespace UTanksServer.ECS.Templates.Battle
{
    [TypeUid(-6419489500262573655L)]
    public class RailgunBattleItemTemplate : DiscreteWeaponTemplate
    {
        public static ECSEntity CreateEntity(ECSEntity tank, BattleTankPlayer battlePlayer)
        {
            ECSEntity entity = CreateEntity(new RailgunBattleItemTemplate(), "garage/weapon/railgun", tank, battlePlayer);
            entity.Components.Add(new RailgunComponent());
            
            entity.Components.Add(battlePlayer.TurretUnloadEnergyPerShot == null
                ? new RailgunChargingWeaponComponent(1f)
                : new RailgunChargingWeaponComponent((float) battlePlayer.TurretUnloadEnergyPerShot));

            return entity;
        }
    }
}
