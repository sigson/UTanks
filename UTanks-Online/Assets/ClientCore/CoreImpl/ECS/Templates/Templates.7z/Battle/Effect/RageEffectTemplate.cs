using UTanksServer.Core.Battles;
using UTanksServer.Core.Protocol;
using UTanksServer.ECS.ECSCore;
using UTanksServer.ECS.Components.Battle.Effect.Rage;

namespace UTanksServer.ECS.Templates.Battle.Effect
{
    [TypeUid(636364997672415488L)]
    public class RageEffectTemplate : EffectBaseTemplate
    {
        public static ECSEntity CreateEntity(int decreaseCooldownPerKillMs, MatchPlayer matchPlayer)
        {
            ECSEntity effect = CreateEntity(new RageEffectTemplate(), "battle/effect/rage", matchPlayer);
            effect.AddComponent(new RageEffectComponent(decreaseCooldownPerKillMs));

            return effect;
        }
    }
}
