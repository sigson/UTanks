﻿using UTanksServer.Core.Protocol;
using UTanksServer.ECS.ECSCore;

namespace UTanksServer.ECS.Templates.Battle.Bonus
{
	[TypeUid(636403852024917041L)]
	public class GoldBonusWithCrystalsTemplate : GoldBonusTemplate
	{
	}
}
