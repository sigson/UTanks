using UTanksServer.ECS.ECSCore;
using UTanksServer.ECS.Components;
using UTanksServer.ECS.Components.Battle;
using UTanksServer.ECS.Components.Battle.Time;
using System;

namespace UTanksServer.ECS.Templates.Battle
{
    public abstract class BattleTemplate : IEntityTemplate
    {
		protected static ECSEntity CreateEntity(ECSEntity battleLobby, BattleTemplate template, string modeName,
            int scoreLimit, int timeLimit, int warmingUpTimeLimit)
		{
			UserLimitComponent userLimitComponent = battleLobby.GetComponent<UserLimitComponent>();

			ECSEntity entity = new(new TemplateAccessor(template, "battle/modes/" + modeName),
				new ScoreLimitComponent(scoreLimit),
				new TimeLimitComponent(timeLimit, warmingUpTimeLimit),
				new BattleStartTimeComponent(new DateTimeOffset(DateTime.UtcNow)),
				userLimitComponent,
				battleLobby.GetComponent<MapGroupComponent>(),
				battleLobby.GetComponent<GravityComponent>(),
				battleLobby.GetComponent<BattleModeComponent>(),
				new BattleConfiguratedComponent(),
				new VisibleItemComponent(),
				new UserCountComponent(userLimitComponent.UserLimit),
				new BattleComponent(),
				new BattleTankCollisionsComponent());
			entity.Components.Add(new BattleGroupComponent(entity));

			return entity;
		}
	}
}
