using UTanksServer.Core.Battles;
using UTanksServer.Core.Configuration;
using UTanksServer.Core.Protocol;
using UTanksServer.ECS.ECSCore;
using UTanksServer.ECS.Components.Battle.Weapon;

namespace UTanksServer.ECS.Templates.Battle
{
    [TypeUid(-3936735916503799349L)]
    public class VulcanBattleItemTemplate : WeaponTemplate
    {
        private const string ConfigPath = "garage/weapon/vulcan";

        public static ECSEntity CreateEntity(ECSEntity tank, BattleTankPlayer battlePlayer)
        {
            ECSEntity entity = CreateEntity(new VulcanBattleItemTemplate(), ConfigPath, tank, battlePlayer);

            entity.Components.UnionWith(new Component[]
            {
                Config.GetComponent<VulcanWeaponComponent>(ConfigPath),
                Config.GetComponent<KickbackComponent>(ConfigPath),
                Config.GetComponent<ImpactComponent>(ConfigPath),
                Config.GetComponent<StreamHitConfigComponent>("battle/weapon/vulcan"),
                new VulcanComponent(),
                new StreamWeaponComponent()
            });

            return entity;
        }
    }
}
