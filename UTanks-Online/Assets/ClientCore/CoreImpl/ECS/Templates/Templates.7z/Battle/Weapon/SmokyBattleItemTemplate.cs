﻿using UTanksServer.Core.Battles;
using UTanksServer.Core.Protocol;
using UTanksServer.ECS.ECSCore;
using UTanksServer.ECS.Components.Battle.Weapon;
using UTanksServer.ECS.Templates.Battle.Weapon;

namespace UTanksServer.ECS.Templates.Battle
{
    [TypeUid(-2434344547754767853L)]
    public class SmokyBattleItemTemplate : DiscreteWeaponTemplate
    {
        public static ECSEntity CreateEntity(ECSEntity tank, BattleTankPlayer battlePlayer)
        {
            ECSEntity entity = CreateEntity(new SmokyBattleItemTemplate(), "garage/weapon/smoky", tank, battlePlayer);
            entity.Components.Add(new SmokyComponent());

            return entity;
        }
    }
}
