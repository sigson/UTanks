﻿using UTanksServer.Core.Battles;
using UTanksServer.Core.Protocol;
using UTanksServer.ECS.ECSCore;

namespace UTanksServer.ECS.Templates.Battle.Effect
{
	[TypeUid(636222384398205627L)]
	public class InvisibilityEffectTemplate : EffectBaseTemplate
    {
        private static readonly string _configPath = "/battle/effect/invisibility";

		public static ECSEntity CreateEntity(MatchPlayer matchPlayer) =>
            CreateEntity(new InvisibilityEffectTemplate(), _configPath, matchPlayer, 6000);
    }
}
