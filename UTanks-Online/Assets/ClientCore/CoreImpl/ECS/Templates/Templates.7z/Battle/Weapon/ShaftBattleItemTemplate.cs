﻿using UTanksServer.Core.Battles;
using UTanksServer.Core.Configuration;
using UTanksServer.Core.Protocol;
using UTanksServer.ECS.ECSCore;
using UTanksServer.ECS.Components.Battle.Weapon;

namespace UTanksServer.ECS.Templates.Battle.Weapon
{
    [TypeUid(-2537616944465628484L)]
    public class ShaftBattleItemTemplate : DiscreteWeaponTemplate
    {
        private const string GarageWeaponConfig = "garage/weapon/shaft";

        public static ECSEntity CreateEntity(ECSEntity tank, BattleTankPlayer battlePlayer)
        {
            ECSEntity entity = CreateEntity(new ShaftBattleItemTemplate(), GarageWeaponConfig, tank, battlePlayer);
            entity.Components.UnionWith(new Component[]
            {
                new ShaftComponent(),
                Config.GetComponent<ShaftAimingImpactComponent>(GarageWeaponConfig),
                Config.GetComponent<ShaftAimingSpeedComponent>(GarageWeaponConfig),
                new ShaftEnergyComponent(0.2857f, 1, 0.2f, 0.143f),
                Config.GetComponent<ShaftStateConfigComponent>("battle/weapon/shaft")
            });

            return entity;
        }
    }
}
