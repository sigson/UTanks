﻿using System;
using System.Numerics;
using UTanksServer.Core.Protocol;
using UTanksServer.ECS.ECSCore;
using UTanksServer.ECS.Components.Battle;
using UTanksServer.ECS.Components.Battle.Bonus;
using UTanksServer.ECS.Components.Battle.Location;

namespace UTanksServer.ECS.Templates.Battle.Bonus
{
	[TypeUid(-8402520789413485183L)]
	public class GoldBonusTemplate : BonusTemplate
	{
        public static ECSEntity CreateEntity(ECSEntity bonusRegion, Vector3 position, ECSEntity battleEntity)
        {
            ECSEntity bonus = CreateEntity(new GoldBonusTemplate(), "battle/bonus/gold/cry", bonusRegion,
                position, battleEntity);
            bonus.AddComponent(bonusRegion.GetComponent<GoldBonusRegionComponent>());

            return bonus;
        }
    }
}
