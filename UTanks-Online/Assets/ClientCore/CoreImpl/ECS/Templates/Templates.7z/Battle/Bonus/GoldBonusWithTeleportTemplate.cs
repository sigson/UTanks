﻿using UTanksServer.Core.Protocol;
using UTanksServer.ECS.ECSCore;

namespace UTanksServer.ECS.Templates.Battle.Bonus
{
	[TypeUid(636404649605276028L)]
	public class GoldBonusWithTeleportTemplate : GoldBonusTemplate
	{
        // not in use anymore
	}
}
