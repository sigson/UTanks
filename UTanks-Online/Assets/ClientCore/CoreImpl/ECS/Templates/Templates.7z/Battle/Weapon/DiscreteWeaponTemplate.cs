using System.Linq;
using UTanksServer.Core.Battles;
using UTanksServer.Core.Configuration;
using UTanksServer.Core.Protocol;
using UTanksServer.ECS.ECSCore;
using UTanksServer.ECS.Components.Battle.Weapon;

namespace UTanksServer.ECS.Templates.Battle.Weapon
{
    [TypeUid(-1716200834009238305L)]
    public class DiscreteWeaponTemplate : WeaponTemplate
    {
        protected new static ECSEntity CreateEntity(WeaponTemplate template, string configPath, ECSEntity tank, BattleTankPlayer battlePlayer)
        {
            ECSEntity entity = WeaponTemplate.CreateEntity(template, configPath, tank, battlePlayer);

            entity.Components.UnionWith(new Component[] {
                Config.GetComponent<ImpactComponent>(configPath),
                new DiscreteWeaponComponent(),
                Config.GetComponent<DamageWeakeningByDistanceComponent>(configPath, false),
                battlePlayer.TurretKickback == null
                    ? Config.GetComponent<KickbackComponent>(configPath)
                    : new KickbackComponent((float)battlePlayer.TurretKickback),
            }.Where(x => x != null));

            if (template.GetType() != typeof(ShaftBattleItemTemplate))
            {
                entity.AddComponent(battlePlayer.TurretUnloadEnergyPerShot == null
                    ? Config.GetComponent<DiscreteWeaponEnergyComponent>(configPath)
                    : new DiscreteWeaponEnergyComponent(1, (float) battlePlayer.TurretUnloadEnergyPerShot));
            }

            return entity;
        }
    }
}
