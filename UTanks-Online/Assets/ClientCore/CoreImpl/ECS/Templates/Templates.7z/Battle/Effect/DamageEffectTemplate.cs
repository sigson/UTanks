using UTanksServer.Core.Battles;
using UTanksServer.Core.Protocol;
using UTanksServer.ECS.ECSCore;

namespace UTanksServer.ECS.Templates.Battle.Effect
{
    [TypeUid(1486018791920L)]
    public class DamageEffectTemplate : EffectBaseTemplate
    {
        public static ECSEntity CreateEntity(MatchPlayer matchPlayer, long duration) =>
            CreateEntity(new DamageEffectTemplate(), "battle/effect/damage", matchPlayer, duration);
    }
}
