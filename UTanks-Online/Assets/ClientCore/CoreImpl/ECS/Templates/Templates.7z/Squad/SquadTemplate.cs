﻿using UTanksServer.Core.Protocol;
using UTanksServer.ECS.ECSCore;
using UTanksServer.ECS.Components.Groups;


namespace UTanksServer.ECS.Templates.Squad
{
    [TypeUid(1507120664314L)]
    public class SquadTemplate : IEntityTemplate
    {
        public static ECSEntity CreateEntity()
        {
            ECSEntity entity = new(new TemplateAccessor(new SquadTemplate(), "squad"));
            entity.AddComponent(new SquadGroupComponent(entity));
            return entity;
        }
    }
}