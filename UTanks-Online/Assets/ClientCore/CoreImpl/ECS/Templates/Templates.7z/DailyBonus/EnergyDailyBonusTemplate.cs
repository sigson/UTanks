﻿using UTanksServer.Core.Protocol;
using UTanksServer.ECS.ECSCore;

namespace UTanksServer.ECS.Templates
{
    [TypeUid(1504269596164)]
    public class EnergyDailyBonusTemplate : IEntityTemplate { }
}
