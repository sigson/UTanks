﻿using UTanksServer.Core.Protocol;
using UTanksServer.ECS.ECSCore;

namespace UTanksServer.ECS.Templates
{
    [TypeUid(1518618270341L)]
	public class MoneyDailyBonusTemplate : IEntityTemplate
	{
	}
}
