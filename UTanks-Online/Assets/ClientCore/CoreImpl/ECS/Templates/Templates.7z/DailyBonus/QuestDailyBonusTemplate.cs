﻿using UTanksServer.Core.Protocol;
using UTanksServer.ECS.ECSCore;

namespace UTanksServer.ECS.Templates
{
    [TypeUid(1513768369538L)]
	public class QuestDailyBonusTemplate : IEntityTemplate
	{
	}
}
