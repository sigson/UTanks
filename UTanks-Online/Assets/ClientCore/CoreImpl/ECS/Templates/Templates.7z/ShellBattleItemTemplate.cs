﻿using UTanksServer.Core.Protocol;
using UTanksServer.ECS.ECSCore;
using UTanksServer.ECS.Components;
using UTanksServer.ECS.Components.Battle;
using UTanksServer.ECS.Components.Battle.Tank;

namespace UTanksServer.ECS.Templates
{
    [TypeUid(-5342270968507348251)]
    public class ShellBattleItemTemplate : IEntityTemplate
    {
        public static ECSEntity CreateEntity(ECSEntity userItem, ECSEntity tank)
        {
            return new ECSEntity(new TemplateAccessor(new ShellBattleItemTemplate(), userItem.TemplateAccessor.ConfigPath),
                new ShellBattleItemComponent(),
                tank.GetComponent<UserGroupComponent>(),
                tank.GetComponent<BattleGroupComponent>(),
                tank.GetComponent<TankGroupComponent>(),
                userItem.GetComponent<MarketItemGroupComponent>());
        }
    }
}