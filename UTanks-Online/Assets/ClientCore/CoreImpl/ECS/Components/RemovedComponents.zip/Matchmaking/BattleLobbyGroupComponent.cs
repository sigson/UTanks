﻿using UTanksServer.Core.Protocol;
using UTanksServer.ECS.ECSCore;

namespace UTanksServer.ECS.Components
{
    [TypeUid(1496052424091)]
    public class BattleLobbyGroupComponent : GroupComponent
    {
        public BattleLobbyGroupComponent(Entity entity) : base(entity)
        {
            
        }

        public BattleLobbyGroupComponent(long Key) : base(Key)
        {
        }
    }
}