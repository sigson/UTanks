﻿using UTanksServer.Core.Protocol;
using UTanksServer.ECS.ECSCore;
using UTanksServer.ECS.Types;

namespace UTanksServer.ECS.Components
{
    [TypeUid(1435652501758)]
    public class GravityComponent : ECSComponent
    {
        public GravityComponent(float gravity, GravityType gravityType)
        {
            Gravity = gravity;
            GravityType = gravityType;
        }
        
        public float Gravity { get; set; }
        
        public GravityType GravityType { get; set; }
    }
}