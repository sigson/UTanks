﻿using UTanksServer.Core.Protocol;
using UTanksServer.ECS.ECSCore;
using UTanksServer.ECS.Types;

namespace UTanksServer.ECS.Components
{
    [TypeUid(6258344835131144773)]
    public class TeamColorComponent : ECSComponent
    {
        public TeamColorComponent(TeamColor color)
        {
            TeamColor = color;
        }
        
        public TeamColor TeamColor { get; set; }
    }
}