﻿using UTanksServer.Core.Protocol;
using UTanksServer.ECS.ECSCore;

namespace UTanksServer.ECS.Components
{
    [TypeUid(1497442440245)]
    public class MatchMakingUserReadyComponent : ECSComponent
    {

    }
}