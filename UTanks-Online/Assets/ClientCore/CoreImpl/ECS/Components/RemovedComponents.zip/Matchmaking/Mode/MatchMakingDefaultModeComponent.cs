﻿using UTanksServer.Core.Protocol;
using UTanksServer.ECS.ECSCore;

namespace UTanksServer.ECS.Components
{
    [TypeUid(1499242904641L)]
    public class MatchMakingDefaultModeComponent : ECSComponent
    {
        public int MinimalBattles { get; set; } = 0;
    }
}
