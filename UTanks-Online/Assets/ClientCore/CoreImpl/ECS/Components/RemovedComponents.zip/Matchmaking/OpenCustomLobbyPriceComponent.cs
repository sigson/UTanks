﻿using UTanksServer.Core.Protocol;
using UTanksServer.ECS.ECSCore;
using UTanksServer.ECS.Types;

namespace UTanksServer.ECS.Components
{
    [TypeUid(1548677305789L)]
    public class OpenCustomLobbyPriceComponent : ECSComponent
    {
        public OpenCustomLobbyPriceComponent(long openPrice)
        {
            this.OpenPrice = openPrice;
        }

        public long OpenPrice { get; set; }
    }
}