﻿using UTanksServer.Core.Protocol;
using UTanksServer.ECS.ECSCore;

namespace UTanksServer.ECS.Components
{
    [TypeUid(1498810443225)]
    public class MatchMakingUserComponent : ECSComponent
    {
        
    }
}