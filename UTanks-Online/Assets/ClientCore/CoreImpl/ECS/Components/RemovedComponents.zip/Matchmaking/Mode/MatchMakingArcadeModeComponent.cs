﻿using UTanksServer.Core.Protocol;
using UTanksServer.ECS.ECSCore;

namespace UTanksServer.ECS.Components
{
    [TypeUid(1504155281802L)]
    public class MatchMakingArcadeModeComponent : ECSComponent
    {
    }
}
