﻿using UTanksServer.Core.Protocol;
using UTanksServer.ECS.ECSCore;

namespace UTanksServer.ECS.Components
{
    [TypeUid(3911401339075883957)]
    public class UserLimitComponent : ECSComponent
    {
        public UserLimitComponent(int userLimit, int teamLimit)
        {
            UserLimit = userLimit;
            TeamLimit = teamLimit;
        }
        
        public int UserLimit { get; set; }
        
        public int TeamLimit { get; set; }
    }
}