﻿using System;
using UTanksServer.Core.Protocol;
using UTanksServer.ECS.ECSCore;

namespace UTanksServer.ECS.Components
{
    [TypeUid(1496833452921)]
    public class MatchMakingLobbyStartTimeComponent : ECSComponent
    {
        public DateTime StartTime { get; set; }
    }
}