﻿using UTanksServer.Core.Protocol;
using UTanksServer.ECS.ECSCore;
using UTanksServer.ECS.Types;

namespace UTanksServer.ECS.Components
{
    [TypeUid(1432624073184)]
    public class BattleModeComponent : ECSComponent
    {
        public BattleModeComponent(BattleMode mode)
        {
            BattleMode = mode;
        }
        
        public BattleMode BattleMode { get; set; }
    }
}