﻿using UTanksServer.Core;
using UTanksServer.Core.Protocol;
using UTanksServer.ECS.ECSCore;
using UTanksServer.ECS.Types;
using System;

namespace UTanksServer.ECS.Components
{
    [TypeUid(1498569137147L)]
    public class ClientBattleParamsComponent : ECSComponent
    {
        public ClientBattleParamsComponent(ClientBattleParams customParams)
        {
            Params = customParams;
        }
        public ClientBattleParams Params { get; set; }
    }
}
