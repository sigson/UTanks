﻿using UTanksServer.Core.Protocol;
using UTanksServer.ECS.ECSCore;

namespace UTanksServer.ECS.Components
{
    [TypeUid(1496751204302L)]
    public class CustomBattleLobbyComponent : ECSComponent
    {
    }
}
