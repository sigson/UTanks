﻿using UTanksServer.Core.Protocol;
using UTanksServer.ECS.ECSCore;

namespace UTanksServer.ECS.Components.Matchmaking.Mode
{
    [TypeUid(1503396723788L)]
    public class MatchMakingRatingModeComponent : ECSComponent
    {
    }
}
