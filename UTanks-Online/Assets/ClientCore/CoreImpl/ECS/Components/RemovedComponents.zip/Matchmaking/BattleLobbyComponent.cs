﻿using UTanksServer.Core.Protocol;
using UTanksServer.ECS.ECSCore;

namespace UTanksServer.ECS.Components
{
    [TypeUid(1498460800928)]
    public class BattleLobbyComponent : ECSComponent
    {
        
    }
}