﻿using UTanksServer.Core.Protocol;
using UTanksServer.ECS.ECSCore;

namespace UTanksServer.ECS.Components
{
    [TypeUid(1547721316362L)]
    public class OpenToConnectLobbyComponent : ECSComponent
    {
    }
}