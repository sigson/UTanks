using UTanksServer.Core.Protocol;
using UTanksServer.ECS.ECSCore;

namespace UTanksServer.ECS.Components.Matchmaking.Mode
{
    [TypeUid(1509682826874L)]
    public class MatchMakingTrainingModeComponent : ECSComponent
    {
    }
}
