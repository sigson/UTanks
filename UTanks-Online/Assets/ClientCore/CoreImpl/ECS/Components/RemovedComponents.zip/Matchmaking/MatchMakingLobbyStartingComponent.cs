﻿using UTanksServer.Core.Protocol;
using UTanksServer.ECS.ECSCore;

namespace UTanksServer.ECS.Components
{
    [TypeUid(1499773899867)]
    public class MatchMakingLobbyStartingComponent : ECSComponent
    {
        
    }
}