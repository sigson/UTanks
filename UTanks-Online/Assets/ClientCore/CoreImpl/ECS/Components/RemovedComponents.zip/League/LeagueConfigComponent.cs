﻿using UTanksServer.Core.Protocol;
using UTanksServer.ECS.ECSCore;

namespace UTanksServer.ECS.Components
{
    [TypeUid(1502713060357L)]
	public class LeagueConfigComponent : ECSComponent
	{
		public LeagueConfigComponent(int leagueIndex, double reputationToEnter)
		{
			LeagueIndex = leagueIndex;
            ReputationToEnter = reputationToEnter;
        }

		public int LeagueIndex { get; set; }

		public double ReputationToEnter { get; set; } = 0;
	}
}
