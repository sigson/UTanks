using System;
using UTanksServer.Core.Protocol;
using UTanksServer.ECS.ECSCore;

namespace UTanksServer.ECS.Components
{
    [TypeUid(1505728594733L)]
    public class SeasonEndDateComponent : ECSComponent
    {
        [OptionalMapped]
        public DateTime EndDate { get; set; } = DateTime.UtcNow.AddHours(6);
    }
}
