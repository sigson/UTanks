﻿using UTanksServer.Core.Protocol;
using UTanksServer.ECS.ECSCore;

namespace UTanksServer.ECS.Components
{
    [TypeUid(1508823738925L)]
    public class CurrentSeasonNumberComponent : ECSComponent
    {
        public int SeasonNumber { get; set; } = 0;
    }
}
