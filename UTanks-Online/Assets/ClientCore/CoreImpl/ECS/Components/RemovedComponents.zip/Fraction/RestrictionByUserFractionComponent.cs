﻿using UTanksServer.Core.Protocol;
using UTanksServer.ECS.ECSCore;

namespace UTanksServer.ECS.Components
{
    [TypeUid(1544956558339)]
    public class RestrictionByUserFractionComponent : ECSComponent
    {
        public long FractionId { get; set; }
    }
}
