using UTanksServer.Core.Protocol;
using UTanksServer.ECS.ECSCore;

namespace UTanksServer.ECS.Components.Fraction
{
    [TypeUid(1545106623033L)]
    public class FractionInvolvedInCompetitionComponent : ECSComponent
    {
        public FractionInvolvedInCompetitionComponent(long userCount)
        {
            UserCount = userCount;
        }

        public long UserCount { get; set; }
    }
}
