﻿using UTanksServer.Core.Protocol;
using UTanksServer.ECS.ECSCore;

namespace UTanksServer.ECS.Components
{
    [TypeUid(1544499423535)]
    public class FractionComponent : ECSComponent
    {
        public FractionComponent(string FractionName)
        {
            this.FractionName = FractionName;
        }

        public string FractionName { get; set; }
    }
}
