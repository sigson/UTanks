﻿using UTanksServer.Core.Protocol;
using UTanksServer.ECS.ECSCore;

namespace UTanksServer.ECS.Components.Fraction
{
    [TypeUid(1545394828752)]
    public class FinishedFractionsCompetitionComponent : ECSComponent
    {
        public FinishedFractionsCompetitionComponent(long winner)
        {
            Winner = winner;
        }

        public long Winner { get; set; }
    }
}
