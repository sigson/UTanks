﻿using UTanksServer.Core.Protocol;
using UTanksServer.ECS.ECSCore;

namespace UTanksServer.ECS.Components
{
    [TypeUid(1544590059379)]
    public class FractionUserScoreComponent : ECSComponent
    {
        public FractionUserScoreComponent(long TotalEarnedPoints)
        {
            this.TotalEarnedPoints = TotalEarnedPoints;
        }

        public long TotalEarnedPoints { get; set; }
    }
}
