
using UTanksServer.ECS.ECSCore;

namespace UTanksServer.ECS.Components.Entrance {
  [TypeUid(1439808320725)]
  public class InviteComponent : ECSComponent {
    [ProtocolName("ShowScreenOnEntrance")] public bool ShowOnEntrance { get; set; }
    [ProtocolOptional] public string? InviteCode { get; set; }

    public InviteComponent(string? inviteCode = null, bool showOnEntrance = true) {
      ShowOnEntrance = showOnEntrance;
      InviteCode = inviteCode;
    }
  }
}
