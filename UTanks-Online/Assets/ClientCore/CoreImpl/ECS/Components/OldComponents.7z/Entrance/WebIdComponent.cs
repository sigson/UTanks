using UTanksServer.ECS.ECSCore;


namespace UTanksServer.ECS.Components.Entrance {
  [TypeUid(1479820450460)]
  public class WebIdComponent : ECSComponent {
    public string WebId { get; set; } = "";
    public string Utm { get; set; } = "";
    public string GoogleAnalyticsId { get; set; } = "";
    public string WebIdUid { get; set; } = "";
  }
}
