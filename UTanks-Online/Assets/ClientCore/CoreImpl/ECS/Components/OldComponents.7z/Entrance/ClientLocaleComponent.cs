using UTanksServer.ECS.ECSCore;


namespace UTanksServer.ECS.Components.Entrance {
  [TypeUid(1453796862447)]
  public class ClientLocaleComponent : ECSComponent {
    public string LocaleCode { get; set; }

    public ClientLocaleComponent(string localeCode) {
      LocaleCode = localeCode;
    }
  }
}
