using UTanksServer.ECS.ECSCore;


namespace UTanksServer.ECS.Components.Entrance {
  [TypeUid(8430454860460725282)]
  public class ClientSessionComponent : ECSComponent { }
}
