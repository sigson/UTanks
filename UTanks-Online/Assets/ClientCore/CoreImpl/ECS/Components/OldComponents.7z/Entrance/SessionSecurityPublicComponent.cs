using UTanksServer.ECS.ECSCore;


namespace UTanksServer.ECS.Components.Entrance {
  [TypeUid(1439792100478)]
  public class SessionSecurityPublicComponent : ECSComponent {
    public string PublicKey { get; set; }

    public SessionSecurityPublicComponent(string publicKey) {
      PublicKey = publicKey;
    }
  }
}
