using UTanksServer.ECS.ECSCore;


namespace UTanksServer.ECS.Components.Groups {
  [TypeUid(7453043498913563889)]
  public class UserGroupComponent : GroupComponent {
    public UserGroupComponent(ECSEntity entity) : base(entity) { }
    public UserGroupComponent(long key) : base(key) { }
  }
}
