//using UTanksServer.Protocol;

using UTanksServer.ECS.ECSCore;

namespace UTanksServer.ECS.Components.Groups {
  public abstract class GroupComponent : ECSComponent {
    [ServerOnlyData] public long Key { get; set; }
    [ServerOnlyData] public long TypeUid => TypeUidUtils.GetId(GetType());

    public GroupComponent(ECSEntity entity) : this(entity.Id) { }

    public GroupComponent(long key) {
      Key = key;
    }
  }
}
