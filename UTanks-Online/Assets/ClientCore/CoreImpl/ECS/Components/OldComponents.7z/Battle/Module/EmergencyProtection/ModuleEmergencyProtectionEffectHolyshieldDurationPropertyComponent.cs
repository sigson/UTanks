
using UTanksServer.ECS.ECSCore;

namespace UTanksServer.ECS.Components.Battle.Module.EmergencyProtection {
  [TypeUid(636362286701413474L)]
  public class ModuleEmergencyProtectionEffectHolyshieldDurationPropertyComponent : ModuleEffectUpgradablePropertyComponent { }
}
