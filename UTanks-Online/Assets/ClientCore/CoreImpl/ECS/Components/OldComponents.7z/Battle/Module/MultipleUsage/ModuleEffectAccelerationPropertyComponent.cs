﻿
using UTanksServer.ECS.ECSCore;

namespace UTanksServer.ECS.Components.Battle.Module.MultipleUsage {
  [TypeUid(636364868333117422L)]
  public class ModuleEffectAccelerationPropertyComponent : ModuleEffectUpgradablePropertyComponent { }
}
