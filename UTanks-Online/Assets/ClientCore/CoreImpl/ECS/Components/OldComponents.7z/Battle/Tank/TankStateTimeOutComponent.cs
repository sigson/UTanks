
using UTanksServer.ECS.ECSCore;

namespace UTanksServer.ECS.Components.Battle.Tank {
  [TypeUid(3330454646188163682L)]
  public class TankStateTimeOutComponent : ECSComponent { }
}
