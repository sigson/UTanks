
using UTanksServer.ECS.ECSCore;

namespace UTanksServer.ECS.Components.Battle.Weapon.Railgun {
  [TypeUid(2654416098660377118L)]
  public class RailgunChargingWeaponComponent : ECSComponent {
    public float ChargingTime { get; set; }

    public RailgunChargingWeaponComponent(float chargingTime) {
      ChargingTime = chargingTime;
    }
  }
}
