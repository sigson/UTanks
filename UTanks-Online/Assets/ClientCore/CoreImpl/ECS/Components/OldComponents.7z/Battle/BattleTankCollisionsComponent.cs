
using UTanksServer.ECS.ECSCore;

namespace UTanksServer.ECS.Components.Battle {
  [TypeUid(6549840349742289518L)]
  public class BattleTankCollisionsComponent : ECSComponent {
    public long SemiActiveCollisionsPhase { get; set; }
  }
}
