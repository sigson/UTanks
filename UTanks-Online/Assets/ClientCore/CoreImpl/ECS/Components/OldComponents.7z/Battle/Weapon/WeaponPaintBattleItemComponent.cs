
using UTanksServer.ECS.ECSCore;

namespace UTanksServer.ECS.Components.Battle.Weapon {
  [TypeUid(636287141304624351)]
  public class WeaponPaintBattleItemComponent : ECSComponent { }
}
