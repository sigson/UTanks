
using UTanksServer.ECS.ECSCore;

namespace UTanksServer.ECS.Components.Battle.Tank {
  [TypeUid(4349602566017552920L)]
  public class TankNewStateComponent : ECSComponent { }
}
