
using UTanksServer.ECS.ECSCore;

namespace UTanksServer.ECS.Components.Battle.Chassis {
  [TypeUid(1437571863912)]
  public class WeightComponent : ECSComponent {
    public float Weight { get; set; }

    public WeightComponent(float weight) {
      Weight = weight;
    }
  }
}
