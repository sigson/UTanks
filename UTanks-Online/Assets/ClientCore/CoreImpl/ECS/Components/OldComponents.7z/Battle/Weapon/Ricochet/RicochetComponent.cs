
using UTanksServer.ECS.ECSCore;

namespace UTanksServer.ECS.Components.Battle.Weapon.Ricochet {
  [TypeUid(2115384895595656627L)]
  public class RicochetComponent : ECSComponent { }
}
