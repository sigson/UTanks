
using UTanksServer.ECS.ECSCore;

namespace UTanksServer.ECS.Components.Battle.Weapon.Twins {
  [TypeUid(-7502402889350277618L)]
  public class TwinsComponent : ECSComponent { }
}
