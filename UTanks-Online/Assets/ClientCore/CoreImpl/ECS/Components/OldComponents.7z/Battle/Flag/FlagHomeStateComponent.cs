
using UTanksServer.ECS.ECSCore;

namespace UTanksServer.ECS.Components.Battle.Flag {
  [TypeUid(2149515032365065390L)]
  public class FlagHomeStateComponent : ECSComponent { }
}
