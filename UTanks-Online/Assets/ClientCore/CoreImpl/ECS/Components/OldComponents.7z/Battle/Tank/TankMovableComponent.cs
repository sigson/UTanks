
using UTanksServer.ECS.ECSCore;

namespace UTanksServer.ECS.Components.Battle.Tank {
  [TypeUid(5853281840501157320)]
  public class TankMovableComponent : ECSComponent { }
}
