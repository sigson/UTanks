using System.Numerics;


using UTanksServer.ECS.ECSCore;

namespace UTanksServer.ECS.Components.Battle.Effect.Mine {
  [TypeUid(1431673085710L)]
  public class MinePositionComponent : ECSComponent {
    public Vector3 Position { get; set; }

    public MinePositionComponent(Vector3 position) {
      Position = position;
    }
  }
}
