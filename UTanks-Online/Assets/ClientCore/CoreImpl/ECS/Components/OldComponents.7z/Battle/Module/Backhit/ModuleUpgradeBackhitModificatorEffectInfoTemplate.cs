
using UTanksServer.ECS.ECSCore;

namespace UTanksServer.ECS.Components.Battle.Module.Backhit {
  [TypeUid(636354482826717831L)]
  public class ModuleBackhitModificatorEffectPropertyComponent : ModuleEffectUpgradablePropertyComponent { }
}
