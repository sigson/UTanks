﻿
using UTanksServer.ECS.ECSCore;

namespace UTanksServer.ECS.Components.Battle.Module.Turbospeed {
  [TypeUid(636352853748645024L)]
  public class ModuleTurbospeedEffectPropertyComponent : ModuleEffectUpgradablePropertyComponent { }
}
