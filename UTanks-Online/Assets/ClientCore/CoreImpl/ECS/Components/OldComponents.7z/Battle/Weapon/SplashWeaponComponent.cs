
using UTanksServer.ECS.ECSCore;

namespace UTanksServer.ECS.Components.Battle.Weapon {
  [TypeUid(3169143415222756957L)]
  // TODO(Assasans): Document
  public class SplashWeaponComponent : ECSComponent {
    public float MinSplashDamagePercent { get; set; }

    public float RadiusOfMaxSplashDamage { get; set; }
    public float RadiusOfMinSplashDamage { get; set; }

    public SplashWeaponComponent(float minSplashDamagePercent, float radiusOfMaxSplashDamage, float radiusOfMinSplashDamage) {
      MinSplashDamagePercent = minSplashDamagePercent;
      RadiusOfMaxSplashDamage = radiusOfMaxSplashDamage;
      RadiusOfMinSplashDamage = radiusOfMinSplashDamage;
    }
  }
}
