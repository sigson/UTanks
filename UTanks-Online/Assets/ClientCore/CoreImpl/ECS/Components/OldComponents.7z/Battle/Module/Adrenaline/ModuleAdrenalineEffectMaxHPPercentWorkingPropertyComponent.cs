
using UTanksServer.ECS.ECSCore;

namespace UTanksServer.ECS.Components.Battle.Module.Adrenaline {
  [TypeUid(636365875777960253L)]
  public class ModuleAdrenalineEffectMaxHPPercentWorkingPropertyComponent : ModuleEffectUpgradablePropertyComponent { }
}
