using System;


using UTanksServer.ECS.ECSCore;

namespace UTanksServer.ECS.Components.Battle.Time {
  [TypeUid(92197374614905239)]
  public class RoundStopTimeComponent : ECSComponent {
    public long StopTime { get; set; }

    public RoundStopTimeComponent(DateTimeOffset stopTime) {
      StopTime = stopTime.ToUnixTimeMilliseconds();
    }
  }
}
