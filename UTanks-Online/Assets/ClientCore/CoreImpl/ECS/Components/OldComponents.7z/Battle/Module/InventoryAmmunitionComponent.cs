﻿
using UTanksServer.ECS.ECSCore;

namespace UTanksServer.ECS.Components.Battle.Module {
  [TypeUid(636383014039871905L)]
  public class InventoryAmmunitionComponent : ECSComponent {
    public int CurrentCount { get; set; }
    public int MaxCount { get; set; }

    public InventoryAmmunitionComponent(int maxCount = 0) {
      CurrentCount = maxCount;
      MaxCount = maxCount;
    }
  }
}
