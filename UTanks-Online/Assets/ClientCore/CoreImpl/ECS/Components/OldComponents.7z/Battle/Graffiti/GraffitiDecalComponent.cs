using System.Numerics;


using UTanksServer.ECS.ECSCore;

namespace UTanksServer.ECS.Components.Battle.Graffiti {
  [TypeUid(636100801609006236L)]
  public class GraffitiDecalComponent : ECSComponent {
    public Vector3 SprayPosition { get; set; }
    public Vector3 SprayDirection { get; set; }
    public Vector3 SprayUpDirection { get; set; }
  }
}
