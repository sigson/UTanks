﻿
using UTanksServer.ECS.ECSCore;

namespace UTanksServer.ECS.Components.Battle.Module.AcceleratedGears {
  [TypeUid(1541765983249L)]
  public class ModuleAcceleratedGearsEffectHullRotationSpeedPropertyComponent : ModuleEffectUpgradablePropertyComponent { }
}
