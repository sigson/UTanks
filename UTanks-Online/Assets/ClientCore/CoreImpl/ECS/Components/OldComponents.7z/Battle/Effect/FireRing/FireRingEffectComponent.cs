
using UTanksServer.ECS.ECSCore;

namespace UTanksServer.ECS.Components.Battle.Effect.FireRing {
  [TypeUid(1542695311337L)]
  public class FireRingEffectComponent : ECSComponent {
    public long Duration { get; set; }

    public float TemperatureDelta { get; set; }
    public float TemperatureLimit { get; set; }

    public FireRingEffectComponent() {
      Duration = 4;

      TemperatureDelta = 150;
      TemperatureLimit = 60;
    }
  }
}
