
using UTanksServer.ECS.ECSCore;

namespace UTanksServer.ECS.Components.Battle.Tank.Incarnation {
  [TypeUid(1491549293967)]
  public class TankIncarnationKillStatisticsComponent : ECSComponent {
    public int Kills { get; set; }
  }
}
