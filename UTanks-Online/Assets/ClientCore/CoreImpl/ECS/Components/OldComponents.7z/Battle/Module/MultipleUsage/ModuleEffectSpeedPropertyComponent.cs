﻿
using UTanksServer.ECS.ECSCore;

namespace UTanksServer.ECS.Components.Battle.Module.MultipleUsage {
  [TypeUid(636364868010252631L)]
  public class ModuleEffectSpeedPropertyComponent : ModuleEffectUpgradablePropertyComponent { }
}
