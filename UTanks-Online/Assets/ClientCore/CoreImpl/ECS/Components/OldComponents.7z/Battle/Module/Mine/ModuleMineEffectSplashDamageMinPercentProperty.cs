
using UTanksServer.ECS.ECSCore;

namespace UTanksServer.ECS.Components.Battle.Module.Mine {
  [TypeUid(636364863305483587L)]
  public class ModuleMineEffectSplashDamageMinPercentPropertyComponent : ModuleEffectUpgradablePropertyComponent { }
}
