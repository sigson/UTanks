
using UTanksServer.ECS.ECSCore;

namespace UTanksServer.ECS.Components.Battle.Weapon {
  [TypeUid(636392465276329653L)]
  public class ShootableComponent : ECSComponent { }
}
