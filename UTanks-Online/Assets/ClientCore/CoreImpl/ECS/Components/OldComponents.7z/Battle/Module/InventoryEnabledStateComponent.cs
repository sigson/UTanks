﻿
using UTanksServer.ECS.ECSCore;

namespace UTanksServer.ECS.Components.Battle.Module {
  [TypeUid(1486635410088L)]
  public class InventoryEnabledStateComponent : ECSComponent { }
}
