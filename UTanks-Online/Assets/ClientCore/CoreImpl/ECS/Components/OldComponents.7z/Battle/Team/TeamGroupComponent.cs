
using UTanksServer.ECS.ECSCore;
using UTanksServer.ECS.Components.Groups;

namespace UTanksServer.ECS.Components.Battle.Team {
  [TypeUid(6955808089218759626)]
  public class TeamGroupComponent : GroupComponent {
    public TeamGroupComponent(ECSEntity entity) : base(entity) { }
    public TeamGroupComponent(long key) : base(key) { }
  }
}
