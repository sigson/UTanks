
using UTanksServer.ECS.ECSCore;

namespace UTanksServer.ECS.Components.Battle {
  [TypeUid(1436532217083L)]
  public class BattleScoreComponent : ECSComponent {
    public int Score { get; set; }

    public int ScoreRed { get; set; }
    public int ScoreBlue { get; set; }

    public BattleScoreComponent(int score, int scoreRed, int scoreBlue) {
      Score = score;

      ScoreRed = scoreRed;
      ScoreBlue = scoreBlue;
    }
  }
}
