﻿
using UTanksServer.ECS.ECSCore;

namespace UTanksServer.ECS.Components.Battle.Module {
  [TypeUid(1505906670608L)]
  public class ForceFieldTransformComponent : ECSComponent {
    public Movement.Movement Movement { get; set; }

    public ForceFieldTransformComponent(Movement.Movement movement) {
      Movement = movement;
    }
  }
}
