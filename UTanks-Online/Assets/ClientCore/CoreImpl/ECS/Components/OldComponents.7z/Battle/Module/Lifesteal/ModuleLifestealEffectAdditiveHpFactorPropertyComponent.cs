﻿
using UTanksServer.ECS.ECSCore;

namespace UTanksServer.ECS.Components.Battle.Module.Lifesteal {
  /// <remarks>Original name: ModuleLifestealEffectAdditiveHPFactorPropertyComponent</remarks>
  [TypeUid(636353776254463073L)]
  public class ModuleLifestealEffectAdditiveHpFactorPropertyComponent : ModuleEffectUpgradablePropertyComponent { }
}
