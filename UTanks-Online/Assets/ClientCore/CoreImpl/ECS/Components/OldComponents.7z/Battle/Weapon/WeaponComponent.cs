
using UTanksServer.ECS.ECSCore;

namespace UTanksServer.ECS.Components.Battle.Weapon {
  [TypeUid(1753170307328606337)]
  public class WeaponComponent : ECSComponent { }
}
