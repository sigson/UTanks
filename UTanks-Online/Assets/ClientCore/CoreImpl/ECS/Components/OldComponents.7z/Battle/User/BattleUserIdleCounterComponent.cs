using System;


using UTanksServer.ECS.ECSCore;

namespace UTanksServer.ECS.Components.Battle.User {
  /// <remarks>Original name: IdleCounterComponent</remarks>
  [TypeUid(2930474294118078222)]
  public class BattleUserIdleCounterComponent : ECSComponent {
    [ProtocolOptional] public DateTime? SkipBeginDate { get; set; }
    public long SkippedMillis { get; set; }

    public BattleUserIdleCounterComponent(long skippedMillis, DateTime? skipBeginDate = null) {
      SkipBeginDate = skipBeginDate;
      SkippedMillis = skippedMillis;
    }
  }
}
