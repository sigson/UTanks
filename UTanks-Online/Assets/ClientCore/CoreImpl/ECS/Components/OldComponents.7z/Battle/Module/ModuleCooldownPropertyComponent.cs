﻿
using UTanksServer.ECS.ECSCore;

namespace UTanksServer.ECS.Components.Battle.Module {
  [TypeUid(636350270419523154L)]
  public class ModuleCooldownPropertyComponent : ModuleEffectUpgradablePropertyComponent { }
}
