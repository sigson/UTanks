
using UTanksServer.ECS.ECSCore;

namespace UTanksServer.ECS.Components.Battle.Tank.Incarnation {
  [TypeUid(1478091189336)]
  public class TankIncarnationComponent : ECSComponent { }
}
