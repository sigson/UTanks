
using UTanksServer.ECS.ECSCore;

namespace UTanksServer.ECS.Components.Battle.Mode {
  /// <remarks>Original name: TDMComponent</remarks>
  [TypeUid(-3014435861245042556L)]
  public class TdmComponent : ECSComponent { }
}
