
using UTanksServer.ECS.ECSCore;

namespace UTanksServer.ECS.Components.Battle.Round {
  [TypeUid(-5556650973238726161L)]
  public class RoundRestartingStateComponent : ECSComponent { }
}
