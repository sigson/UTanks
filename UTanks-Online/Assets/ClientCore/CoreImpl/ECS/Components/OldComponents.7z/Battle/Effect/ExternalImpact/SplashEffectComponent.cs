
using UTanksServer.ECS.ECSCore;

namespace UTanksServer.ECS.Components.Battle.Effect.ExternalImpact {
  /// <remarks>Original name: SplashEffectComponent</remarks>
  [TypeUid(1542363613520L)]
  public class SplashEffectComponent : ECSComponent {
    public bool CanTargetTeammates { get; set; }

    public SplashEffectComponent(bool canTargetTeammates) {
      CanTargetTeammates = canTargetTeammates;
    }
  }
}
