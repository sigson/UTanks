using System.Numerics;


using UTanksServer.ECS.ECSCore;

namespace UTanksServer.ECS.Components.Battle.Tank {
  [TypeUid(1835748384321L)]
  public class TankJumpComponent : ECSComponent {
    public float StartTime { get; set; }
    public Vector3 Velocity { get; set; }
    public bool OnFly { get; set; }
    public bool Slowdown { get; set; }
    public float SlowdownStartTime { get; set; }
  }
}
