
using UTanksServer.ECS.ECSCore;


namespace UTanksServer.ECS.Components.Battle.Time {
  [TypeUid(1447751145383)]
  public class BattleTimeIndicatorComponent : ECSComponent {
    public string TimeText { get; set; }
    public float Progress { get; set; }

    public BattleTimeIndicatorComponent(string timeText, float progress) {
      TimeText = timeText;
      Progress = progress;
    }
  }
}
