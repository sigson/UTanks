
using UTanksServer.ECS.ECSCore;

namespace UTanksServer.ECS.Components.Battle.Weapon.Smoky {
  [TypeUid(-8909369349482735423L)]
  public class SmokyComponent : ECSComponent { }
}
