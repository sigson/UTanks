using UTanksServer.ECS.ECSCore;


namespace UTanksServer.ECS.Components.Battle.Weapon.Hammer {
  [TypeUid(1464955716416L)]
  public class HammerPelletConeComponent : ECSComponent {
    public float HorizontalConeHalfAngle { get; set; }
    public float VerticalConeHalfAngle { get; set; }

    public int PelletCount { get; set; }

    public HammerPelletConeComponent(float horizontalConeHalfAngle, float verticalConeHalfAngle, int pelletCount) {
      HorizontalConeHalfAngle = horizontalConeHalfAngle;
      VerticalConeHalfAngle = verticalConeHalfAngle;
      PelletCount = pelletCount;
    }
  }
}
