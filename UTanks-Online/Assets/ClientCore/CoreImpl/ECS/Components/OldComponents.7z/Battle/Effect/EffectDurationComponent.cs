using System;


using UTanksServer.ECS.ECSCore;

namespace UTanksServer.ECS.Components.Battle.Effect {
  /// <remarks>Original name: DurationComponent</remarks>
  [TypeUid(5192591761194414739L)]
  public class EffectDurationComponent : ECSComponent {
    public DateTime StartedTime { get; set; }

    public EffectDurationComponent(DateTime startedTime) {
      StartedTime = startedTime;
    }
  }
}
