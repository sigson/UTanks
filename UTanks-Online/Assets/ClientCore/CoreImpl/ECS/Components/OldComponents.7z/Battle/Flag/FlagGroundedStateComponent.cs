
using UTanksServer.ECS.ECSCore;

namespace UTanksServer.ECS.Components.Battle.Flag {
  [TypeUid(-5647412743872630142L)]
  public class FlagGroundedStateComponent : ECSComponent { }
}
