
using UTanksServer.ECS.ECSCore;

namespace UTanksServer.ECS.Components.Battle {
  /// <remarks>Original name: ScoreLimitComponent</remarks>
  [TypeUid(-3048295118496552479)]
  public class BattleScoreLimitComponent : ECSComponent {
    public int ScoreLimit { get; set; }

    public BattleScoreLimitComponent(int scoreLimit) {
      ScoreLimit = scoreLimit;
    }
  }
}
