﻿
using UTanksServer.ECS.ECSCore;

namespace UTanksServer.ECS.Components.Battle.Module.JumpImpact {
  [TypeUid(1538454546805L)]
  public class JumpImpactForceMultPropertyComponent : ModuleEffectUpgradablePropertyComponent { }
}
