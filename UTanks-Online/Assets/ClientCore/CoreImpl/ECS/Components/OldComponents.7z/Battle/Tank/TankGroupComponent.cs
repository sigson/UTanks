
using UTanksServer.ECS.ECSCore;
using UTanksServer.ECS.Components.Groups;

namespace UTanksServer.ECS.Components.Battle.Tank {
  [TypeUid(4088029591333632383)]
  public class TankGroupComponent : GroupComponent {
    public TankGroupComponent(ECSEntity entity) : base(entity) { }
    public TankGroupComponent(long key) : base(key) { }
  }
}
