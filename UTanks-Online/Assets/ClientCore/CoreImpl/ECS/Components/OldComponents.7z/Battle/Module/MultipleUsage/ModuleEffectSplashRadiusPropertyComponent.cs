
using UTanksServer.ECS.ECSCore;

namespace UTanksServer.ECS.Components.Battle.Module.MultipleUsage {
  [TypeUid(1542363751348L)]
  public class ModuleEffectSplashRadiusPropertyComponent : ModuleEffectUpgradablePropertyComponent { }
}
