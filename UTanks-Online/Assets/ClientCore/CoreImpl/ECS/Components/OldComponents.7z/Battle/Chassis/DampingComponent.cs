
using UTanksServer.ECS.ECSCore;

namespace UTanksServer.ECS.Components.Battle.Chassis {
  [TypeUid(1437725485852)]
  public class DampingComponent : ECSComponent {
    public float Damping { get; set; }

    public DampingComponent(float damping) {
      Damping = damping;
    }
  }
}
