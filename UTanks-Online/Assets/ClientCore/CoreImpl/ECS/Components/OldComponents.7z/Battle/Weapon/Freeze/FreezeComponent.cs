using UTanksServer.ECS.ECSCore;


namespace UTanksServer.ECS.Components.Battle.Weapon.Freeze {
  [TypeUid(-6302277327770479278L)]
  public class FreezeComponent : ECSComponent { }
}
