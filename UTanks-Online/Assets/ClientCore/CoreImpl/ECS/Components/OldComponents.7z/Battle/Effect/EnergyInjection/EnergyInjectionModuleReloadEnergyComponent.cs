
using UTanksServer.ECS.ECSCore;

namespace UTanksServer.ECS.Components.Battle.Effect.EnergyInjection {
  [TypeUid(636367507221863506L)]
  public class EnergyInjectionModuleReloadEnergyComponent : ECSComponent {
    public float ReloadEnergyPercent { get; set; }

    public EnergyInjectionModuleReloadEnergyComponent(float reloadEnergyPercent) {
      ReloadEnergyPercent = reloadEnergyPercent;
    }
  }
}
