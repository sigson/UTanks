
using UTanksServer.ECS.ECSCore;

namespace UTanksServer.ECS.Components.Battle.Round {
  [TypeUid(3670620103661822470)]
  public class RoundComponent : ECSComponent { }
}
