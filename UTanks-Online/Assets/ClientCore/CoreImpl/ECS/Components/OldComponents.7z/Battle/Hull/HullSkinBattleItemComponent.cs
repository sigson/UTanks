
using UTanksServer.ECS.ECSCore;

namespace UTanksServer.ECS.Components.Battle.Hull {
  [TypeUid(636047118717612351)]
  public class HullSkinBattleItemComponent : ECSComponent { }
}
