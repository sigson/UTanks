using UTanksServer.ECS.ECSCore;


namespace UTanksServer.ECS.Components.Battle.Weapon.Hammer {
  [TypeUid(5461724450865069568L)]
  public class HammerComponent : ECSComponent { }
}
