
using UTanksServer.ECS.ECSCore;

namespace UTanksServer.ECS.Components.Battle.Module.Adrenaline {
  [TypeUid(636365877003610356L)]
  public class ModuleAdrenalineEffectCooldownSpeedCoeffPropertyComponent : ModuleEffectUpgradablePropertyComponent { }
}
