
using UTanksServer.ECS.ECSCore;

namespace UTanksServer.ECS.Components.Battle.Graffiti {
  [TypeUid(636100801973199045L)]
  public class GraffitiBattleItemComponent : ECSComponent { }
}
