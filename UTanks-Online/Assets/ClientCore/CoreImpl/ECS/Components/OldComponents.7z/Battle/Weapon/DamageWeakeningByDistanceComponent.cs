
using UTanksServer.ECS.ECSCore;

namespace UTanksServer.ECS.Components.Battle.Weapon {
  [TypeUid(2869455602943064305L)]
  // TODO(Assasans): Document fucking property names
  public class DamageWeakeningByDistanceComponent : ECSComponent {
    public float MinDamagePercent { get; set; }

    public float RadiusOfMaxDamage { get; set; }
    public float RadiusOfMinDamage { get; set; }

    public DamageWeakeningByDistanceComponent(float minDamagePercent, float radiusOfMaxDamage, float radiusOfMinDamage) {
      MinDamagePercent = minDamagePercent;
      RadiusOfMaxDamage = radiusOfMaxDamage;
      RadiusOfMinDamage = radiusOfMinDamage;
    }
  }
}
