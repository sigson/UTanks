
using UTanksServer.ECS.ECSCore;

namespace UTanksServer.ECS.Components.Battle.Weapon.Hammer {
  /// <remarks>Original name: MagazineReadyStateComponent</remarks>
  [TypeUid(-2847147893073248509L)]
  public class HammerMagazineReadyStateComponent : ECSComponent { }
}
