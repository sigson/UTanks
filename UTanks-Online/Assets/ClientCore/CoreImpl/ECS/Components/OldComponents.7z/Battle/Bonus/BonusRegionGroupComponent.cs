
using UTanksServer.ECS.ECSCore;
using UTanksServer.ECS.Components.Groups;

namespace UTanksServer.ECS.Components.Battle.Bonus {
  [TypeUid(8566120830355322079L)]
  public class BonusRegionGroupComponent : GroupComponent {
    public BonusRegionGroupComponent(ECSEntity entity) : base(entity) { }
    public BonusRegionGroupComponent(long key) : base(key) { }
  }
}
