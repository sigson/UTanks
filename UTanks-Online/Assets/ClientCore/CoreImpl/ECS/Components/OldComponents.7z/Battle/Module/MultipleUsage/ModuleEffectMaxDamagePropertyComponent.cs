﻿
using UTanksServer.ECS.ECSCore;

namespace UTanksServer.ECS.Components.Battle.Module.MultipleUsage {
  [TypeUid(636364870290426531L)]
  public class ModuleEffectMaxDamagePropertyComponent : ModuleEffectUpgradablePropertyComponent { }
}
