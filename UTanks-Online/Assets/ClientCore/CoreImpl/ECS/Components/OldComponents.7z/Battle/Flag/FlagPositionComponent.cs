using System.Numerics;


using UTanksServer.ECS.ECSCore;

namespace UTanksServer.ECS.Components.Battle.Flag {
  [TypeUid(-7424433796811681217L)]
  public class FlagPositionComponent : ECSComponent {
    public Vector3 Position { get; set; }

    public FlagPositionComponent(Vector3 position) {
      Position = position;
    }
  }
}
