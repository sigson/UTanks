
using UTanksServer.ECS.ECSCore;

namespace UTanksServer.ECS.Components.Battle {
  /// <remarks>Original name: VisibleItemComponent</remarks>
  [TypeUid(635824351028615226L)]
  public class BattleVisibleComponent : ECSComponent { }
}
