
using UTanksServer.ECS.ECSCore;

namespace UTanksServer.ECS.Components.Battle.Weapon.Hammer {
  /// <remarks>Original name: MagazineReloadStateComponent</remarks>
  [TypeUid(-8359680231701816964L)]
  public class HammerMagazineReloadStateComponent : ECSComponent { }
}
