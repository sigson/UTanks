
using UTanksServer.ECS.ECSCore;

namespace UTanksServer.ECS.Components.Battle.Weapon.Shaft {
  [TypeUid(8631717637564140236L)]
  public class ShaftAimingWorkActivationStateComponent : ECSComponent {
    public float ActivationTimer { get; set; }
    public int ClientTime { get; set; }
  }
}
