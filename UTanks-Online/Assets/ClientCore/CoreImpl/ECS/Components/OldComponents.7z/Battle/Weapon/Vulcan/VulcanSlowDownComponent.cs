using System;


using UTanksServer.ECS.ECSCore;

namespace UTanksServer.ECS.Components.Battle.Weapon.Vulcan {
  [TypeUid(-6843896944033144903L)]
  public class VulcanSlowDownComponent : ECSComponent {
    public int ClientTime { get; set; }

    public bool IsAfterShooting { get; set; }

    public void OnAttached(Services.Servers.Game.Player player, ECSEntity weapon) {
      if(!IsAfterShooting) return;

      throw new NotImplementedException();
      // ((Vulcan)player.BattlePlayer.MatchPlayer.BattleWeapon).LastVulcanHeatTactTime = null;
      // ((Vulcan)player.BattlePlayer.MatchPlayer.BattleWeapon).VulcanShootingStartTime = null;
    }
  }
}
