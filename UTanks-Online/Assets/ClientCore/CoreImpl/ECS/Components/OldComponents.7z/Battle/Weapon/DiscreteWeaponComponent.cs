
using UTanksServer.ECS.ECSCore;

namespace UTanksServer.ECS.Components.Battle.Weapon {
  [TypeUid(4827843948170109589L)]
  public class DiscreteWeaponComponent : ECSComponent { }
}
