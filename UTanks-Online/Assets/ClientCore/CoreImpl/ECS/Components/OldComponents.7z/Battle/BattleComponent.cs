
using UTanksServer.ECS.ECSCore;

namespace UTanksServer.ECS.Components.Battle {
  [TypeUid(4993448249879742580)]
  public class BattleComponent : ECSComponent { }
}
