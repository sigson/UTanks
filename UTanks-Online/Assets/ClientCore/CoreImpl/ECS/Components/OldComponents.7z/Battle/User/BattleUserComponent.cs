using UTanksServer.ECS.ECSCore;


namespace UTanksServer.ECS.Components.Battle.User {
  [TypeUid(-6549017400741137637)]
  public class BattleUserComponent : ECSComponent { }
}
