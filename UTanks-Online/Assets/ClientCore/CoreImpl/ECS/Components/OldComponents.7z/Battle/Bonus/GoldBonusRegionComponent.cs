
using UTanksServer.ECS.ECSCore;

namespace UTanksServer.ECS.Components.Battle.Bonus {
  [TypeUid(7308100860894277025L)]
  public class GoldBonusRegionComponent : ECSComponent { }
}
