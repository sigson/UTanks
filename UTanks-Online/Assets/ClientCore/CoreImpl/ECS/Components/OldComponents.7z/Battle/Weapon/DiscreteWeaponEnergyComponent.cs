
using UTanksServer.ECS.ECSCore;

namespace UTanksServer.ECS.Components.Battle.Weapon {
  [TypeUid(1438077188268L)]
  public class DiscreteWeaponEnergyComponent : ECSComponent {
    public float ReloadEnergyPerSec { get; set; }
    public float UnloadEnergyPerShot { get; set; }

    public DiscreteWeaponEnergyComponent(float reloadEnergyPerSec, float unloadEnergyPerShot) {
      ReloadEnergyPerSec = reloadEnergyPerSec;
      UnloadEnergyPerShot = unloadEnergyPerShot;
    }
  }
}
