
using UTanksServer.ECS.ECSCore;

namespace UTanksServer.ECS.Components.Battle.Module.Rage {
  [TypeUid(636362455389111859L)]
  public class ModuleRageEffectReduceCooldownTimePerKillPropertyComponent : ModuleEffectUpgradablePropertyComponent { }
}
