
using UTanksServer.ECS.ECSCore;

namespace UTanksServer.ECS.Components.Battle.Effect.Rage {
  [TypeUid(636364996704090103L)]
  public class RageEffectComponent : ECSComponent {
    [ProtocolName("DecreaseCooldownPerKillMS")] public int DecreaseCooldownPerKillMillis { get; set; }

    public RageEffectComponent(int decreaseCooldownPerKillMillis) {
      DecreaseCooldownPerKillMillis = decreaseCooldownPerKillMillis;
    }
  }
}
