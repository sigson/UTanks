using UTanksServer.ECS.ECSCore;


namespace UTanksServer.ECS.Components.Battle.Effect.Emp {
  /// <remarks>Original name: EMPEffectComponent</remarks>
  [TypeUid(636250000933021510L)]
  public class EmpEffectComponent : ECSComponent {
    public float Radius { get; set; }

    public EmpEffectComponent(float radius) {
      Radius = radius;
    }
  }
}
