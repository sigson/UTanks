using System;


using UTanksServer.Services.Servers.Game;
using UTanksServer.ECS.ECSCore;

namespace UTanksServer.ECS.Components.Battle.Weapon {
  [TypeUid(971549724137995758L)]
  public class StreamWeaponWorkingComponent : ECSComponent {
    public int Time { get; set; }

    public void OnAttached(Services.Servers.Game.Player player, ECSEntity battleUser) {
      throw new NotImplementedException();
      // player.BattlePlayer.MatchPlayer.TryDeactivateInvisibility();
    }

    public void OnRemove(Services.Servers.Game.Player player, ECSEntity battleUser) {
      throw new NotImplementedException();
      // player.BattlePlayer.MatchPlayer.StreamHitLengths.Clear();
    }
  }
}
