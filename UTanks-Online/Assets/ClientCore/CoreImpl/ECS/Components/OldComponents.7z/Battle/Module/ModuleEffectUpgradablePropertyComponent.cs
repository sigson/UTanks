﻿using System.Collections.Generic;


using UTanksServer.ECS.ECSCore;

namespace UTanksServer.ECS.Components.Battle.Module {
  public abstract class ModuleEffectUpgradablePropertyComponent : ECSComponent {
    public List<float> UpgradeLevel2Values { get; set; }
    public bool LinearInterpolation { get; set; }

    public ModuleEffectUpgradablePropertyComponent() {
      UpgradeLevel2Values = new List<float>();
    }
  }
}
