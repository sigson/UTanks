
using UTanksServer.ECS.ECSCore;

namespace UTanksServer.ECS.Components.Battle.Effect.ExplosiveMass {
  [TypeUid(1543402751411L)]
  public class ExplosiveMassEffectComponent : ECSComponent {
    public float Radius { get; set; }
    public long Delay { get; set; }

    public ExplosiveMassEffectComponent(float radius, long delay = 3000) {
      Radius = radius;
      Delay = delay;
    }
  }
}
