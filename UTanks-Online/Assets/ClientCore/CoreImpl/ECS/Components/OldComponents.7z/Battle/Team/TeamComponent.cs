
using UTanksServer.ECS.ECSCore;

namespace UTanksServer.ECS.Components.Battle.Team {
  [TypeUid(-1462317917257855335)]
  public class TeamComponent : ECSComponent { }
}
