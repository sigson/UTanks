
using UTanksServer.ECS.ECSCore;

namespace UTanksServer.ECS.Components.Battle.Round {
  [TypeUid(1758386908788302656)]
  public class RoundUserComponent : ECSComponent { }
}
