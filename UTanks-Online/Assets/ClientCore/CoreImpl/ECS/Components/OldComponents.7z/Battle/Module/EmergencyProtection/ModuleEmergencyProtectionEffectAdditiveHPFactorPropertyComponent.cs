
using UTanksServer.ECS.ECSCore;

namespace UTanksServer.ECS.Components.Battle.Module.EmergencyProtection {
  [TypeUid(636362288661075561L)]
  public class ModuleEmergencyProtectionEffectAdditiveHPFactorPropertyComponent : ModuleEffectUpgradablePropertyComponent { }
}
