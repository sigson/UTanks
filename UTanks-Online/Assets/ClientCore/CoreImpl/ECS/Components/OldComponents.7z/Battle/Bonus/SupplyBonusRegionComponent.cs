
using UTanksServer.ECS.ECSCore;

namespace UTanksServer.ECS.Components.Battle.Bonus {
  [TypeUid(-4617088084931480326L)]
  public class SupplyBonusRegionComponent : ECSComponent { }
}
