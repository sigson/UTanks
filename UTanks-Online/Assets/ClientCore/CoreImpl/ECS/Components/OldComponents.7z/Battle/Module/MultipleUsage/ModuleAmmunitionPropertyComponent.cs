
using UTanksServer.ECS.ECSCore;

namespace UTanksServer.ECS.Components.Battle.Module.MultipleUsage {
  [TypeUid(636382998448773893L)]
  public class ModuleAmmunitionPropertyComponent : ModuleEffectUpgradablePropertyComponent { }
}
