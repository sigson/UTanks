using UTanksServer.ECS.Components.Battle.Movement;

using UTanksServer.ECS.ECSCore;

namespace UTanksServer.ECS.Components.Battle.Tank {
  [TypeUid(-615965945505672897)]
  public class TankMovementComponent : ECSComponent {
    public Movement.Movement Movement { get; set; }
    public MoveControl MoveControl { get; set; }

    public float WeaponRotation { get; set; }
    public float WeaponControl { get; set; }

    public TankMovementComponent(Movement.Movement movement, MoveControl moveControl, float weaponRotation, float weaponControl) {
      Movement = movement;
      MoveControl = moveControl;

      WeaponRotation = weaponRotation;
      WeaponControl = weaponControl;
    }
  }
}
