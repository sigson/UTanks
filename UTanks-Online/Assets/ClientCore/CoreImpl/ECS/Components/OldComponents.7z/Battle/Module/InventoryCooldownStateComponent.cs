﻿
using UTanksServer.ECS.ECSCore;

using System;

namespace UTanksServer.ECS.Components.Battle.Module {
  [TypeUid(1486635434064L)]
  public class InventoryCooldownStateComponent : ECSComponent {
    public DateTime CooldownStartTime { get; set; }
    public int CooldownTime { get; set; }

    public InventoryCooldownStateComponent(DateTime cooldownStartTime, int cooldownTime) {
      CooldownStartTime = cooldownStartTime;
      CooldownTime = cooldownTime;
    }
  }
}
