
using UTanksServer.ECS.ECSCore;

namespace UTanksServer.ECS.Components.Battle.Weapon.Vulcan {
  [TypeUid(-7317457627241247550L)]
  public class VulcanSpeedUpComponent : ECSComponent {
    public int ClientTime { get; set; }
  }
}
