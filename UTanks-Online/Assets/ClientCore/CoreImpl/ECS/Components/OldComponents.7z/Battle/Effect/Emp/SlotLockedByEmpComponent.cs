using UTanksServer.ECS.ECSCore;


namespace UTanksServer.ECS.Components.Battle.Effect.Emp {
  /// <remarks>Original name: SlotLockedByEMPComponent</remarks>
  [TypeUid(636371831496078072L)]
  public class SlotLockedByEmpComponent : ECSComponent { }
}
