
using UTanksServer.ECS.ECSCore;

namespace UTanksServer.ECS.Components.Battle.Weapon {
  [TypeUid(1437983636148L)]
  public class ImpactComponent : ECSComponent {
    public float ImpactForce { get; set; }

    public ImpactComponent(float impactForce) {
      ImpactForce = impactForce;
    }
  }
}
