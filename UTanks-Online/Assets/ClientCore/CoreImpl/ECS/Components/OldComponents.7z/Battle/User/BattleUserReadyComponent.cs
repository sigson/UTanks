using System;


using UTanksServer.ECS.ECSCore;
using UTanksServer.ECS.Types.Battle.Tank;

namespace UTanksServer.ECS.Components.Battle.User {
  /// <remarks>Original name: UserReadyToBattleComponent</remarks>
  [TypeUid(1399558738794728790)]
  public class BattleUserReadyComponent : ECSComponent {
    public void OnAttached(Services.Servers.Game.Player player, ECSEntity battleUser) {
      throw new NotImplementedException();
      // if(player.BattlePlayer != null) player.BattlePlayer.MatchPlayer.TankState = TankState.Spawn;
    }
  }
}
