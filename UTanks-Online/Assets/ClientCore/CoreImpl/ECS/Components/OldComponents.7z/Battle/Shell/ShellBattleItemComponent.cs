
using UTanksServer.ECS.ECSCore;

namespace UTanksServer.ECS.Components.Battle.Shell {
  [TypeUid(-3172561945444029781)]
  public class ShellBattleItemComponent : ECSComponent { }
}
