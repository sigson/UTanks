
using UTanksServer.ECS.ECSCore;

namespace UTanksServer.ECS.Components.Battle.Weapon.Vulcan {
  [TypeUid(468273627357216440L)]
  public class VulcanComponent : ECSComponent { }
}
