
using UTanksServer.ECS.ECSCore;

namespace UTanksServer.ECS.Components.Battle.Team {
  [TypeUid(-2440064891528955383)]
  public class TeamScoreComponent : ECSComponent {
    public int Score { get; set; }

    public TeamScoreComponent(int score) {
      Score = score;
    }
  }
}
