
using UTanksServer.ECS.ECSCore;

namespace UTanksServer.ECS.Components.Battle.Weapon {
  [TypeUid(5122689933165143605L)]
  public class StreamWeaponComponent : ECSComponent { }
}
