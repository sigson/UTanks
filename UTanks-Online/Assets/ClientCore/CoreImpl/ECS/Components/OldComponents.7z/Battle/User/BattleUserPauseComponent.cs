
using UTanksServer.ECS.ECSCore;

namespace UTanksServer.ECS.Components.Battle.User {
  /// <remarks>Original name: PauseComponent</remarks>
  [TypeUid(-1447059217096518564L)]
  public class BattleUserPauseComponent : ECSComponent { }
}
