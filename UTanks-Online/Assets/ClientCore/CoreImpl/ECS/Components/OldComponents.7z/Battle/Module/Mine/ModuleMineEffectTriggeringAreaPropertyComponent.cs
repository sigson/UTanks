﻿
using UTanksServer.ECS.ECSCore;

namespace UTanksServer.ECS.Components.Battle.Module.Mine {
  [TypeUid(636377085945440678L)]
  public class ModuleMineEffectTriggeringAreaPropertyComponent : ModuleEffectUpgradablePropertyComponent { }
}
