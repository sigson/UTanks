
using UTanksServer.ECS.ECSCore;

namespace UTanksServer.ECS.Components.Battle {
  [TypeUid(1436248430372L)]
  public class BattleSelectComponent : ECSComponent { }
}
