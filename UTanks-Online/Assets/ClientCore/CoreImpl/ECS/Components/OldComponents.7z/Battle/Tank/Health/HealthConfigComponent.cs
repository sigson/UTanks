
using UTanksServer.ECS.ECSCore;

namespace UTanksServer.ECS.Components.Battle.Tank.Health {
  /// <remarks>Original name: HealthConfigComponent</remarks>
  [TypeUid(8420700272384380156)]
  public class TankHealthConfigComponent : ECSComponent {
    public float BaseHealth { get; set; }

    public TankHealthConfigComponent(float baseHealth) {
      BaseHealth = baseHealth;
    }
  }
}
