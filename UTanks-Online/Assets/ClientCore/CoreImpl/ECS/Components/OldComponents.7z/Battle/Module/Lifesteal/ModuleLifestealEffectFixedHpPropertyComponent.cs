﻿
using UTanksServer.ECS.ECSCore;

namespace UTanksServer.ECS.Components.Battle.Module.Lifesteal {
  /// <remarks>Original name: ModuleLifestealEffectFixedHPPropertyComponent</remarks>
  [TypeUid(636353775649218455L)]
  public class ModuleLifestealEffectFixedHpPropertyComponent : ModuleEffectUpgradablePropertyComponent { }
}
