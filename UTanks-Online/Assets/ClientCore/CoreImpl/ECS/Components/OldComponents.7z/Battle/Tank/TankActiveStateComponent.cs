
using UTanksServer.ECS.ECSCore;

namespace UTanksServer.ECS.Components.Battle.Tank {
  [TypeUid(-6102394227324346258)]
  public class TankActiveStateComponent : ECSComponent { }
}
