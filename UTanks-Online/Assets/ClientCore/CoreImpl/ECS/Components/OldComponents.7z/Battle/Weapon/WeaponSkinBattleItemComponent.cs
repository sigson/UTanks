
using UTanksServer.ECS.ECSCore;

namespace UTanksServer.ECS.Components.Battle.Weapon {
  [TypeUid(636046284973498221)]
  public class WeaponSkinBattleItemComponent : ECSComponent { }
}
