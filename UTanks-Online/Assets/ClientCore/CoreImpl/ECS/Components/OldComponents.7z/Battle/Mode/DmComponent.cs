
using UTanksServer.ECS.ECSCore;

namespace UTanksServer.ECS.Components.Battle.Mode {
  /// <remarks>Original name: DMComponent</remarks>
  [TypeUid(-7862706140193752603)]
  public class DmComponent : ECSComponent { }
}
