
using UTanksServer.ECS.ECSCore;

namespace UTanksServer.ECS.Components.Battle.Time {
  [TypeUid(-3596341255560623830)]
  public class TimeLimitComponent : ECSComponent {
    public long TimeLimitSec { get; set; }
    public long WarmingUpTimeLimitSet { get; set; }

    public TimeLimitComponent(long timeLimitSec, long warmingUpTimeLimitSet) {
      TimeLimitSec = timeLimitSec;
      WarmingUpTimeLimitSet = warmingUpTimeLimitSet;
    }
  }
}
