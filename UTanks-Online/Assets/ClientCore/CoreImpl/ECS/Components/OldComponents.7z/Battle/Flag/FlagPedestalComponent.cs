using System.Numerics;


using UTanksServer.ECS.ECSCore;

namespace UTanksServer.ECS.Components.Battle.Flag {
  [TypeUid(4898317045808451550L)]
  public class FlagPedestalComponent : ECSComponent {
    public Vector3 Position { get; set; }

    public FlagPedestalComponent(Vector3 position) {
      Position = position;
    }
  }
}
