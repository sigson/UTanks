
using UTanksServer.ECS.ECSCore;

namespace UTanksServer.ECS.Components.Battle.Weapon.Shaft {
  [TypeUid(635950079224407790L)]
  public class ShaftStateConfigComponent : ECSComponent {
    public float WaitingToActivationTransitionTimeSec { get; set; }
    public float ActivationToWorkingTransitionTimeSec { get; set; }
    public float FinishToIdleTransitionTimeSec { get; set; }

    public ShaftStateConfigComponent(
      float waitingToActivationTransitionTimeSec,
      float activationToWorkingTransitionTimeSec,
      float finishToIdleTransitionTimeSec
    ) {
      WaitingToActivationTransitionTimeSec = waitingToActivationTransitionTimeSec;
      ActivationToWorkingTransitionTimeSec = activationToWorkingTransitionTimeSec;
      FinishToIdleTransitionTimeSec = finishToIdleTransitionTimeSec;
    }
  }
}
