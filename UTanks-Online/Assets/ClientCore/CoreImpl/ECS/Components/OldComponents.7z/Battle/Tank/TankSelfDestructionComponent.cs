using System;


using UTanksServer.ECS.ECSCore;

namespace UTanksServer.ECS.Components.Battle.Tank {
  /// <remarks>Original name: SelfDestructionComponent</remarks>
  [TypeUid(-9188485263407476652L)]
  public class TankSelfDestructionComponent : ECSComponent {
    public void OnAttached(Services.Servers.Game.Player player, ECSEntity tank) {
      throw new NotImplementedException();
      // player.BattlePlayer.MatchPlayer.SelfDestructionTime = DateTime.UtcNow.AddSeconds(5);
    }
  }
}
