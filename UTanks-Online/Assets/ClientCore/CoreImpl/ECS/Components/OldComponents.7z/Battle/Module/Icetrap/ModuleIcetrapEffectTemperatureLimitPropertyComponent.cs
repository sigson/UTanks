
using UTanksServer.ECS.ECSCore;

namespace UTanksServer.ECS.Components.Battle.Module.Icetrap {
  [TypeUid(636384786717917459L)]
  public class ModuleIcetrapEffectTemperatureLimitPropertyComponent : ModuleEffectUpgradablePropertyComponent { }
}
