using System;


using UTanksServer.ECS.ECSCore;

namespace UTanksServer.ECS.Components.Battle.Time {
  [TypeUid(1436521738148L)]
  public class BattleStartTimeComponent : ECSComponent {
    /// <remarks>ProtocolOptional is not used but set in the client</remarks>
    [ProtocolOptional] public long RoundStartTime { get; set; }

    public BattleStartTimeComponent(DateTimeOffset roundStartTime) {
      RoundStartTime = roundStartTime.ToUnixTimeMilliseconds();
    }
  }
}
