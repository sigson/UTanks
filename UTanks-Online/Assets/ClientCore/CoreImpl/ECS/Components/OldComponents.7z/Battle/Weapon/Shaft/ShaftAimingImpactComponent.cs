
using UTanksServer.ECS.ECSCore;

namespace UTanksServer.ECS.Components.Battle.Weapon.Shaft {
  [TypeUid(1437983715951L)]
  public class ShaftAimingImpactComponent : ECSComponent {
    public float MaxImpactForce { get; set; }

    public ShaftAimingImpactComponent(float maxImpactForce) {
      MaxImpactForce = maxImpactForce;
    }
  }
}
