
using UTanksServer.ECS.ECSCore;

namespace UTanksServer.ECS.Components.Battle.Weapon {
  [TypeUid(7115193786389139467)]
  public class WeaponCooldownComponent : ECSComponent {
    public float CooldownIntervalSec { get; set; }

    public WeaponCooldownComponent(float cooldownIntervalSec) {
      CooldownIntervalSec = cooldownIntervalSec;
    }
  }
}
