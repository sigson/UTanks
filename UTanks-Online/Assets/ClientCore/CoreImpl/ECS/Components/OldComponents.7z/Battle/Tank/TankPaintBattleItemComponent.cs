
using UTanksServer.ECS.ECSCore;

namespace UTanksServer.ECS.Components.Battle.Tank {
  [TypeUid(1437380560892)]
  public class TankPaintBattleItemComponent : ECSComponent { }
}
