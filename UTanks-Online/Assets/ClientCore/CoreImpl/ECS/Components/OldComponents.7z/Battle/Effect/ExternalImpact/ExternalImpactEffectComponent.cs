
using UTanksServer.ECS.ECSCore;

namespace UTanksServer.ECS.Components.Battle.Effect.ExternalImpact {
  [TypeUid(1542270913447L)]
  public class ExternalImpactEffectComponent : ECSComponent { }
}
