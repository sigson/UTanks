
using UTanksServer.ECS.ECSCore;

namespace UTanksServer.ECS.Components.Battle.Effect.Drone {
  [TypeUid(1486025343421L)]
  public class DroneEffectComponent : ECSComponent { }
}
