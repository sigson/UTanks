using System.Numerics;


using UTanksServer.ECS.ECSCore;

namespace UTanksServer.ECS.Components.Battle.Weapon.Shaft {
  [TypeUid(8445798616771064825L)]
  public class ShaftAimingTargetPointComponent : ECSComponent {
    public bool IsInsideTankPart { get; set; }

    [ProtocolOptional] public Vector3? Point { get; set; }
  }
}
