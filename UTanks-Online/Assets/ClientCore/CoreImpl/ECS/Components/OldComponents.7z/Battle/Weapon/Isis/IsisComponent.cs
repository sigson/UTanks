
using UTanksServer.ECS.ECSCore;

namespace UTanksServer.ECS.Components.Battle.Weapon.Isis {
  [TypeUid(-8080087598394650833L)]
  public class IsisComponent : ECSComponent { }
}
