
using UTanksServer.ECS.ECSCore;

namespace UTanksServer.ECS.Components.Battle.Module.EmergencyProtection {
  [TypeUid(636362287689760005L)]
  public class ModuleEmergencyProtectionEffectFixedHPPropertyComponent : ModuleEffectUpgradablePropertyComponent { }
}
