
using UTanksServer.ECS.ECSCore;

namespace UTanksServer.ECS.Components.Battle.Weapon.Hammer {
  /// <remarks>Original name: MagazineWeaponComponent</remarks>
  [TypeUid(4355651182908057733L)]
  public class HammerMagazineWeaponComponent : ECSComponent {
    public int MaxCartridgeCount { get; set; }
    public float ReloadMagazineTimePerSec { get; set; }

    public HammerMagazineWeaponComponent(int maxCartridgeCount, float reloadMagazineTimePerSec) {
      MaxCartridgeCount = maxCartridgeCount;
      ReloadMagazineTimePerSec = reloadMagazineTimePerSec;
    }
  }
}
