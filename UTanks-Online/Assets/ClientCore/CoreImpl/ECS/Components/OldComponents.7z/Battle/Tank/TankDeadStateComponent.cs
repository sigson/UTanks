using System;


using UTanksServer.ECS.ECSCore;

namespace UTanksServer.ECS.Components.Battle.Tank {
  [TypeUid(-2656312914607478436)]
  public class TankDeadStateComponent : ECSComponent {
    public DateTime EndTime { get; set; }

    public TankDeadStateComponent() {
      EndTime = DateTime.UtcNow.AddSeconds(3);
    }
  }
}
