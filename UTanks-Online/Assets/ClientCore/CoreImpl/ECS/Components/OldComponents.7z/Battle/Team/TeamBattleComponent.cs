
using UTanksServer.ECS.ECSCore;

namespace UTanksServer.ECS.Components.Battle.Team {
  [TypeUid(-7175336783650365377)]
  public class TeamBattleComponent : ECSComponent { }
}
