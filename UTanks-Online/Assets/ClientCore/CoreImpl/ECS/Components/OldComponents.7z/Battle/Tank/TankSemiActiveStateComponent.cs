
using UTanksServer.ECS.ECSCore;

namespace UTanksServer.ECS.Components.Battle.Tank {
  [TypeUid(5166099393636831290)]
  public class TankSemiActiveStateComponent : ECSComponent {
    public float ActivationTime { get; set; }

    public TankSemiActiveStateComponent(float activationTime = 0.25f) {
      ActivationTime = activationTime;
    }
  }
}
