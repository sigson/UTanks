﻿using System;


using UTanksServer.ECS.ECSCore;


namespace UTanksServer.ECS.Components.Battle.Module {
  [TypeUid(636367520290400984L)]
  public class InventorySlotTemporaryBlockedByServerComponent : ECSComponent {
    public DateTime StartBlockTime { get; set; }
    [ProtocolName("BlockTimeMS")] public long BlockTime { get; set; }

    public InventorySlotTemporaryBlockedByServerComponent(DateTime startBlockTime, long blockTime) {
      StartBlockTime = startBlockTime;
      BlockTime = blockTime;
    }
  }
}
