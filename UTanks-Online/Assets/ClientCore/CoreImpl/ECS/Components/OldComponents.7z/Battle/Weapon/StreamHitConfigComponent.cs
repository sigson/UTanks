
using UTanksServer.ECS.ECSCore;

namespace UTanksServer.ECS.Components.Battle.Weapon {
  [TypeUid(-5407563795844501148L)]
  public class StreamHitConfigComponent : ECSComponent {
    public float LocalCheckPeriod { get; set; }
    public float SendToServerPeriod { get; set; }

    public bool DetectStaticHit { get; set; }
  }
}
