
using UTanksServer.ECS.ECSCore;

namespace UTanksServer.ECS.Components.Battle.Weapon.Thunder {
  [TypeUid(-7859561519974477242L)]
  public class ThunderComponent : ECSComponent { }
}
