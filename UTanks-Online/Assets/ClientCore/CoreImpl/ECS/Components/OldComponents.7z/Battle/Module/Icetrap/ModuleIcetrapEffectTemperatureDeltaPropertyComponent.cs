
using UTanksServer.ECS.ECSCore;

namespace UTanksServer.ECS.Components.Battle.Module.Icetrap {
  [TypeUid(636384786473203463L)]
  public class ModuleIcetrapEffectTemperatureDeltaPropertyComponent : ModuleEffectUpgradablePropertyComponent { }
}
