using System.Numerics;


using UTanksServer.ECS.ECSCore;

namespace UTanksServer.ECS.Components.Battle.Bonus {
  /// <remarks>Original name: RotationComponent</remarks>
  [TypeUid(-1853333282151870933)]
  public class BonusRotationComponent : ECSComponent {
    public Vector3 RotationEuler { get; set; }

    public BonusRotationComponent(Vector3 rotationEuler) {
      RotationEuler = rotationEuler;
    }
  }
}
