
using UTanksServer.ECS.ECSCore;
using UTanksServer.ECS.Types.Battle.Bonus;

namespace UTanksServer.ECS.Components.Battle.Bonus {
  [TypeUid(-3961778961585441606L)]
  public class BonusRegionComponent : ECSComponent {
    public BonusType Type { get; set; }

    public BonusRegionComponent(BonusType type) {
      Type = type;
    }
  }
}
