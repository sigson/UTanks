using System;


using UTanksServer.Services.Servers.Game;
using UTanksServer.ECS.ECSCore;

namespace UTanksServer.ECS.Components.Battle.Weapon {
  [TypeUid(6803807621463709653L)]
  public class WeaponStreamShootingComponent : ECSComponent {
    [ProtocolOptional] public DateTime? StartShootingTime { get; set; }

    public int Time { get; set; }

    public void OnAttached(Services.Servers.Game.Player player, ECSEntity weapon) {
      throw new NotImplementedException();
      // if(player.BattlePlayer.MatchPlayer.BattleWeapon.GetType() == typeof(Vulcan)) {
      //   ((Vulcan)player.BattlePlayer.MatchPlayer.BattleWeapon).TrySaveShootingStartTime();
      // }
    }
  }
}
