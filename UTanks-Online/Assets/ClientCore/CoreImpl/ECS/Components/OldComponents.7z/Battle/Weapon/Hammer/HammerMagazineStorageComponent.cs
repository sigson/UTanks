
using UTanksServer.ECS.ECSCore;

namespace UTanksServer.ECS.Components.Battle.Weapon.Hammer {
  /// <remarks>Original name: MagazineStorageComponent</remarks>
  [TypeUid(2388237143993578319L)]
  public class HammerMagazineStorageComponent : ECSComponent {
    public int CurrentCartridgeCount { get; set; }

    public HammerMagazineStorageComponent(int currentCartridgeCount) {
      CurrentCartridgeCount = currentCartridgeCount;
    }
  }
}
