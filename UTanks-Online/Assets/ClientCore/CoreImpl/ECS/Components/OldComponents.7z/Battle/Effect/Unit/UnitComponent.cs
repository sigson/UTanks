
using UTanksServer.ECS.ECSCore;

namespace UTanksServer.ECS.Components.Battle.Effect.Unit {
  [TypeUid(1486028267437L)]
  public class UnitComponent : ECSComponent { }
}
