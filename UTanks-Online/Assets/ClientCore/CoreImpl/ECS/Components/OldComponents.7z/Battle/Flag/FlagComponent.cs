
using UTanksServer.ECS.ECSCore;

namespace UTanksServer.ECS.Components.Battle.Flag {
  [TypeUid(1431940940187L)]
  public class FlagComponent : ECSComponent { }
}
