using System.Numerics;


using UTanksServer.ECS.ECSCore;

namespace UTanksServer.ECS.Components.Battle.Bonus {
  /// <remarks>Original name: PositionComponent</remarks>
  [TypeUid(4605414188335188027)]
  public class BonusPositionComponent : ECSComponent {
    public Vector3 Position { get; set; }

    public BonusPositionComponent(Vector3 position) {
      Position = position;
    }
  }
}
