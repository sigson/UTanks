
using UTanksServer.ECS.ECSCore;

namespace UTanksServer.ECS.Components.Battle.Weapon {
  [TypeUid(1437989437781L)]
  public class KickbackComponent : ECSComponent {
    public float KickbackForce { get; set; }

    public KickbackComponent(float kickbackForce) {
      KickbackForce = kickbackForce;
    }
  }
}
