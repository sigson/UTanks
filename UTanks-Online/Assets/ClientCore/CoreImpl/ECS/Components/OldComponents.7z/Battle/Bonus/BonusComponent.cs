
using UTanksServer.ECS.ECSCore;

namespace UTanksServer.ECS.Components.Battle.Bonus {
  [TypeUid(8101904939955946870)]
  public class BonusComponent : ECSComponent { }
}
