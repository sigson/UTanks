
using UTanksServer.ECS.ECSCore;

namespace UTanksServer.ECS.Components.Battle.Mode {
  /// <remarks>Original name: CTFComponent</remarks>
  [TypeUid(-3628517123128351904)]
  public class CtfComponent : ECSComponent { }
}
