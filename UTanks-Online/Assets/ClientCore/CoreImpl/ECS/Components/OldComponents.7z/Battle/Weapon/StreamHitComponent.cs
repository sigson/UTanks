
using UTanksServer.ECS.ECSCore;
using UTanksServer.ECS.Types.Battle.Weapon;

namespace UTanksServer.ECS.Components.Battle.Weapon {
  [TypeUid(-6274985110858845212L)]
  public class StreamHitComponent : ECSComponent {
    [ProtocolOptional] public HitTarget? TankHit { get; set; }
    [ProtocolOptional] public StaticHit? StaticHit { get; set; }
  }
}
