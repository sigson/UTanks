
using UTanksServer.ECS.ECSCore;

namespace UTanksServer.ECS.Components.Battle.Weapon.Shaft {
  [TypeUid(-5749845294664286691L)]
  public class ShaftIdleStateComponent : ECSComponent { }
}
