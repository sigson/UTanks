
using UTanksServer.ECS.ECSCore;

namespace UTanksServer.ECS.Components.Battle.Tank {
  [TypeUid(-3257495205014980038)]
  public class TankSpawnStateComponent : ECSComponent { }
}
