
using UTanksServer.ECS.ECSCore;
using UTanksServer.ECS.Components.Groups;

namespace UTanksServer.ECS.Components.Battle.Effect.Unit {
  [TypeUid(1485231135123L)]
  public class UnitGroupComponent : GroupComponent {
    public UnitGroupComponent(ECSEntity entity) : base(entity) { }
    public UnitGroupComponent(long key) : base(key) { }
  }
}
