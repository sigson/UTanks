
using UTanksServer.ECS.ECSCore;

namespace UTanksServer.ECS.Components.Battle.Round {
  [TypeUid(1519220488495)]
  public class RoundWarmingUpStateComponent : ECSComponent { }
}
