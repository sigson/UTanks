
using UTanksServer.ECS.ECSCore;

namespace UTanksServer.ECS.Components.Battle.Round {
  [TypeUid(-503038106518527208)]
  public class RoundActiveStateComponent : ECSComponent { }
}
