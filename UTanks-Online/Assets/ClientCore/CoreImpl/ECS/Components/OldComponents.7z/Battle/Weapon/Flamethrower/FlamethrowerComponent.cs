using UTanksServer.ECS.ECSCore;


namespace UTanksServer.ECS.Components.Battle.Weapon.Flamethrower {
  [TypeUid(-748006331130499044L)]
  public class FlamethrowerComponent : ECSComponent { }
}
