
using UTanksServer.ECS.ECSCore;

namespace UTanksServer.ECS.Components.Battle.Weapon.Shaft {
  [TypeUid(-5670596162316552032L)]
  public class ShaftAimingWorkFinishStateComponent : ECSComponent {
    public float FinishTimer { get; set; }
    public int ClientTime { get; set; }
  }
}
