
using UTanksServer.ECS.ECSCore;

namespace UTanksServer.ECS.Components.Battle.Weapon.Shaft {
  [TypeUid(-9115674636175564451L)]
  public class ShaftComponent : ECSComponent { }
}
