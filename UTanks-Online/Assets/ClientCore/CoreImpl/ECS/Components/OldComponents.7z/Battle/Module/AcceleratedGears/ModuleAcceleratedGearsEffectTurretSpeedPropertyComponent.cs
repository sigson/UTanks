﻿
using UTanksServer.ECS.ECSCore;

namespace UTanksServer.ECS.Components.Battle.Module.AcceleratedGears {
  [TypeUid(636353691668785049L)]
  public class ModuleAcceleratedGearsEffectTurretSpeedPropertyComponent : ModuleEffectUpgradablePropertyComponent { }
}
