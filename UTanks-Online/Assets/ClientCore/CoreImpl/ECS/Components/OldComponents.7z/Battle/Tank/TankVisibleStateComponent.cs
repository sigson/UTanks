
using UTanksServer.ECS.ECSCore;

namespace UTanksServer.ECS.Components.Battle.Tank {
  [TypeUid(1490261141766)]
  public class TankVisibleStateComponent : ECSComponent { }
}
