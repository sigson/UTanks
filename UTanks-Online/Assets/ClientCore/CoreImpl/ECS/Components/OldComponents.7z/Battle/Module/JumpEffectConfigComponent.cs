﻿
using UTanksServer.ECS.ECSCore;

namespace UTanksServer.ECS.Components.Battle.Module {
  [TypeUid(1538548472363L)]
  public class JumpEffectConfigComponent : ECSComponent {
    public float ForceUpgradeMult { get; set; }

    public JumpEffectConfigComponent(float forceUpgradeMult) {
      ForceUpgradeMult = forceUpgradeMult;
    }
  }
}
