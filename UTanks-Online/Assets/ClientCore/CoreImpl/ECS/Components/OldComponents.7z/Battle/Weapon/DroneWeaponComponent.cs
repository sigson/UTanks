
using UTanksServer.ECS.ECSCore;

namespace UTanksServer.ECS.Components.Battle.Weapon {
  [TypeUid(1482462483179L)]
  public class DroneWeaponComponent : ECSComponent { }
}
