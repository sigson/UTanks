
using UTanksServer.ECS.ECSCore;

namespace UTanksServer.ECS.Components.Battle.Effect.Unit {
  [TypeUid(636364931473899150L)]
  public class UnitTargetingConfigComponent : ECSComponent {
    public float TargetingPeriod { get; set; }
    public float WorkDistance { get; set; }

    public UnitTargetingConfigComponent(float targetingPeriod, float workingDistance) {
      TargetingPeriod = targetingPeriod;
      WorkDistance = workingDistance;
    }
  }
}
