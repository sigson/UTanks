﻿
using UTanksServer.ECS.ECSCore;

namespace UTanksServer.ECS.Components.Battle.Module {
  [TypeUid(636353722123286947L)]
  public class ModuleEngineerEffectDurationFactorPropertyComponent : ModuleEffectUpgradablePropertyComponent { }
}
