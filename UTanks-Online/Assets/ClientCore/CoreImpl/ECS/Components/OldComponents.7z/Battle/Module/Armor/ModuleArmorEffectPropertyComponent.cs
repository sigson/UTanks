﻿
using UTanksServer.ECS.ECSCore;

namespace UTanksServer.ECS.Components.Battle.Module.Armor {
  [TypeUid(636352805194667895L)]
  public class ModuleArmorEffectPropertyComponent : ModuleEffectUpgradablePropertyComponent { }
}
