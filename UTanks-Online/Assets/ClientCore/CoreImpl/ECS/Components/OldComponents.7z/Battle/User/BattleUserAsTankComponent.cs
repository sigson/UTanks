
using UTanksServer.ECS.ECSCore;

namespace UTanksServer.ECS.Components.Battle.User {
  /// <remarks>Original name: UserInBattleAsTankComponent</remarks>
  [TypeUid(9050657850876792572)]
  public class BattleUserAsTankComponent : ECSComponent { }
}
