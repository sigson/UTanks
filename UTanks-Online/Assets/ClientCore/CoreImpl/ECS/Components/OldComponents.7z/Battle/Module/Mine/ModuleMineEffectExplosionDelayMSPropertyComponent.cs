﻿
using UTanksServer.ECS.ECSCore;

namespace UTanksServer.ECS.Components.Battle.Module.Mine {
  [TypeUid(636377164225108018L)]
  public class ModuleMineEffectExplosionDelayMSPropertyComponent : ModuleEffectUpgradablePropertyComponent { }
}
