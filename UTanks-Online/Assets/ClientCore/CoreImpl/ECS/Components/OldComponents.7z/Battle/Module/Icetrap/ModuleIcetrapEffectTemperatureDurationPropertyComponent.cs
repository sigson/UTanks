
using UTanksServer.ECS.ECSCore;

namespace UTanksServer.ECS.Components.Battle.Module.Icetrap {
  [TypeUid(636384786165975890L)]
  public class ModuleIcetrapEffectTemperatureDurationPropertyComponent : ModuleEffectUpgradablePropertyComponent { }
}
