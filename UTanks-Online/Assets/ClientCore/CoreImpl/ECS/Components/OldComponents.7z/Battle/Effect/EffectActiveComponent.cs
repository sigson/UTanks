
using UTanksServer.ECS.ECSCore;

namespace UTanksServer.ECS.Components.Battle.Effect {
  [TypeUid(1431673116434L)]
  public class EffectActiveComponent : ECSComponent { }
}
