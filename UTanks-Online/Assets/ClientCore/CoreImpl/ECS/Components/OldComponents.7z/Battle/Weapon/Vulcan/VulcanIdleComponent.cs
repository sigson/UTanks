
using UTanksServer.ECS.ECSCore;

namespace UTanksServer.ECS.Components.Battle.Weapon.Vulcan {
  [TypeUid(-3791262141248621103L)]
  public class VulcanIdleComponent : ECSComponent {
    public int Time { get; set; }
  }
}
