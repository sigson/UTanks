using System.Numerics;


using UTanksServer.ECS.ECSCore;

namespace UTanksServer.ECS.Components.Battle.Effect.Unit {
  [TypeUid(1485519196443L)]
  public class UnitMoveComponent : ECSComponent {
    public Movement.Movement Movement { get; set; }

    [ServerOnlyData] public Vector3 LastPosition { get; set; }

    public UnitMoveComponent(Movement.Movement movement) {
      Movement = movement;
    }
  }
}
