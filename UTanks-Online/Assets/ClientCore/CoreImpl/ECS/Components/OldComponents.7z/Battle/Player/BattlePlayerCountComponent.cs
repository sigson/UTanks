
using UTanksServer.ECS.ECSCore;

namespace UTanksServer.ECS.Components.Battle.Player {
  /// <remarks>Original name: UserCountComponent</remarks>
  [TypeUid(1436520497855L)]
  public class BattlePlayerCountComponent : ECSComponent {
    [ProtocolName("UserCount")] public int PlayerCount { get; set; }

    public BattlePlayerCountComponent(int playerCount) {
      PlayerCount = playerCount;
    }
  }
}
