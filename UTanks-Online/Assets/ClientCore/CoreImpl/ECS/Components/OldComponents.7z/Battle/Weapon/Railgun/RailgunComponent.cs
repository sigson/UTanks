
using UTanksServer.ECS.ECSCore;

namespace UTanksServer.ECS.Components.Battle.Weapon.Railgun {
  [TypeUid(1105463674216064116L)]
  public class RailgunComponent : ECSComponent { }
}
