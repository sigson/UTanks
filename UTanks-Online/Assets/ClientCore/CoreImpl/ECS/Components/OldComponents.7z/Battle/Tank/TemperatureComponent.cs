
using UTanksServer.ECS.ECSCore;

namespace UTanksServer.ECS.Components.Battle.Tank {
  [TypeUid(6673681254298647708L)]
  public class TemperatureComponent : ECSComponent {
    public float Temperature { get; set; }

    public TemperatureComponent(float temperature) {
      Temperature = temperature;
    }
  }
}
