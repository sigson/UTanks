﻿
using UTanksServer.ECS.ECSCore;

namespace UTanksServer.ECS.Components.Battle.Module.Emp {
  /// <remarks>Original name: ModuleEMPEffectRadiusPropertyComponent</remarks>
  [TypeUid(636371764390179834L)]
  public class ModuleEmpEffectRadiusPropertyComponent : ModuleEffectUpgradablePropertyComponent { }
}
