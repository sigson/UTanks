﻿
using UTanksServer.ECS.ECSCore;

namespace UTanksServer.ECS.Components.Battle.Module.MultipleUsage {
  [TypeUid(636364869964762333L)]
  public class ModuleEffectMinDamagePropertyComponent : ModuleEffectUpgradablePropertyComponent { }
}
