
using UTanksServer.ECS.ECSCore;

namespace UTanksServer.ECS.Components.Battle.Tank {
  [TypeUid(-8709930588703405128)]
  public class TankComponent : ECSComponent { }
}
