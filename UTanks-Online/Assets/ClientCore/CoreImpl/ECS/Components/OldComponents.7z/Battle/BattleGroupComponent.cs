
using UTanksServer.ECS.ECSCore;
using UTanksServer.ECS.Components.Groups;

namespace UTanksServer.ECS.Components.Battle {
  [TypeUid(1140613249019529884)]
  public class BattleGroupComponent : GroupComponent {
    public BattleGroupComponent(ECSEntity entity) : base(entity) { }
    public BattleGroupComponent(long key) : base(key) { }
  }
}
