
using UTanksServer.ECS.ECSCore;

namespace UTanksServer.ECS.Components.Battle.Weapon {
  [TypeUid(1498352458940656986L)]
  public class StreamWeaponIdleComponent : ECSComponent {
    public int Time { get; set; }
  }
}
