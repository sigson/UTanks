
using UTanksServer.ECS.ECSCore;

namespace UTanksServer.ECS.Components.Battle {
  [TypeUid(-7296556060693494496L)]
  public class BattleConfiguredComponent : ECSComponent { }
}
