using System;


using UTanksServer.ECS.ECSCore;

namespace UTanksServer.ECS.Components.Battle.Bonus {
  [TypeUid(-7944772313373733709)]
  public class BonusDropTimeComponent : ECSComponent {
    public DateTime DropTime { get; set; }

    public BonusDropTimeComponent(DateTime dropTime) {
      DropTime = dropTime;
    }
  }
}
