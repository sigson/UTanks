
using UTanksServer.ECS.ECSCore;

namespace UTanksServer.ECS.Components.Battle.Weapon.Shaft {
  [TypeUid(6541712051864507498L)]
  public class ShaftWaitingStateComponent : ECSComponent {
    public float WaitingTimer { get; set; }
    public int Time { get; set; }
  }
}
