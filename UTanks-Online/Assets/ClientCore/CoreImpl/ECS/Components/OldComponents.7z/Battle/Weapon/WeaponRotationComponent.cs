
using UTanksServer.ECS.ECSCore;

namespace UTanksServer.ECS.Components.Battle.Weapon {
  [TypeUid(1432792458422)]
  public class WeaponRotationComponent : ECSComponent {
    public float BaseSpeed { get; set; }
    public float Speed { get; set; }

    public float Acceleration { get; set; }

    // TODO(Assasans)
    public WeaponRotationComponent(float simplifiedTurretRotation) {
      BaseSpeed = simplifiedTurretRotation;
      Speed = simplifiedTurretRotation;

      Acceleration = simplifiedTurretRotation;
    }

    // TODO(Assasans)
    // public void ChangeByTemperature(BattleWeapon battleWeapon, float multiplier) {
    //   Speed = battleWeapon.OriginalWeaponRotationComponent.Speed * multiplier;
    // }
  }
}
