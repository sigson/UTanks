
using UTanksServer.ECS.ECSCore;

namespace UTanksServer.ECS.Components.Battle.Weapon {
  [TypeUid(1438773081827L)]
  public class SplashImpactComponent : ECSComponent {
    public SplashImpactComponent(float impactForce) {
      ImpactForce = impactForce;
    }

    public float ImpactForce { get; set; }
  }
}
