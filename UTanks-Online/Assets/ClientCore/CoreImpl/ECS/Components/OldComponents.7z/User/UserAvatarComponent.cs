
using UTanksServer.ECS.ECSCore;

namespace UTanksServer.ECS.Components.User {
  [TypeUid(1545809085571L)]
  public class UserAvatarComponent : ECSComponent {
    public string Id { get; set; }

    public UserAvatarComponent(string id) {
      Id = id;
    }
  }
}
