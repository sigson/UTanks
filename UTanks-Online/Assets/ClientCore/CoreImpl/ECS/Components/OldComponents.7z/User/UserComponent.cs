
using UTanksServer.ECS.ECSCore;

namespace UTanksServer.ECS.Components.User {
  [TypeUid(5326061426508819120)]
  public class UserComponent : ECSComponent { }
}
