using UTanksServer.ECS.ECSCore;


namespace UTanksServer.ECS.Components.User {
  /// <remarks>Original name: UserUidComponent</remarks>
  [TypeUid(-5477085396086342998)]
  public class UserUsernameComponent : ECSComponent {
    [ProtocolName("Uid")] public string Username { get; set; }

    public UserUsernameComponent(string username) {
      Username = username;
    }
  }
}
